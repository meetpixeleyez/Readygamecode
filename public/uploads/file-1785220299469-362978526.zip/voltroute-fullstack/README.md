# VoltRoute — Full Stack (Flutter + NestJS + PostgreSQL)

## Quick Start

### 1. Start PostgreSQL
```bash
cd docker
docker-compose up -d
```

### 2. Start Backend (NestJS)
```bash
cd backend
npm install
npx prisma db push
npm run start:dev
# → http://localhost:3001
```

### 3. Start Frontend (Flutter)
```bash
cd frontend
flutter pub get
# Edit lib/services/api_service.dart → set baseUrl
flutter run
```

## Structure
```
voltroute-fullstack/
├── backend/     ← NestJS API (port 3001)
├── frontend/    ← Flutter app
├── docker/      ← PostgreSQL docker-compose
└── README.md
```

import { Module } from '@nestjs/common';
import { PrismaModule } from './prisma/prisma.module';
import { StationsController } from './controllers/stations.controller';
import { VehiclesController } from './controllers/vehicles.controller';
import { BookingsController } from './controllers/bookings.controller';
import { WalletController } from './controllers/wallet.controller';
import { PaymentsController } from './controllers/payments.controller';
import { ReviewsController } from './controllers/reviews.controller';
import { RoutePlannerController } from './controllers/route-planner.controller';
import { OwnerController } from './controllers/owner.controller';
import { AdminController } from './controllers/admin.controller';
import { AiController } from './controllers/ai.controller';
import { MeController } from './controllers/me.controller';
import { SetupController } from './controllers/setup.controller';

@Module({
  imports: [PrismaModule],
  controllers: [
    StationsController,
    VehiclesController,
    BookingsController,
    WalletController,
    PaymentsController,
    ReviewsController,
    RoutePlannerController,
    OwnerController,
    AdminController,
    AiController,
    MeController,
    SetupController,
  ],
})
export class AppModule {}

import { Controller, Get } from '@nestjs/common';
import { getAdminOverview } from '../services/admin.service';

@Controller('admin')
export class AdminController {
  @Get()
  async overview() {
    return await getAdminOverview();
  }
}

import { Controller, Post, Body } from '@nestjs/common';
import { runBatteryPrediction, runEmergencyAssessment, runCostComparison, runTripIntelligence } from '../services/ai.service';

@Controller('ai')
export class AiController {
  @Post('predict-battery')
  async predict(@Body() body: any) {
    if (!body.vehicle) return { error: 'vehicle required' };
    return { prediction: await runBatteryPrediction(body) };
  }

  @Post('emergency')
  async emergency(@Body() body: any) {
    if (!body.vehicle || typeof body.userLat !== 'number') return { error: 'vehicle, userLat, userLng required' };
    return { assessment: await runEmergencyAssessment(body) };
  }

  @Post('compare-costs')
  async compare(@Body() body: any) {
    if (!body.vehicle) return { error: 'vehicle required' };
    return await runCostComparison(body);
  }

  @Post('plan-trip')
  async planTrip(@Body() body: any) {
    if (!body.from || !body.to || !body.vehicle) return { error: 'from, to, vehicle required' };
    return { plan: await runTripIntelligence(body) };
  }
}

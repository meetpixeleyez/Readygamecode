import { Controller, Get, Post, Patch, Query, Body, Param } from '@nestjs/common';
import { getBookingsByUser, createBooking, cancelBooking, completeBooking, rescheduleBooking } from '../services/booking.service';

@Controller('bookings')
export class BookingsController {
  @Get()
  async list(@Query('userId') userId: string) {
    if (!userId) return { error: 'userId required' };
    return { bookings: await getBookingsByUser(userId) };
  }

  @Post()
  async create(@Body() body: any) {
    const result = await createBooking(body);
    if ('error' in result) return { error: result.error };
    return result;
  }

  @Patch(':id')
  async update(@Param('id') id: string, @Body() body: any) {
    switch (body.action) {
      case 'cancel': return { booking: await cancelBooking(id) };
      case 'complete': return { booking: await completeBooking(id) };
      case 'reschedule':
        if (!body.slotStart || !body.slotEnd) return { error: 'slotStart and slotEnd required' };
        return { booking: await rescheduleBooking(id, body.slotStart, body.slotEnd) };
      default: return { error: 'Unknown action' };
    }
  }
}

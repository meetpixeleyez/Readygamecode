import { Controller, Get, Patch, Body } from '@nestjs/common';
import { getDemoUser, updateDemoUser, getUserStats } from '../services/user.service';
import { db } from '../prisma/prisma.service';
import { DEFAULT_PREFERENCES } from '../shared/types';

@Controller('me')
export class MeController {
  @Get()
  async getMe() {
    let user = await getDemoUser();
    if (!user) {
      const created = await db.user.create({ data: { email: 'demo@ev.app', name: 'New User', role: 'USER', walletBalance: 0, preferences: JSON.stringify(DEFAULT_PREFERENCES) } });
      user = { ...created, preferences: DEFAULT_PREFERENCES, vehicles: [] as any };
    }
    return { user };
  }

  @Patch()
  async updateMe(@Body() body: any) {
    const user = await updateDemoUser(body);
    if (!user) return { error: 'User not found' };
    return { user };
  }

  @Get('stats')
  async stats() {
    return await getUserStats();
  }
}

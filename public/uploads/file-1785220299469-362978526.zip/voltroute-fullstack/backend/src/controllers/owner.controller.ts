import { Controller, Get, Post, Patch, Body, Query } from '@nestjs/common';
import { getOwnerStations, createStation, toggleChargerStatus, approveStation, suspendStation } from '../services/owner.service';

@Controller('owner')
export class OwnerController {
  @Get()
  async list(@Query('ownerId') ownerId: string) {
    if (!ownerId) return { error: 'ownerId required' };
    return { stations: await getOwnerStations(ownerId) };
  }

  @Post()
  async create(@Body() body: any) {
    if (!body.ownerId || !body.name || !body.state || !body.city || !body.address) return { error: 'Missing fields' };
    const station = await createStation(body);
    return { station: { ...station, amenities: station.amenities.split(',') } };
  }

  @Patch()
  async update(@Body() body: any) {
    switch (body.action) {
      case 'toggle-charger': return { charger: await toggleChargerStatus(body.chargerId, body.status) };
      case 'approve-station': return { station: await approveStation(body.id) };
      case 'suspend-station': return { station: await suspendStation(body.id) };
      default: return { error: 'Unknown action' };
    }
  }
}

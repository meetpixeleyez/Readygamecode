import { Controller, Post, Body } from '@nestjs/common';
import { createOrder, verifyPaymentSignature } from '../services/payment.service';
import { computeBookingAmount, createBookingAfterRazorpayPayment } from '../services/booking.service';
import { db } from '../prisma/prisma.service';

@Controller('payments')
export class PaymentsController {
  @Post('create-order')
  async createOrder(@Body() body: any) {
    const { paymentMethod } = body;
    if (paymentMethod !== 'UPI' && paymentMethod !== 'CARD') return { error: 'Only UPI/CARD' };
    const priced = await computeBookingAmount(body);
    if ('error' in priced) return { error: priced.error };
    const order = await createOrder(priced.amount, `ev_${Date.now()}`);
    return { orderId: order.id, amount: order.amount, amountInr: priced.amount, currency: order.currency, keyId: process.env.NEXT_PUBLIC_RAZORPAY_KEY_ID, receipt: order.receipt };
  }

  @Post('verify')
  async verify(@Body() body: any) {
    const valid = verifyPaymentSignature({
      razorpay_order_id: body.razorpay_order_id,
      razorpay_payment_id: body.razorpay_payment_id,
      razorpay_signature: body.razorpay_signature,
    });
    if (!valid) return { error: 'Signature verification failed' };
    const result = await createBookingAfterRazorpayPayment(body);
    if ('error' in result) return { error: result.error };
    return { booking: result.booking };
  }

  @Post('recover')
  async recover(@Body() body: any) {
    const { razorpay_order_id, type, amount, bookingPayload } = body;
    const res = await fetch(`https://api.razorpay.com/v1/orders/${razorpay_order_id}/payments`, {
      headers: { Authorization: 'Basic ' + Buffer.from(`${process.env.RAZORPAY_KEY_ID}:${process.env.RAZORPAY_KEY_SECRET}`).toString('base64') },
    });
    const data = await res.json();
    const captured = (data.items || []).find((p: any) => p.status === 'captured');
    if (!captured) return { recovered: false, message: 'No successful payment found' };
    if (type === 'wallet') {
      const user = await db.user.findFirst({ where: { email: 'demo@ev.app' } });
      if (!user) return { error: 'User not found' };
      const existing = await db.transaction.findFirst({ where: { reason: { contains: captured.id } } });
      if (existing) return { recovered: true, alreadyProcessed: true };
      await db.user.update({ where: { id: user.id }, data: { walletBalance: { increment: Number(amount) } } });
      const tx = await db.transaction.create({ data: { userId: user.id, type: 'CREDIT', amount: Number(amount), reason: `WALLET_TOPUP_RAZORPAY_${captured.id}` } });
      const u = await db.user.findUnique({ where: { id: user.id } });
      return { recovered: true, transaction: tx, walletBalance: u?.walletBalance };
    }
    const result = await createBookingAfterRazorpayPayment(bookingPayload);
    return result;
  }
}

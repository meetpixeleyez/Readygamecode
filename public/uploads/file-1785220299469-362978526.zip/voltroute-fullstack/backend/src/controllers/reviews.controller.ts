import { Controller, Get, Post, Body, Query } from '@nestjs/common';
import { getReviewsByStation, createReview } from '../services/review.service';

@Controller('reviews')
export class ReviewsController {
  @Get()
  async list(@Query('stationId') stationId: string) {
    if (!stationId) return { error: 'stationId required' };
    return { reviews: await getReviewsByStation(stationId) };
  }

  @Post()
  async create(@Body() body: any) {
    const result = await createReview(body);
    if ('error' in result) return { error: result.error };
    return result;
  }
}

import { Controller, Post, Body } from '@nestjs/common';
import { planTrip } from '../services/route-planner.service';

@Controller('route-planner')
export class RoutePlannerController {
  @Post()
  async plan(@Body() body: any) {
    if (!body.from || !body.to || !body.vehicle) return { error: 'from, to, vehicle required' };
    return { trip: await planTrip(body) };
  }
}

import { Controller, Get, Post, Body } from '@nestjs/common';
import { db } from '../prisma/prisma.service';

@Controller('setup')
export class SetupController {
  @Get('status')
  async status() {
    const [users, stations, vehicleModels] = await Promise.all([db.user.count(), db.station.count(), db.vehicleModel.count()]);
    return { needsSetup: stations === 0, hasUsers: users > 0, hasStations: stations > 0, hasVehicleModels: vehicleModels > 0, stationCount: stations, vehicleModelCount: vehicleModels, userCount: users };
  }

  @Post('stations')
  async createStations(@Body() body: any) {
    const { stations } = body;
    if (!Array.isArray(stations)) return { error: 'stations array required' };
    const created = [];
    for (const s of stations) {
      const station = await db.station.create({
        data: { name: s.name, description: s.description || null, state: s.state, city: s.city, address: s.address, lat: Number(s.lat) || 0, lng: Number(s.lng) || 0, open24x7: Boolean(s.open24x7), operatingHours: s.operatingHours || null, amenities: (s.amenities || []).join(','), status: 'APPROVED', rating: 0, reviewCount: 0, chargers: { create: (s.chargers || []).map((c: any) => ({ label: c.label, connectorType: c.connectorType, powerKw: Number(c.powerKw), chargerSpeed: c.chargerSpeed, pricingModel: c.pricingModel, price: Number(c.price), status: 'AVAILABLE' })) } },
        include: { chargers: true },
      });
      created.push({ ...station, amenities: station.amenities.split(',') });
    }
    return { created: created.length, stations: created };
  }

  @Get('vehicle-models')
  async getModels() {
    const models = await db.vehicleModel.findMany({ orderBy: { brand: 'asc' } });
    return { models: models.map(m => ({ ...m, connectors: m.connectors.split(',') })) };
  }

  @Post('vehicle-models')
  async createModels(@Body() body: any) {
    const { models } = body;
    if (!Array.isArray(models)) return { error: 'models array required' };
    const created = [];
    for (const m of models) {
      const model = await db.vehicleModel.create({ data: { brand: m.brand, model: m.model, vehicleType: m.vehicleType || '4W', batteryCapacity: Number(m.batteryCapacity) || 40, fullRange: Number(m.fullRange) || 300, connectors: Array.isArray(m.connectors) ? m.connectors.join(',') : 'CCS2', maxAcKw: Number(m.maxAcKw) || 7.4, maxDcKw: Number(m.maxDcKw) || 50, popular: Boolean(m.popular) } });
      created.push(model);
    }
    return { created: created.length, models: created };
  }
}

import { Controller, Get, Query, Param } from '@nestjs/common';
import { searchStations, getStationById } from '../services/station.service';

@Controller('stations')
export class StationsController {
  @Get()
  async search(@Query() query: any) {
    const filters = {
      search: query.search, state: query.state, city: query.city,
      connectors: query.connectors?.split(','), speeds: query.speeds?.split(','),
      availableNow: query.availableNow === 'true', openNow: query.openNow === 'true',
      minRating: query.minRating ? Number(query.minRating) : undefined,
      amenities: query.amenities?.split(','),
      userLat: query.userLat ? Number(query.userLat) : undefined,
      userLng: query.userLng ? Number(query.userLng) : undefined,
      radius: query.radius ? Number(query.radius) : undefined,
    };
    const stations = await searchStations(filters);
    return { stations };
  }

  @Get(':id')
  async getById(@Param('id') id: string) {
    const station = await getStationById(id);
    if (!station) return { error: 'Station not found' };
    return { station };
  }
}

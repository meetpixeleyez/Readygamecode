import { Controller, Get, Post, Patch, Delete, Query, Body } from '@nestjs/common';
import { getVehiclesByUser, createVehicle, updateVehicle, deleteVehicle } from '../services/vehicle.service';

@Controller('vehicles')
export class VehiclesController {
  @Get()
  async list(@Query('userId') userId: string) {
    if (!userId) return { error: 'userId required' };
    return { vehicles: await getVehiclesByUser(userId) };
  }

  @Post()
  async create(@Body() body: any) {
    if (!body.userId || !body.brand || !body.model) return { error: 'Missing required fields' };
    return { vehicle: await createVehicle(body) };
  }

  @Patch()
  async update(@Body() body: any) {
    if (!body.id) return { error: 'id required' };
    const { id, ...patch } = body;
    return { vehicle: await updateVehicle({ id, ...patch }) };
  }

  @Delete()
  async remove(@Query('id') id: string) {
    if (!id) return { error: 'id required' };
    await deleteVehicle(id);
    return { success: true };
  }
}

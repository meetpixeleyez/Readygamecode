import { Controller, Get, Post, Body, Query } from '@nestjs/common';
import { getTransactions, createTopupOrder, verifyAndCreditWallet } from '../services/wallet.service';

@Controller('wallet')
export class WalletController {
  @Get()
  async transactions(@Query('userId') userId: string) {
    if (!userId) return { error: 'userId required' };
    return { transactions: await getTransactions(userId) };
  }

  @Post('create-order')
  async createOrder(@Body() body: any) {
    try { return await createTopupOrder(body.userId, Number(body.amount)); }
    catch (e: any) { return { error: e.message }; }
  }

  @Post('verify')
  async verify(@Body() body: any) {
    const result = await verifyAndCreditWallet({
      userId: body.userId, amountInr: Number(body.amount),
      razorpay_order_id: body.razorpay_order_id,
      razorpay_payment_id: body.razorpay_payment_id,
      razorpay_signature: body.razorpay_signature,
    });
    if ('error' in result) return { error: result.error };
    return result;
  }
}

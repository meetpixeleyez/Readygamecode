// ── AI Battery Predictor ─────────────────────────────────────────────
// Physics-based range prediction with realistic degradation factors.
// No ML model — pure deterministic calculation with sensible defaults.

import { haversine } from './utils'
import type {
  BatteryPrediction,
  BatteryPredictorInput,
  Station,
  Vehicle,
} from '../shared/types'

// ── Factor tables ────────────────────────────────────────────────────

const TERRAIN_FACTORS: Record<NonNullable<BatteryPredictorInput['terrain']>, number> = {
  flat: 1.0,
  hilly: 0.85,
  mountain: 0.72,
}

const WEATHER_FACTORS: Record<NonNullable<BatteryPredictorInput['weather']>, number> = {
  ideal: 1.0,    // 20-30°C, clear
  cold: 0.82,    // <10°C — battery chemistry slows, heating draws power
  hot: 0.93,     // >40°C — AC load
  rainy: 0.88,   // wipers + AC defog + drag
}

/**
 * Speed factor — EVs are most efficient at 40-60 km/h.
 * Above 80 km/h, aerodynamic drag eats range exponentially.
 */
function speedFactor(speed: number): number {
  if (speed <= 60) return 1.0
  if (speed <= 80) return 0.92
  if (speed <= 100) return 0.82
  if (speed <= 120) return 0.70
  return 0.58 // 120+ km/h is brutal for range
}

/**
 * Optimal speed for range — the sweet spot.
 */
function optimalSpeed(vehicle: Vehicle): number {
  // 2-wheelers are efficient at lower speeds; 4W at 60
  return vehicle.vehicleType === '2W' ? 50 : 60
}

/**
 * Battery health degradation model.
 *   - New battery: 100%
 *   - Loses ~0.15% per month of age
 *   - Loses ~0.05% per fast-charge session (DC fast charging stresses cells)
 *   - Floor at 70% (batteries are typically replaced below this)
 */
export function computeBatteryHealth(
  vehicleAgeMonths: number = 0,
  fastChargeCount: number = 0,
): number {
  const ageDegradation = vehicleAgeMonths * 0.15
  const fastChargeDegradation = fastChargeCount * 0.05
  return Math.max(70, Math.min(100, 100 - ageDegradation - fastChargeDegradation))
}

/**
 * Confidence score — how much we trust the prediction.
 * Higher when we have more data (route, weather, terrain).
 */
function computeConfidence(input: BatteryPredictorInput): number {
  let confidence = 82 // baseline
  if (input.routeDistanceKm !== undefined) confidence += 6
  if (input.terrain) confidence += 4
  if (input.weather) confidence += 4
  if (input.avgSpeed) confidence += 4
  return Math.min(98, confidence)
}

/**
 * Main prediction function.
 */
export function predictBattery(input: BatteryPredictorInput): BatteryPrediction {
  const {
    vehicle,
    routeDistanceKm,
    terrain = 'flat',
    avgSpeed,
    weather = 'ideal',
    acOn = true,
    nearbyStations = [],
    fastChargeCount = 0,
    vehicleAgeMonths = 0,
  } = input

  // ── Base range from current battery ──
  const baseRange = vehicle.fullRange * (vehicle.currentBattery / 100)

  // ── Apply factors ──
  const terrainF = TERRAIN_FACTORS[terrain]
  const speedF = avgSpeed ? speedFactor(avgSpeed) : 1.0
  const weatherF = WEATHER_FACTORS[weather]
  const acF = acOn ? 0.90 : 1.0
  const healthF = computeBatteryHealth(vehicleAgeMonths, fastChargeCount) / 100

  const predictedRange = Math.round(
    baseRange * terrainF * speedF * weatherF * acF * healthF,
  )

  // ── Arrival battery (if route distance given) ──
  let arrivalBattery = vehicle.currentBattery
  if (routeDistanceKm !== undefined && routeDistanceKm > 0) {
    const batteryUsed = (routeDistanceKm / Math.max(predictedRange, 1)) * vehicle.currentBattery
    arrivalBattery = Math.max(0, Math.round(vehicle.currentBattery - batteryUsed))
  }

  // ── Confidence ──
  const confidence = computeConfidence(input)

  // ── Battery health ──
  const batteryHealth = Math.round(computeBatteryHealth(vehicleAgeMonths, fastChargeCount))

  // ── Suggested speed ──
  const suggestedSpeed = optimalSpeed(vehicle)

  // ── Recommended charger ──
  // Pick the nearest station with a DC fast charger compatible with the vehicle
  let recommendedCharger: BatteryPrediction['recommendedCharger'] = null
  let estimatedCost = 0
  let recommendedChargeTime = 0

  if (nearbyStations.length > 0) {
    const compatible = nearbyStations
      .filter((s) => s.chargers.some((c) =>
        vehicle.connectors.includes(c.connectorType) && c.status === 'AVAILABLE',
      ))
      .map((s) => ({
        station: s,
        charger: s.chargers.find((c) =>
          vehicle.connectors.includes(c.connectorType) && c.status === 'AVAILABLE',
        )!,
        distance: 0, // filled below if we had user location
      }))
      .sort((a, b) => b.charger.powerKw - a.charger.powerKw) // prefer faster

    if (compatible.length > 0) {
      const pick = compatible[0]
      recommendedCharger = { station: pick.station, charger: pick.charger }

      // Estimate charge time: from current battery to 80%
      const targetPercent = 80
      const kwhNeeded = vehicle.batteryCapacity * ((targetPercent - vehicle.currentBattery) / 100)
      const effectiveKw = targetPercent > 80 ? pick.charger.powerKw * 0.7 : pick.charger.powerKw
      recommendedChargeTime = Math.max(5, Math.round((kwhNeeded / Math.max(effectiveKw, 1)) * 60))

      // Estimate cost
      if (pick.charger.pricingModel === 'PER_KWH') {
        estimatedCost = Math.round(kwhNeeded * pick.charger.price)
      } else if (pick.charger.pricingModel === 'PER_HOUR') {
        estimatedCost = Math.round((recommendedChargeTime / 60) * pick.charger.price)
      } else {
        estimatedCost = pick.charger.price
      }
    }
  }

  // ── Breakdown for UI ──
  const breakdown: BatteryPrediction['breakdown'] = [
    { label: 'Base range', impact: `${Math.round(baseRange)} km`, detail: `${vehicle.currentBattery}% battery × ${vehicle.fullRange} km full range` },
    { label: `Terrain (${terrain})`, impact: `${Math.round(terrainF * 100)}%`, detail: terrain === 'flat' ? 'No elevation impact' : 'Elevation changes reduce efficiency' },
    { label: `Speed (${avgSpeed ?? suggestedSpeed} km/h)`, impact: `${Math.round(speedF * 100)}%`, detail: avgSpeed && avgSpeed > 80 ? 'Aerodynamic drag reduces range' : 'Optimal speed zone' },
    { label: `Weather (${weather})`, impact: `${Math.round(weatherF * 100)}%`, detail: weather === 'ideal' ? 'Ideal conditions' : 'Weather impacts battery chemistry' },
    { label: `AC ${acOn ? 'ON' : 'OFF'}`, impact: `${Math.round(acF * 100)}%`, detail: acOn ? 'Climate control draws ~10% range' : 'No climate load' },
    { label: 'Battery health', impact: `${Math.round(healthF * 100)}%`, detail: `${fastChargeCount} fast charges, ${vehicleAgeMonths} months old` },
  ]

  return {
    predictedRange,
    arrivalBattery,
    confidence,
    batteryHealth,
    suggestedSpeed,
    recommendedCharger,
    estimatedCost,
    recommendedChargeTime,
    factors: { terrain: terrainF, speed: speedF, weather: weatherF, acUsage: acF, health: healthF },
    breakdown,
  }
}

// ── Charging Cost Comparison Engine ──────────────────────────────────
// Ranks nearby stations by a weighted score: cost (40%) + time (40%) + rating (20%).

import type {
  CostComparisonInput,
  CostComparisonResult,
  Station,
  StationCostComparison,
} from '../shared/types'

/**
 * Estimate queue time based on charger occupancy ratio.
 * If 50% of chargers are occupied, assume ~10 min queue.
 * If 75% occupied, ~20 min. If 100%, ~30 min.
 */
function estimateQueue(station: Station): number {
  const total = station.chargers.length
  if (total === 0) return 30
  const occupied = station.chargers.filter(
    (c) => c.status === 'OCCUPIED' || c.status === 'MAINTENANCE',
  ).length
  const occupancyRatio = occupied / total

  if (occupancyRatio === 0) return 0
  if (occupancyRatio <= 0.25) return 5
  if (occupancyRatio <= 0.5) return 10
  if (occupancyRatio <= 0.75) return 20
  return 30
}

/**
 * Main comparison function.
 */
export function compareChargingCosts(input: CostComparisonInput): CostComparisonResult {
  const { vehicle, targetBatteryPercent, stations } = input

  // kWh needed to charge from current battery to target
  const kwhNeeded = Math.max(
    0,
    vehicle.batteryCapacity * ((targetBatteryPercent - vehicle.currentBattery) / 100),
  )

  // Build comparison for each compatible station
  const comparisons: StationCostComparison[] = stations
    .filter((s) =>
      s.status === 'APPROVED' &&
      s.chargers.some((c) =>
        vehicle.connectors.includes(c.connectorType) && c.status === 'AVAILABLE',
      ),
    )
    .map((station) => {
      // Pick the best available compatible charger (highest power)
      const charger = station.chargers
        .filter((c) =>
          vehicle.connectors.includes(c.connectorType) && c.status === 'AVAILABLE',
        )
        .sort((a, b) => b.powerKw - a.powerKw)[0]

      // Charging time (DC taper above 80%)
      const effectiveKw = targetBatteryPercent > 80
        ? charger.powerKw * 0.7
        : charger.powerKw
      const chargingMinutes = Math.max(5, Math.round((kwhNeeded / Math.max(effectiveKw, 1)) * 60))

      // Total cost
      let totalCost = 0
      let pricePerKwh = 0
      if (charger.pricingModel === 'PER_KWH') {
        pricePerKwh = charger.price
        totalCost = Math.round(kwhNeeded * charger.price)
      } else if (charger.pricingModel === 'PER_HOUR') {
        pricePerKwh = Math.round((charger.price / 60) * 100) / 100 // normalize to per-kWh equiv
        totalCost = Math.round((chargingMinutes / 60) * charger.price)
      } else {
        totalCost = charger.price
        pricePerKwh = Math.round((totalCost / Math.max(kwhNeeded, 1)) * 100) / 100
      }

      const queueMinutes = estimateQueue(station)
      const totalTimeMinutes = queueMinutes + chargingMinutes

      return {
        station,
        pricePerKwh,
        queueMinutes,
        chargingSpeedKw: charger.powerKw,
        totalCost,
        totalTimeMinutes,
        kwhNeeded: Math.round(kwhNeeded * 10) / 10,
        rating: station.rating,
        aiScore: 0, // filled below
        rank: 0,    // filled below
        isBestOverall: false,
      }
    })

  if (comparisons.length === 0) {
    return {
      comparisons: [],
      bestOverall: null,
      recommendation: 'No compatible charging stations found nearby. Try expanding your search radius.',
    }
  }

  // ── Normalize values for scoring ──
  const costs = comparisons.map((c) => c.totalCost)
  const times = comparisons.map((c) => c.totalTimeMinutes)
  const ratings = comparisons.map((c) => c.rating)
  const minCost = Math.min(...costs)
  const maxCost = Math.max(...costs)
  const minTime = Math.min(...times)
  const maxTime = Math.max(...times)
  const minRating = Math.min(...ratings, 0)
  const maxRating = Math.max(...ratings, 1)

  // ── AI Score: cost (40%) + time (40%) + rating (20%) ──
  comparisons.forEach((c) => {
    const costScore = maxCost === minCost ? 100 : ((maxCost - c.totalCost) / (maxCost - minCost)) * 100
    const timeScore = maxTime === minTime ? 100 : ((maxTime - c.totalTimeMinutes) / (maxTime - minTime)) * 100
    const ratingScore = maxRating === minRating ? 100 : ((c.rating - minRating) / (maxRating - minRating)) * 100
    c.aiScore = Math.round(costScore * 0.4 + timeScore * 0.4 + ratingScore * 0.2)
  })

  // ── Rank by AI score (desc) ──
  comparisons.sort((a, b) => b.aiScore - a.aiScore)
  comparisons.forEach((c, i) => {
    c.rank = i + 1
    if (i === 0) {
      c.isBestOverall = true
      // Compute savings vs most expensive + slowest
      c.moneySaved = maxCost - c.totalCost
      c.timeSaved = maxTime - c.totalTimeMinutes
    }
  })

  const best = comparisons[0]
  const recommendation = `⭐ Best Overall: ${best.station.name} — Save ₹${best.moneySaved ?? 0} and ${best.timeSaved ?? 0} min vs alternatives. AI score: ${best.aiScore}/100`

  return {
    comparisons,
    bestOverall: best,
    recommendation,
  }
}

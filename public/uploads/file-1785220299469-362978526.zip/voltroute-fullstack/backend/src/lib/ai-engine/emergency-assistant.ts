// ── AI Emergency Assistant ───────────────────────────────────────────
// Assesses risk based on current battery, distance to nearest station,
// and vehicle range. Provides actionable recommendations.

import { haversine } from './utils'
import type {
  EmergencyAssessment,
  EmergencyInput,
  EmergencyRisk,
  Station,
} from '../shared/types'
import { computeBatteryHealth } from './battery-predictor'

const RESERVE_PERCENT = 15 // never plan below this

/**
 * Main emergency assessment function.
 */
export function assessEmergency(input: EmergencyInput): EmergencyAssessment {
  const { vehicle, userLat, userLng, stations } = input

  // ── Compute usable range (with reserve + health) ──
  const healthFactor = computeBatteryHealth() / 100 // fresh battery if no history
  const usableRange = Math.round(
    vehicle.fullRange * (vehicle.currentBattery - RESERVE_PERCENT) / 100 * healthFactor,
  )

  // ── Find nearest compatible station ──
  const compatibleStations = stations
    .filter((s) =>
      s.status === 'APPROVED' &&
      s.chargers.some((c) =>
        vehicle.connectors.includes(c.connectorType) && c.status !== 'OFFLINE',
      ),
    )
    .map((s) => ({
      station: s,
      distance: haversine(userLat, userLng, s.lat, s.lng),
    }))
    .sort((a, b) => a.distance - b.distance)

  const nearest = compatibleStations[0] ?? null
  const distanceToNearest = nearest?.distance ?? Infinity

  // ── Reach probability ──
  let reachProbability = 0
  if (nearest) {
    if (distanceToNearest <= usableRange) {
      // Can reach — probability based on margin
      const margin = (usableRange - distanceToNearest) / usableRange
      reachProbability = Math.round(Math.min(98, 60 + margin * 38))
    } else {
      // Cannot reach — probability based on how close
      reachProbability = Math.round(Math.max(0, 100 - ((distanceToNearest - usableRange) / usableRange) * 100))
    }
  }

  // ── Risk level ──
  let risk: EmergencyRisk = 'LOW'
  if (vehicle.currentBattery < 10 || !nearest) {
    risk = 'CRITICAL'
  } else if (reachProbability < 30) {
    risk = 'CRITICAL'
  } else if (reachProbability < 50) {
    risk = 'HIGH'
  } else if (reachProbability < 75) {
    risk = 'MEDIUM'
  }

  // ── Alternative stations (next 2 nearest) ──
  const alternativeStations = compatibleStations
    .slice(1, 3)
    .map((s) => s.station)

  // ── Services (all available in our simulated world, but only recommend when needed) ──
  const needsAssistance = risk === 'HIGH' || risk === 'CRITICAL'
  const services: EmergencyAssessment['services'] = {
    towService: needsAssistance,
    roadsideAssistance: needsAssistance,
    batterySavingMode: risk !== 'LOW', // recommend for MEDIUM+
    shareLiveLocation: needsAssistance,
    emergencyContact: needsAssistance,
  }

  const nearbyFacilities: EmergencyAssessment['nearbyFacilities'] = {
    police: needsAssistance,
    hospital: needsAssistance,
  }

  // ── Recommendations ──
  const recommendations: string[] = []
  if (risk === 'CRITICAL') {
    recommendations.push('⚠️ Stop driving immediately. Battery critically low.')
    if (nearest) {
      recommendations.push(`Nearest station is ${Math.round(distanceToNearest)} km away — may not be reachable.`)
    }
    recommendations.push('Enable Battery Saving Mode to reduce power draw.')
    recommendations.push('Call roadside assistance for towing to nearest charger.')
    recommendations.push('Share your live location with an emergency contact.')
  } else if (risk === 'HIGH') {
    recommendations.push('Head directly to the nearest charging station.')
    recommendations.push(`Nearest station: ${nearest?.station.name ?? 'N/A'} (${Math.round(distanceToNearest)} km).`)
    recommendations.push('Reduce speed to 50-60 km/h to maximize range.')
    recommendations.push('Turn off AC and non-essential electronics.')
    recommendations.push('Enable Battery Saving Mode.')
  } else if (risk === 'MEDIUM') {
    recommendations.push(`Plan to charge soon. Nearest station: ${Math.round(distanceToNearest)} km.`)
    recommendations.push('Monitor battery closely. Avoid high-speed driving.')
  } else {
    recommendations.push('Battery level is healthy. No action needed.')
    recommendations.push(`Nearest station available at ${Math.round(distanceToNearest)} km if needed.`)
  }

  return {
    risk,
    reachProbability,
    nearestStation: nearest?.station ?? null,
    distanceToNearest: nearest ? Math.round(distanceToNearest) : 0,
    usableRange,
    alternativeStations,
    services,
    nearbyFacilities,
    recommendations,
  }
}

// ── AI Engine barrel ─────────────────────────────────────────────────
// Single import surface for the AI engine modules.

export { predictBattery, computeBatteryHealth } from './battery-predictor'
export { assessEmergency } from './emergency-assistant'
export { compareChargingCosts } from './cost-comparison'
export { planSmartTrip } from './trip-intelligence'

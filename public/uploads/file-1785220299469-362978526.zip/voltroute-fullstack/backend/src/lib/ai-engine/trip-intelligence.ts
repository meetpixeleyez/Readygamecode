// ── Smart Trip Intelligence ──────────────────────────────────────────
// Extends the route planner with break suggestions (lunch, coffee, rest)
// and combines charging stops with meal breaks when possible.

import { haversine } from './utils'
import { planRoute } from '../lib/route-planner'
import { computeBatteryHealth } from './battery-predictor'
import type {
  SmartTripPlan,
  TripIntelligenceInput,
  TripStop,
  Station,
  Vehicle,
} from '../shared/types'

const ROAD_FACTOR = 1.3
const AVG_SPEED = 60 // km/h

interface PlanTripParams {
  from: { address: string; lat: number; lng: number }
  to: { address: string; lat: number; lng: number }
  vehicle: Vehicle
  stations: Station[]
  reservePercent?: number
  targetChargePercent?: number
}

/**
 * Plan a smart trip with charging stops + breaks.
 * Uses the existing route-planner algorithm for charging stops,
 * then layers in lunch/coffee/rest breaks.
 */
export function planSmartTrip(input: TripIntelligenceInput): SmartTripPlan {
  const {
    from, to, vehicle, stations,
    departureTime,
    preferences = { lunchBreak: true, coffeeBreaks: true },
  } = input

  const warnings: string[] = []

  // 1. Get the base route plan (charging stops)
  const basePlan = planRoute({
    from, to, vehicle, stations,
    reservePercent: 15,
    targetChargePercent: 80,
  })

  // 2. Compute total driving distance + time
  const totalDistance = Math.round(
    haversine(from.lat, from.lng, to.lat, to.lng) * ROAD_FACTOR,
  )
  const drivingMinutes = Math.round((totalDistance / AVG_SPEED) * 60)

  // 3. Parse departure time
  const [depH, depM] = (departureTime ?? defaultDepartureTime()).split(':').map(Number)
  let currentTimeMin = depH * 60 + depM

  // 4. Build stops list
  const stops: TripStop[] = []

  // Origin
  stops.push({
    type: 'origin',
    name: from.address,
    arrivalTime: formatTime(currentTimeMin),
    durationMinutes: 0,
    batteryPercent: vehicle.currentBattery,
    description: `Starting with ${vehicle.currentBattery}% battery`,
  })

  // Distribute driving time across legs
  const chargingStops = basePlan.chargingStops
  const numLegs = chargingStops.length + 1
  const drivingPerLeg = Math.round(drivingMinutes / numLegs)

  let currentBattery = vehicle.currentBattery
  let totalChargingTime = 0
  let totalCost = 0
  let totalBreakTime = 0
  let drivingTimeAccumulated = 0

  for (let i = 0; i < chargingStops.length; i++) {
    const stop = chargingStops[i]

    // Drive to this charging stop
    currentTimeMin += drivingPerLeg
    drivingTimeAccumulated += drivingPerLeg
    currentBattery = stop.arrivalBattery

    // Check if it's lunch time (12:00-14:00) — combine charging with lunch
    const isLunchTime = currentTimeMin >= 720 && currentTimeMin <= 840
    const isCoffeeTime = (currentTimeMin >= 600 && currentTimeMin <= 660) || (currentTimeMin >= 900 && currentTimeMin <= 960)

    let breakType: TripStop['type'] = 'charging'
    let breakDuration = stop.chargingMinutes
    let description = `Charge from ${stop.arrivalBattery}% → ${stop.departureBattery}%`

    if (isLunchTime && preferences.lunchBreak) {
      // Combine charging with lunch — max of charging time or 45 min lunch
      breakType = 'lunch'
      breakDuration = Math.max(stop.chargingMinutes, 45)
      description = `Lunch break + charge from ${stop.arrivalBattery}% → ${stop.departureBattery}%`
    } else if (isCoffeeTime && preferences.coffeeBreaks) {
      breakType = 'coffee'
      breakDuration = Math.max(stop.chargingMinutes, 20)
      description = `Coffee break + charge from ${stop.arrivalBattery}% → ${stop.departureBattery}%`
    }

    stops.push({
      type: breakType,
      name: stop.station.name,
      address: `${stop.station.city}, ${stop.station.state}`,
      arrivalTime: formatTime(currentTimeMin),
      durationMinutes: breakDuration,
      batteryPercent: stop.arrivalBattery,
      cost: stop.estimatedCost,
      station: stop.station,
      description,
    })

    currentTimeMin += breakDuration
    totalChargingTime += stop.chargingMinutes
    totalBreakTime += breakDuration - stop.chargingMinutes
    totalCost += stop.estimatedCost
    currentBattery = stop.departureBattery
  }

  // Drive to destination
  currentTimeMin += drivingPerLeg
  drivingTimeAccumulated += drivingPerLeg

  // Compute final arrival battery
  const finalBatteryUsed = (totalDistance / Math.max(vehicle.fullRange, 1)) * 100 * (1 - computeBatteryHealth() / 100 + 1)
  const arrivalBattery = Math.max(0, Math.round(currentBattery - finalBatteryUsed / numLegs))

  // Add a rest stop if total driving > 4 hours and no lunch was inserted
  if (drivingTimeAccumulated > 240 && !stops.some((s) => s.type === 'lunch')) {
    // Insert a rest stop at the midpoint
    const midpoint = Math.floor(stops.length / 2)
    const restTime = currentTimeMin
    currentTimeMin += 15
    totalBreakTime += 15
    stops.splice(midpoint + 1, 0, {
      type: 'rest',
      name: 'Rest Stop',
      arrivalTime: formatTime(restTime),
      durationMinutes: 15,
      batteryPercent: stops[midpoint]?.batteryPercent,
      description: '15-min stretch break',
    })
  }

  // Destination
  stops.push({
    type: 'destination',
    name: to.address,
    arrivalTime: formatTime(currentTimeMin),
    durationMinutes: 0,
    batteryPercent: arrivalBattery,
    description: `Arrive with ${arrivalBattery}% battery`,
  })

  // Build itinerary for UI
  const itinerary = stops.map((stop) => ({
    time: stop.arrivalTime,
    title: stop.name,
    detail: stop.description ?? '',
    icon: iconForStopType(stop.type),
  }))

  // Warnings
  if (basePlan.warnings.length > 0) {
    warnings.push(...basePlan.warnings)
  }
  if (chargingStops.length === 0 && totalDistance > vehicle.fullRange * 0.7) {
    warnings.push('Long distance without charging stops — ensure your vehicle can make it on a single charge.')
  }

  return {
    stops,
    totalDistance,
    totalDuration: currentTimeMin - (depH * 60 + depM),
    totalDrivingTime: drivingTimeAccumulated,
    totalBreakTime,
    totalChargingTime,
    totalCost,
    arrivalBattery,
    warnings,
    itinerary,
  }
}

// ── Helpers ──────────────────────────────────────────────────────────

function formatTime(minutes: number): string {
  const h = Math.floor(minutes / 60) % 24
  const m = Math.round(minutes % 60)
  return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}`
}

function defaultDepartureTime(): string {
  const now = new Date()
  return `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`
}

function iconForStopType(type: TripStop['type']): string {
  switch (type) {
    case 'origin': return 'flag'
    case 'charging': return 'zap'
    case 'lunch': return 'utensils'
    case 'coffee': return 'coffee'
    case 'rest': return 'sofa'
    case 'destination': return 'map-pin'
    default: return 'circle'
  }
}

// Smart Route Planner - charging-aware route optimization
import { haversine } from './utils'
import type { Station, ChargingStop, PlannedTrip, Vehicle, Charger } from '../shared/types'

// Approximate driving distance factor (roads aren't straight)
const ROAD_FACTOR = 1.3
// Average driving speed on Indian highways (km/h)
const AVG_SPEED = 60

export interface RoutePlannerInput {
  from: { address: string; lat: number; lng: number }
  to: { address: string; lat: number; lng: number }
  vehicle: Vehicle
  stations: Station[]
  reservePercent?: number // safety buffer, default 15
  targetChargePercent?: number // charge to this % at each stop, default 80
  maxDetourKm?: number // max deviation from route to find chargers
}

// Generate intermediate points along a straight line between two coords
function interpolateRoute(
  from: { lat: number; lng: number },
  to: { lat: number; lng: number },
  numPoints = 30
): { lat: number; lng: number }[] {
  const points = []
  for (let i = 0; i <= numPoints; i++) {
    const t = i / numPoints
    points.push({
      lat: from.lat + (to.lat - from.lat) * t,
      lng: from.lng + (to.lng - from.lng) * t,
    })
  }
  return points
}

// Find stations within `maxDetourKm` of a given point
function findStationsNearPoint(
  point: { lat: number; lng: number },
  stations: Station[],
  maxDetourKm: number
): { station: Station; distance: number }[] {
  return stations
    .map(s => ({
      station: s,
      distance: haversine(point.lat, point.lng, s.lat, s.lng),
    }))
    .filter(x => x.distance <= maxDetourKm)
    .sort((a, b) => a.distance - b.distance)
}

// Find compatible charger for vehicle at station
function findCompatibleCharger(station: Station, vehicle: Vehicle): Charger | undefined {
  const vehicleConnectors = vehicle.connectors
  // Prefer DC fast first, then any compatible
  const dcChargers = station.chargers.filter(
    c => vehicleConnectors.includes(c.connectorType as any) &&
         c.chargerSpeed !== 'SLOW_AC' &&
         c.status === 'AVAILABLE'
  )
  if (dcChargers.length > 0) {
    // Pick highest power
    return dcChargers.sort((a, b) => b.powerKw - a.powerKw)[0]
  }
  // Fall back to AC
  return station.chargers.find(
    c => vehicleConnectors.includes(c.connectorType as any) && c.status === 'AVAILABLE'
  )
}

export function planRoute(input: RoutePlannerInput): PlannedTrip {
  const {
    from,
    to,
    vehicle,
    stations,
    reservePercent = 15,
    targetChargePercent = 80,
    maxDetourKm = 50,
  } = input

  const warnings: string[] = []
  const chargingStops: ChargingStop[] = []
  const routePolyline = interpolateRoute(from, to, 40)

  // Total direct distance
  const totalDirectKm = haversine(from.lat, from.lng, to.lat, to.lng) * ROAD_FACTOR
  const totalDuration = (totalDirectKm / AVG_SPEED) * 60 // minutes

  // Only consider approved stations with at least one compatible charger
  const usableStations = stations.filter(s =>
    s.status === 'APPROVED' &&
    s.chargers.some(c => vehicle.connectors.includes(c.connectorType as any))
  )

  // Walk along route, simulating battery drain
  let currentBattery = vehicle.currentBattery
  let currentPos = { lat: from.lat, lng: from.lng }
  let remainingKm = totalDirectKm
  const fullRange = vehicle.fullRange
  let totalChargingTime = 0
  let totalCost = 0
  let safetyCounter = 0
  const visitedStations = new Set<string>()

  while (remainingKm > 5 && safetyCounter < 10) {
    safetyCounter++
    // Calculate usable range from current battery (accounting for reserve)
    const usableRange = (fullRange * (currentBattery - reservePercent)) / 100
    if (usableRange >= remainingKm) {
      // We can reach destination
      break
    }

    // Need a charging stop. Compute stop point relative to CURRENT position
    // (not the original origin), at ~85% of usable range from here.
    const targetDistance = Math.max(usableRange * 0.85, 20)
    const legDirectKm = haversine(currentPos.lat, currentPos.lng, to.lat, to.lng) * ROAD_FACTOR
    const progressOnLeg = Math.min(targetDistance / Math.max(legDirectKm, 1), 0.95)
    const stopPoint = {
      lat: currentPos.lat + (to.lat - currentPos.lat) * progressOnLeg,
      lng: currentPos.lng + (to.lng - currentPos.lng) * progressOnLeg,
    }

    // Find candidate stations along the remaining leg — sample multiple points
    // from 30% of usable range up to the stop point.
    const candidates: { station: Station; distance: number; routeProgress: number }[] = []
    const seenStationIds = new Set<string>()
    const minProgressOnLeg = Math.max(0.05, (usableRange * 0.3) / Math.max(legDirectKm, 1))
    const numSamples = 8
    for (let i = 0; i <= numSamples; i++) {
      const t = minProgressOnLeg + (progressOnLeg - minProgressOnLeg) * (i / numSamples)
      const samplePoint = {
        lat: currentPos.lat + (to.lat - currentPos.lat) * t,
        lng: currentPos.lng + (to.lng - currentPos.lng) * t,
      }
      const nearby = findStationsNearPoint(samplePoint, usableStations, maxDetourKm)
      for (const n of nearby) {
        if (visitedStations.has(n.station.id) || seenStationIds.has(n.station.id)) continue
        seenStationIds.add(n.station.id)
        // routeProgress is relative to the WHOLE route (for cost calc later)
        const wholeRouteProgress = (haversine(from.lat, from.lng, n.station.lat, n.station.lng) * ROAD_FACTOR) / totalDirectKm
        candidates.push({ ...n, routeProgress: wholeRouteProgress })
      }
    }

    // Also check at the exact stop point with widened radius
    if (candidates.length === 0) {
      const widerCandidates = findStationsNearPoint(stopPoint, usableStations, maxDetourKm * 3)
        .filter(c => !visitedStations.has(c.station.id))
      if (widerCandidates.length === 0) {
        warnings.push(
          `No compatible charging station found within ${(maxDetourKm * 3).toFixed(0)}km of route at ~${targetDistance.toFixed(0)}km from last position. Vehicle cannot complete this route safely. Consider adding more vehicles or stations.`
        )
        break
      }
      candidates.push(...widerCandidates.map(c => ({
        ...c,
        routeProgress: (haversine(from.lat, from.lng, c.station.lat, c.station.lng) * ROAD_FACTOR) / totalDirectKm,
      })))
    }

    // Pick best candidate: prefer one with DC fast charger, available now, highest rating
    const ranked = candidates.sort((a, b) => {
      const aHasDc = a.station.chargers.some(c => c.chargerSpeed !== 'SLOW_AC' && vehicle.connectors.includes(c.connectorType as any)) ? 0 : 1
      const bHasDc = b.station.chargers.some(c => c.chargerSpeed !== 'SLOW_AC' && vehicle.connectors.includes(c.connectorType as any)) ? 0 : 1
      if (aHasDc !== bHasDc) return aHasDc - bHasDc
      // Prefer available stations
      const aAvail = a.station.chargers.filter(c => c.status === 'AVAILABLE').length
      const bAvail = b.station.chargers.filter(c => c.status === 'AVAILABLE').length
      if (aAvail !== bAvail) return bAvail - aAvail
      return a.distance - b.distance
    })

    const chosen = ranked[0]
    visitedStations.add(chosen.station.id)
    const charger = findCompatibleCharger(chosen.station, vehicle)

    if (!charger) continue

    // Calculate arrival battery — distance from current position to station
    // along route, plus detour distance off the route
    const detourKm = chosen.distance
    const kmToStationDirect = haversine(currentPos.lat, currentPos.lng, chosen.station.lat, chosen.station.lng) * ROAD_FACTOR
    const kmToStation = kmToStationDirect + detourKm
    const batteryUsed = (kmToStation / fullRange) * 100
    const arrivalBattery = Math.max(currentBattery - batteryUsed, reservePercent)

    // Estimate charging time to reach target %
    const kwhNeeded = vehicle.batteryCapacity * ((targetChargePercent - arrivalBattery) / 100)
    const effectiveKw = targetChargePercent > 80 ? charger.powerKw * 0.7 : charger.powerKw
    const chargingMinutes = Math.max(10, Math.round((kwhNeeded / Math.max(effectiveKw, 1)) * 60))

    // Calculate cost
    let cost = 0
    if (charger.pricingModel === 'PER_KWH') {
      cost = Math.round(kwhNeeded * charger.price)
    } else if (charger.pricingModel === 'PER_HOUR') {
      cost = Math.round((chargingMinutes / 60) * charger.price)
    } else {
      cost = charger.price
    }

    chargingStops.push({
      station: chosen.station,
      charger,
      arrivalBattery: Math.round(arrivalBattery),
      departureBattery: targetChargePercent,
      chargingMinutes,
      detourKm: Math.round(detourKm * 2) / 2,
      estimatedCost: cost,
    })

    totalChargingTime += chargingMinutes
    totalCost += cost
    currentBattery = targetChargePercent
    currentPos = { lat: chosen.station.lat, lng: chosen.station.lng }
    remainingKm = haversine(currentPos.lat, currentPos.lng, to.lat, to.lng) * ROAD_FACTOR
  }

  // Check if we can reach destination with current battery
  const finalUsableRange = (fullRange * (currentBattery - reservePercent)) / 100
  if (remainingKm > finalUsableRange && warnings.length === 0) {
    warnings.push(
      `Your vehicle cannot reach the destination even with ${chargingStops.length} charging stop(s). Nearest reachable point is ~${finalUsableRange.toFixed(0)}km from last stop, but destination is ${remainingKm.toFixed(0)}km away. Consider adding more stops manually.`
    )
  }

  return {
    fromAddress: from.address,
    toAddress: to.address,
    fromLat: from.lat,
    fromLng: from.lng,
    toLat: to.lat,
    toLng: to.lng,
    totalDistance: Math.round(totalDirectKm),
    totalDuration: Math.round(totalDuration + totalChargingTime),
    totalChargingTime,
    totalCost,
    chargingStops,
    routePolyline,
    warnings,
  }
}

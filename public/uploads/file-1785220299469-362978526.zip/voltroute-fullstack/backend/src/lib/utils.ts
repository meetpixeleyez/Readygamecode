import { type ClassValue, clsx } from "clsx"
import { twMerge } from "tailwind-merge"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

// Haversine distance between two lat/lng points in km
export function haversine(lat1: number, lng1: number, lat2: number, lng2: number): number {
  const R = 6371
  const dLat = ((lat2 - lat1) * Math.PI) / 180
  const dLng = ((lng2 - lng1) * Math.PI) / 180
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos((lat1 * Math.PI) / 180) * Math.cos((lat2 * Math.PI) / 180) *
    Math.sin(dLng / 2) * Math.sin(dLng / 2)
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a))
  return R * c
}

export function formatINR(amount: number): string {
  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    maximumFractionDigits: 0,
  }).format(amount)
}

export function formatKm(km: number): string {
  if (km < 1) return `${Math.round(km * 1000)} m`
  return `${km.toFixed(1)} km`
}

export function formatDuration(minutes: number): string {
  if (minutes < 60) return `${Math.round(minutes)} min`
  const h = Math.floor(minutes / 60)
  const m = Math.round(minutes % 60)
  return m > 0 ? `${h}h ${m}m` : `${h}h`
}

export function formatDateTime(iso: string): string {
  const d = new Date(iso)
  return d.toLocaleString('en-IN', {
    day: '2-digit',
    month: 'short',
    hour: '2-digit',
    minute: '2-digit',
    hour12: true,
  })
}

export function formatTime(iso: string): string {
  const d = new Date(iso)
  return d.toLocaleTimeString('en-IN', {
    hour: '2-digit',
    minute: '2-digit',
    hour12: true,
  })
}

export function formatDate(iso: string): string {
  const d = new Date(iso)
  return d.toLocaleDateString('en-IN', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
  })
}

export function timeUntil(iso: string): string {
  const now = Date.now()
  const then = new Date(iso).getTime()
  const diff = then - now
  if (diff < 0) return 'Past'
  const mins = Math.floor(diff / 60000)
  if (mins < 60) return `in ${mins} min`
  const hours = Math.floor(mins / 60)
  if (hours < 24) return `in ${hours}h ${mins % 60}m`
  const days = Math.floor(hours / 24)
  return `in ${days}d`
}

// Generate a simple QR-like code string (not real QR, just unique token)
export function generateQrToken(): string {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'
  let result = 'EV-'
  for (let i = 0; i < 12; i++) {
    result += chars.charAt(Math.floor(Math.random() * chars.length))
  }
  return result
}

// Calculate estimated charging time in minutes
export function estimateChargingTime(
  batteryKwh: number,
  fromPercent: number,
  toPercent: number,
  chargerKw: number
): number {
  const kwhNeeded = batteryKwh * ((toPercent - fromPercent) / 100)
  // DC fast charging slows down after 80%
  const effectiveKw = toPercent > 80 && fromPercent < 80
    ? chargerKw * 0.7
    : chargerKw
  const hours = kwhNeeded / Math.max(effectiveKw, 0.5)
  return Math.max(5, Math.round(hours * 60))
}

// Calculate estimated cost
export function estimateCost(
  charger: { pricingModel: string; price: number; powerKw: number },
  batteryKwh: number,
  fromPercent: number,
  toPercent: number,
  slotMinutes: number
): number {
  if (charger.pricingModel === 'PER_KWH') {
    const kwh = batteryKwh * ((toPercent - fromPercent) / 100)
    return Math.round(kwh * charger.price)
  } else if (charger.pricingModel === 'PER_HOUR') {
    return Math.round((slotMinutes / 60) * charger.price)
  } else {
    return charger.price
  }
}

export function getInitials(name: string): string {
  return name
    .split(' ')
    .map(n => n[0])
    .slice(0, 2)
    .join('')
    .toUpperCase()
}

// ── Admin service: platform-wide stats, approvals, moderation ────────

import { db } from '../prisma/prisma.service'

export async function getAdminOverview() {
  const [
    totalUsers, totalOwners, totalStations, pendingStations,
    totalBookings, totalRevenue, totalChargers,
  ] = await Promise.all([
    db.user.count({ where: { role: 'USER' } }),
    db.user.count({ where: { role: 'OWNER' } }),
    db.station.count(),
    db.station.count({ where: { status: 'PENDING' } }),
    db.booking.count(),
    db.booking.aggregate({ where: { paymentStatus: 'PAID' }, _sum: { amount: true } }),
    db.charger.count(),
  ])

  const recentStations = await db.station.findMany({
    where: { status: 'PENDING' },
    include: { chargers: true, owner: { select: { name: true, email: true } } },
    orderBy: { createdAt: 'desc' },
  })

  const recentBookings = await db.booking.findMany({
    take: 10,
    orderBy: { createdAt: 'desc' },
    include: { station: true, user: { select: { name: true } } },
  })

  return {
    stats: {
      totalUsers, totalOwners, totalStations, pendingStations,
      totalBookings, totalChargers,
      totalRevenue: totalRevenue._sum.amount ?? 0,
    },
    pendingStations: recentStations.map((s) => ({
      ...s,
      amenities: s.amenities.split(','),
    })),
    recentBookings: recentBookings.map((b) => ({
      ...b,
      station: { ...b.station, amenities: b.station.amenities.split(',') },
    })),
  }
}

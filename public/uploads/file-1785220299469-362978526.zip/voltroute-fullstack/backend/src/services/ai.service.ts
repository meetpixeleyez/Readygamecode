// ── AI service: wraps the AI engine with DB access ───────────────────
// Loads stations / booking history needed for predictions.

import { db } from '../prisma/prisma.service'
import {
  predictBattery,
  assessEmergency,
  compareChargingCosts,
  planSmartTrip,
} from '../lib/ai-engine'
import type {
  BatteryPredictorInput,
  EmergencyInput,
  CostComparisonInput,
  TripIntelligenceInput,
  Vehicle,
} from '../shared/types'

function formatVehicle(v: any): Vehicle {
  return {
    ...v,
    connectors: Array.isArray(v.connectors) ? v.connectors : v.connectors.split(','),
  }
}

async function loadStations(): Promise<any[]> {
  const stations = await db.station.findMany({
    where: { status: 'APPROVED' },
    include: { chargers: true },
  })
  return stations.map((s) => ({
    ...s,
    amenities: s.amenities.split(','),
    chargers: s.chargers.map((c) => ({ ...c })),
  }))
}

async function countFastCharges(userId: string): Promise<number> {
  const bookings = await db.booking.findMany({
    where: {
      userId,
      status: 'COMPLETED',
      charger: { chargerSpeed: { not: 'SLOW_AC' } },
    },
    include: { charger: true },
  })
  return bookings.length
}

export async function runBatteryPrediction(
  input: Omit<BatteryPredictorInput, 'nearbyStations' | 'fastChargeCount'> & {
    userId?: string
    userLat?: number
    userLng?: number
  },
) {
  const stations = await loadStations()
  const fastChargeCount = input.userId ? await countFastCharges(input.userId) : 0

  // If user location provided, filter nearby stations (within 50km)
  let nearbyStations = stations
  if (input.userLat && input.userLng) {
    const { haversine } = await import('@/lib/utils')
    nearbyStations = stations
      .map((s) => ({
        ...s,
        _dist: haversine(input.userLat!, input.userLng!, s.lat, s.lng),
      }))
      .filter((s) => s._dist <= 50)
      .sort((a, b) => (a as any)._dist - (b as any)._dist)
  }

  return predictBattery({
    ...input,
    nearbyStations,
    fastChargeCount,
  })
}

export async function runEmergencyAssessment(input: Omit<EmergencyInput, 'stations'>) {
  const stations = await loadStations()
  return assessEmergency({ ...input, stations })
}

export async function runCostComparison(input: Omit<CostComparisonInput, 'stations'>) {
  const stations = await loadStations()
  return compareChargingCosts({ ...input, stations })
}

export async function runTripIntelligence(input: Omit<TripIntelligenceInput, 'stations'>) {
  const stations = await loadStations()
  return planSmartTrip({ ...input, stations })
}

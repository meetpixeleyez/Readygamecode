// ── Booking service: create, list, cancel, reschedule, complete ──────

import { db } from '../prisma/prisma.service'
import { generateQrToken } from '../lib/utils'
import type { Booking, PaymentMethod } from '../shared/types'

// ───────────────────────────────────────────────────────────────────────
//  Reads
// ───────────────────────────────────────────────────────────────────────

export async function getBookingsByUser(userId: string): Promise<Booking[]> {
  const bookings = await db.booking.findMany({
    where: { userId },
    include: {
      station: { include: { chargers: true } },
      charger: true,
      vehicle: true,
    },
    orderBy: { slotStart: 'desc' },
  })
  return bookings.map((b) => ({
    ...b,
    station: {
      ...b.station,
      amenities: b.station.amenities.split(','),
      chargers: b.station.chargers.map((c) => ({ ...c })),
    },
    vehicle: {
      ...b.vehicle,
      connectors: b.vehicle.connectors.split(','),
    },
  })) as Booking[]
}

// ───────────────────────────────────────────────────────────────────────
//  Pricing / compatibility helpers (shared by all create paths)
// ───────────────────────────────────────────────────────────────────────

interface BookingInput {
  userId: string
  stationId: string
  chargerId: string
  vehicleId: string
  slotStart: string // ISO
  slotEnd: string   // ISO
}

async function validateAndPrice(input: BookingInput): Promise<
  | { error: string }
  | {
      user: { id: string; walletBalance: number }
      charger: NonNullable<Awaited<ReturnType<typeof db.charger.findUnique>>>
      vehicle: NonNullable<Awaited<ReturnType<typeof db.vehicle.findUnique>>>
      start: Date
      end: Date
      slotMinutes: number
      estimatedKwh: number
      amount: number
    }
> {
  const { userId, stationId, chargerId, vehicleId, slotStart, slotEnd } = input

  const charger = await db.charger.findUnique({ where: { id: chargerId } })
  const vehicle = await db.vehicle.findUnique({ where: { id: vehicleId } })
  const user = await db.user.findUnique({ where: { id: userId } })

  if (!charger || !vehicle || !user) return { error: 'Invalid references' }
  if (charger.stationId !== stationId) return { error: 'Charger does not belong to station' }

  // Connector compatibility check
  const vehicleConnectors = vehicle.connectors.split(',')
  if (!vehicleConnectors.includes(charger.connectorType)) {
    return {
      error: `Connector mismatch: vehicle supports ${vehicleConnectors.join(', ')} but charger is ${charger.connectorType}`,
    }
  }

  // Double-booking check (slot lock)
  const start = new Date(slotStart)
  const end = new Date(slotEnd)
  const conflict = await db.booking.findFirst({
    where: {
      chargerId,
      status: { in: ['UPCOMING', 'ONGOING'] },
      slotStart: { lte: end },
      slotEnd: { gte: start },
    },
  })
  if (conflict) {
    return { error: 'This slot was just booked by another user. Please choose a different time.' }
  }

  // Estimate kWh and amount
  const slotMinutes = (end.getTime() - start.getTime()) / 60000
  const fromPercent = vehicle.currentBattery
  const toPercent = Math.min(95, fromPercent + (charger.powerKw * (slotMinutes / 60) / vehicle.batteryCapacity) * 100)
  const estimatedKwh = vehicle.batteryCapacity * ((toPercent - fromPercent) / 100)

  let amount = 0
  if (charger.pricingModel === 'PER_KWH') {
    amount = Math.round(estimatedKwh * charger.price)
  } else if (charger.pricingModel === 'PER_HOUR') {
    amount = Math.round((slotMinutes / 60) * charger.price)
  } else {
    amount = charger.price
  }

  return { user, charger, vehicle, start, end, slotMinutes, estimatedKwh, amount }
}

async function persistBooking(args: {
  userId: string
  stationId: string
  chargerId: string
  vehicleId: string
  start: Date
  end: Date
  amount: number
  estimatedKwh: number
  pricingModel: string
  paymentStatus: 'PENDING' | 'PAID'
  paymentMethod: PaymentMethod
}): Promise<Booking> {
  const booking = await db.booking.create({
    data: {
      userId: args.userId,
      stationId: args.stationId,
      chargerId: args.chargerId,
      vehicleId: args.vehicleId,
      status: 'UPCOMING',
      slotStart: args.start,
      slotEnd: args.end,
      amount: args.amount,
      pricingModel: args.pricingModel as any,
      estimatedKwh: args.estimatedKwh,
      paymentStatus: args.paymentStatus,
      paymentMethod: args.paymentMethod,
      qrCode: generateQrToken(),
    },
    include: {
      station: { include: { chargers: true } },
      charger: true,
      vehicle: true,
    },
  })

  return {
    ...booking,
    station: {
      ...booking.station,
      amenities: booking.station.amenities.split(','),
      chargers: booking.station.chargers.map((c) => ({ ...c })),
    },
    vehicle: {
      ...booking.vehicle,
      connectors: booking.vehicle.connectors.split(','),
    },
  } as Booking
}

// ───────────────────────────────────────────────────────────────────────
//  Create paths
// ───────────────────────────────────────────────────────────────────────

interface CreateBookingInput extends BookingInput {
  paymentMethod: PaymentMethod
}

/**
 * Direct booking creation for WALLET and PAY_AT_STATION.
 * UPI / CARD must go through Razorpay — see createBookingAfterRazorpayPayment().
 */
export async function createBooking(
  input: CreateBookingInput,
): Promise<{ booking: Booking } | { error: string }> {
  const { paymentMethod } = input
  const validated = await validateAndPrice(input)
  if ('error' in validated) return { error: validated.error }

  const { user, charger, start, end, estimatedKwh, amount } = validated

  if (paymentMethod === 'WALLET') {
    if (user.walletBalance < amount) return { error: 'Insufficient wallet balance' }
    await db.user.update({
      where: { id: user.id },
      data: { walletBalance: { decrement: amount } },
    })
    await db.transaction.create({
      data: { userId: user.id, type: 'DEBIT', amount, reason: 'BOOKING_PAYMENT' },
    })
    const booking = await persistBooking({
      userId: user.id, stationId: input.stationId, chargerId: input.chargerId,
      vehicleId: input.vehicleId, start, end, amount, estimatedKwh,
      pricingModel: charger.pricingModel, paymentStatus: 'PAID', paymentMethod,
    })
    return { booking }
  }

  if (paymentMethod === 'PAY_AT_STATION') {
    const booking = await persistBooking({
      userId: user.id, stationId: input.stationId, chargerId: input.chargerId,
      vehicleId: input.vehicleId, start, end, amount, estimatedKwh,
      pricingModel: charger.pricingModel, paymentStatus: 'PENDING', paymentMethod,
    })
    return { booking }
  }

  // UPI / CARD → must go through Razorpay
  return {
    error: 'UPI / Card payments must go through Razorpay checkout. Use /api/payments/create-order then /api/payments/verify.',
  }
}

/**
 * Compute the booking amount for a given input WITHOUT creating the booking.
 * Used by /api/payments/create-order so the client knows how much to charge.
 */
export async function computeBookingAmount(
  input: BookingInput,
): Promise<{ amount: number } | { error: string }> {
  const validated = await validateAndPrice(input)
  if ('error' in validated) return { error: validated.error }
  return { amount: validated.amount }
}

/**
 * Create a booking AFTER Razorpay signature has been verified.
 * Re-runs validation + conflict check to defend against race conditions
 * (e.g. someone else booked the slot while the user was paying).
 */
export async function createBookingAfterRazorpayPayment(
  input: CreateBookingInput,
): Promise<{ booking: Booking } | { error: string }> {
  const { paymentMethod } = input
  if (paymentMethod !== 'UPI' && paymentMethod !== 'CARD') {
    return { error: 'This endpoint is for UPI / Card payments only' }
  }

  const validated = await validateAndPrice(input)
  if ('error' in validated) return { error: validated.error }

  const { user, charger, start, end, estimatedKwh, amount } = validated

  // Record the payment as a transaction (for ledger completeness).
  // Razorpay settlement → user wallet is NOT credited; this is just a record.
  await db.transaction.create({
    data: {
      userId: user.id,
      type: 'DEBIT',
      amount,
      reason: 'BOOKING_PAYMENT_RAZORPAY',
    },
  })

  const booking = await persistBooking({
    userId: user.id, stationId: input.stationId, chargerId: input.chargerId,
    vehicleId: input.vehicleId, start, end, amount, estimatedKwh,
    pricingModel: charger.pricingModel, paymentStatus: 'PAID', paymentMethod,
  })
  return { booking }
}

// ───────────────────────────────────────────────────────────────────────
//  Mutations
// ───────────────────────────────────────────────────────────────────────

export async function cancelBooking(id: string) {
  const booking = await db.booking.findUnique({ where: { id } })
  if (!booking) return { error: 'Booking not found' }

  // Refund logic — only wallet payments are auto-refunded in-app.
  // Razorpay refunds would need a separate /api/payments/refund flow
  // (calling razorpay.payments.refund) — out of scope for this integration.
  if (booking.paymentStatus === 'PAID' && booking.paymentMethod === 'WALLET') {
    await db.user.update({
      where: { id: booking.userId },
      data: { walletBalance: { increment: booking.amount } },
    })
    await db.transaction.create({
      data: {
        userId: booking.userId, type: 'CREDIT',
        amount: booking.amount, reason: 'REFUND', bookingId: booking.id,
      },
    })
  }
  const updated = await db.booking.update({
    where: { id },
    data: {
      status: 'CANCELLED',
      paymentStatus: booking.paymentMethod === 'WALLET' ? 'REFUNDED' : booking.paymentStatus,
    },
  })
  return { booking: updated }
}

export async function completeBooking(id: string) {
  const updated = await db.booking.update({
    where: { id },
    data: { status: 'COMPLETED' },
  })
  return { booking: updated }
}

export async function rescheduleBooking(id: string, slotStart: string, slotEnd: string) {
  const updated = await db.booking.update({
    where: { id },
    data: { slotStart: new Date(slotStart), slotEnd: new Date(slotEnd) },
  })
  return { booking: updated }
}

// ── Owner service: station CRUD + per-station analytics ──────────────

import { db } from '../prisma/prisma.service'
import type { ChargerStatus, ChargerSpeed, ConnectorType, PricingModel } from '../shared/types'

export async function getOwnerStations(ownerId: string) {
  const stations = await db.station.findMany({
    where: { ownerId },
    include: { chargers: true, bookings: { include: { user: true, vehicle: true } } },
    orderBy: { createdAt: 'desc' },
  })

  return stations.map((s) => {
    const now = new Date()
    const weekAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000)
    const recentBookings = s.bookings.filter((b) => b.createdAt > weekAgo)
    const revenue = recentBookings
      .filter((b) => b.paymentStatus === 'PAID')
      .reduce((sum, b) => sum + b.amount, 0)
    const totalSlots = s.chargers.length * 24
    const utilization = totalSlots > 0 ? (recentBookings.length / totalSlots) * 100 : 0
    return {
      ...s,
      amenities: s.amenities.split(','),
      recentBookingCount: recentBookings.length,
      weeklyRevenue: revenue,
      utilization: Math.round(utilization),
    }
  })
}

interface CreateStationInput {
  ownerId: string
  name: string
  description?: string
  state: string
  city: string
  address: string
  lat: number
  lng: number
  open24x7: boolean
  operatingHours?: string
  amenities: string[]
  chargers: Array<{
    label: string
    connectorType: ConnectorType
    powerKw: number
    chargerSpeed: ChargerSpeed
    pricingModel: PricingModel
    price: number
  }>
}

export async function createStation(input: CreateStationInput) {
  return db.station.create({
    data: {
      ownerId: input.ownerId,
      name: input.name,
      description: input.description || null,
      state: input.state, city: input.city, address: input.address,
      lat: Number(input.lat), lng: Number(input.lng),
      open24x7: Boolean(input.open24x7),
      operatingHours: input.operatingHours || null,
      amenities: (input.amenities || []).join(','),
      status: 'PENDING',
      rating: 0, reviewCount: 0,
      chargers: input.chargers && input.chargers.length > 0 ? {
        create: input.chargers.map((c) => ({
          label: c.label,
          connectorType: c.connectorType,
          powerKw: Number(c.powerKw),
          chargerSpeed: c.chargerSpeed,
          pricingModel: c.pricingModel,
          price: Number(c.price),
          status: 'AVAILABLE' satisfies ChargerStatus,
        })),
      } : undefined,
    },
    include: { chargers: true },
  })
}

export async function toggleChargerStatus(chargerId: string, status: ChargerStatus) {
  return db.charger.update({ where: { id: chargerId }, data: { status } })
}

export async function approveStation(id: string) {
  return db.station.update({ where: { id }, data: { status: 'APPROVED' } })
}

export async function suspendStation(id: string) {
  return db.station.update({ where: { id }, data: { status: 'SUSPENDED' } })
}

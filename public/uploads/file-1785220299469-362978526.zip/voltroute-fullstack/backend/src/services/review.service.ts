// ── Review service: list, create (verified booking only) ─────────────

import { db } from '../prisma/prisma.service'
import type { Review } from '../shared/types'

export async function getReviewsByStation(stationId: string): Promise<Review[]> {
  const reviews = await db.review.findMany({
    where: { stationId },
    include: { user: { select: { name: true } } },
    orderBy: { createdAt: 'desc' },
  })
  return reviews.map((r) => ({
    ...r,
    tags: r.tags ? r.tags.split(',') : [],
  })) as Review[]
}

interface CreateReviewInput {
  userId: string
  stationId: string
  bookingId?: string | null
  rating: number
  comment?: string
  tags?: string[]
}

export async function createReview(input: CreateReviewInput): Promise<{ review: Review } | { error: string }> {
  const { userId, stationId, bookingId, rating, comment, tags } = input

  if (bookingId) {
    const booking = await db.booking.findUnique({ where: { id: bookingId } })
    if (!booking || booking.userId !== userId || booking.stationId !== stationId) {
      return { error: 'Verified booking required to review' }
    }
  }

  const review = await db.review.create({
    data: {
      userId, stationId, bookingId: bookingId ?? null,
      rating: Number(rating),
      comment: comment || null,
      tags: tags ? tags.join(',') : null,
    },
    include: { user: { select: { name: true } } },
  })

  // Update station aggregate rating
  const allReviews = await db.review.findMany({ where: { stationId } })
  const avg = allReviews.reduce((sum, r) => sum + r.rating, 0) / allReviews.length
  await db.station.update({
    where: { id: stationId },
    data: { rating: Math.round(avg * 10) / 10, reviewCount: allReviews.length },
  })

  return {
    review: {
      ...review,
      tags: review.tags ? review.tags.split(',') : [],
    } as Review,
  }
}

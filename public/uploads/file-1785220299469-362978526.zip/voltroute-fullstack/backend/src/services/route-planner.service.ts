// ── Route planner service: charging-aware trip planning ──────────────
// Wraps the pure planning algorithm with DB access (load approved stations).

import { db } from '../prisma/prisma.service'
import { planRoute } from '../lib/route-planner'
import type { PlannedTrip, Vehicle } from '../shared/types'

interface PlanRouteInput {
  from: { address: string; lat: number; lng: number }
  to: { address: string; lat: number; lng: number }
  vehicle: Vehicle
  reservePercent?: number
  targetChargePercent?: number
}

export async function planTrip(input: PlanRouteInput): Promise<PlannedTrip> {
  const stations = await db.station.findMany({
    where: { status: 'APPROVED' },
    include: { chargers: true },
  })

  const formattedStations = stations.map((s) => ({
    ...s,
    amenities: s.amenities.split(','),
    chargers: s.chargers.map((c) => ({ ...c })),
  }))

  return planRoute({
    from: input.from,
    to: input.to,
    vehicle: input.vehicle,
    stations: formattedStations as any,
    reservePercent: input.reservePercent,
    targetChargePercent: input.targetChargePercent,
  })
}

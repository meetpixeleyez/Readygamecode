// ── Station service: search, filter, fetch by id ─────────────────────
// Pure business logic — no Next.js Request/Response. Imported by route handlers.

import { db } from '../prisma/prisma.service'
import { haversine } from '../lib/utils'
import type { Station, StationFilters } from '../shared/types'

export async function searchStations(filters: StationFilters = {}): Promise<Station[]> {
  let stations = await db.station.findMany({
    where: { status: 'APPROVED' },
    include: { chargers: true },
    orderBy: { rating: 'desc' },
  })

  stations = stations.filter((s) => {
    if (filters.search) {
      const q = filters.search.toLowerCase()
      const matches =
        s.name.toLowerCase().includes(q) ||
        s.city.toLowerCase().includes(q) ||
        s.state.toLowerCase().includes(q) ||
        s.address.toLowerCase().includes(q)
      if (!matches) return false
    }
    if (filters.state && s.state !== filters.state) return false
    if (filters.city && s.city !== filters.city) return false
    if (filters.connectors && filters.connectors.length > 0) {
      const has = s.chargers.some((c) => filters.connectors!.includes(c.connectorType as any))
      if (!has) return false
    }
    if (filters.speeds && filters.speeds.length > 0) {
      const has = s.chargers.some((c) => filters.speeds!.includes(c.chargerSpeed as any))
      if (!has) return false
    }
    if (filters.availableNow) {
      const has = s.chargers.some((c) => c.status === 'AVAILABLE')
      if (!has) return false
    }
    if (filters.openNow) {
      const open = s.open24x7 || (s.operatingHours && isCurrentlyOpen(s.operatingHours))
      if (!open) return false
    }
    if (filters.minRating && s.rating < filters.minRating) return false
    if (filters.amenities && filters.amenities.length > 0) {
      const stationAmenities = s.amenities.split(',')
      const has = filters.amenities.every((a) => stationAmenities.includes(a))
      if (!has) return false
    }
    return true
  })

  let result: Station[] = stations.map((s) => ({
    ...s,
    amenities: s.amenities.split(','),
    chargers: s.chargers.map((c) => ({ ...c })),
    distance:
      filters.userLat && filters.userLng
        ? haversine(filters.userLat, filters.userLng, s.lat, s.lng)
        : undefined,
  }))

  if (filters.radius && filters.userLat && filters.userLng) {
    result = result.filter((s) => (s.distance ?? 0) <= filters.radius!)
  }

  if (filters.userLat && filters.userLng) {
    result.sort((a, b) => (a.distance ?? 0) - (b.distance ?? 0))
  }

  return result
}

export async function getStationById(id: string) {
  const station = await db.station.findUnique({
    where: { id },
    include: {
      chargers: true,
      reviews: {
        include: { user: { select: { name: true } } },
        orderBy: { createdAt: 'desc' },
        take: 10,
      },
    },
  })
  if (!station) return null
  return {
    ...station,
    amenities: station.amenities.split(','),
    reviews: station.reviews.map((r) => ({
      ...r,
      tags: r.tags ? r.tags.split(',') : [],
    })),
  }
}

function isCurrentlyOpen(hours: string): boolean {
  try {
    const [start, end] = hours.split('-')
    const now = new Date()
    const nowMins = now.getHours() * 60 + now.getMinutes()
    const [sh, sm] = start.split(':').map(Number)
    const [eh, em] = end.split(':').map(Number)
    const startMins = sh * 60 + sm
    const endMins = eh * 60 + em
    return nowMins >= startMins && nowMins <= endMins
  } catch {
    return true
  }
}

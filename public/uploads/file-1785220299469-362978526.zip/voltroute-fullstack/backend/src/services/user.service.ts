// ── User service: profile, preferences, role ─────────────────────────

import { db } from '../prisma/prisma.service'
import { DEFAULT_PREFERENCES } from '../shared/types'
import type { Role, User, UserPreferences } from '../shared/types'

const DEMO_EMAIL = 'demo@ev.app'

export async function getDemoUser(): Promise<User | null> {
  const user = await db.user.findFirst({ where: { email: DEMO_EMAIL } })
  if (!user) return null
  const vehicles = await db.vehicle.findMany({ where: { userId: user.id } })

  let preferences: UserPreferences = DEFAULT_PREFERENCES
  if (user.preferences) {
    try {
      preferences = { ...DEFAULT_PREFERENCES, ...JSON.parse(user.preferences) }
    } catch {
      // fall back to defaults
    }
  }

  return {
    ...user,
    preferences,
    vehicles: vehicles.map((v) => ({
      ...v,
      connectors: v.connectors.split(','),
    })) as any,
  }
}

interface UpdateUserInput {
  name?: string
  phone?: string
  avatarUrl?: string
  role?: Role
  preferences?: Partial<UserPreferences>
}

export async function updateDemoUser(input: UpdateUserInput): Promise<User | null> {
  const user = await db.user.findFirst({ where: { email: DEMO_EMAIL } })
  if (!user) return null

  const data: any = {}
  if (typeof input.name === 'string' && input.name.trim()) data.name = input.name.trim()
  if (typeof input.phone === 'string') data.phone = input.phone.trim() || null
  if (typeof input.avatarUrl === 'string') data.avatarUrl = input.avatarUrl.trim() || null
  if (typeof input.role === 'string' && ['USER', 'OWNER', 'ADMIN'].includes(input.role)) {
    data.role = input.role
  }
  if (input.preferences && typeof input.preferences === 'object') {
    const current: UserPreferences = user.preferences
      ? { ...DEFAULT_PREFERENCES, ...JSON.parse(user.preferences) }
      : DEFAULT_PREFERENCES
    data.preferences = JSON.stringify({ ...current, ...input.preferences })
  }

  const updated = await db.user.update({ where: { id: user.id }, data })

  let pref: UserPreferences = DEFAULT_PREFERENCES
  if (updated.preferences) {
    try {
      pref = { ...DEFAULT_PREFERENCES, ...JSON.parse(updated.preferences) }
    } catch {}
  }
  return { ...updated, preferences: pref }
}

// ── Stats / activity / achievements ──────────────────────────────────

export interface UserStats {
  totalBookings: number
  completedBookings: number
  upcomingBookings: number
  cancelledBookings: number
  totalSpent: number
  totalKwh: number
  vehiclesCount: number
  reviewsCount: number
  tripsCount: number
  favoriteStation: { name: string; city: string; count: number } | null
  memberSince: string
  walletBalance: number
}

export interface Achievement {
  id: string
  title: string
  description: string
  icon: string
  unlocked: boolean
  progress?: number
}

export interface ActivityItem {
  type: string
  title: string
  subtitle: string
  timestamp: string
  icon: string
}

export async function getUserStats(): Promise<{
  stats: UserStats
  achievements: Achievement[]
  activity: ActivityItem[]
} | null> {
  const user = await db.user.findFirst({ where: { email: DEMO_EMAIL } })
  if (!user) return null

  const [bookings, transactions, vehicles, reviews, trips] = await Promise.all([
    db.booking.findMany({
      where: { userId: user.id },
      include: { station: true, charger: true },
    }),
    db.transaction.findMany({ where: { userId: user.id } }),
    db.vehicle.findMany({ where: { userId: user.id } }),
    db.review.findMany({ where: { userId: user.id } }),
    db.trip.findMany({ where: { userId: user.id } }),
  ])

  const completed = bookings.filter((b) => b.status === 'COMPLETED')
  const upcoming = bookings.filter((b) => b.status === 'UPCOMING')
  const cancelled = bookings.filter((b) => b.status === 'CANCELLED')
  const totalSpent = bookings
    .filter((b) => b.paymentStatus === 'PAID')
    .reduce((s, b) => s + b.amount, 0)
  const totalKwh = completed.reduce((s, b) => s + b.estimatedKwh, 0)

  // Favorite station
  const stationCounts = new Map<string, { count: number; name: string; city: string }>()
  for (const b of bookings) {
    const cur = stationCounts.get(b.stationId)
    if (cur) cur.count++
    else stationCounts.set(b.stationId, { count: 1, name: b.station.name, city: b.station.city })
  }
  let favoriteStation: UserStats['favoriteStation'] = null
  for (const [_, v] of stationCounts) {
    if (!favoriteStation || v.count > favoriteStation.count) {
      favoriteStation = { name: v.name, city: v.city, count: v.count }
    }
  }

  const stats: UserStats = {
    totalBookings: bookings.length,
    completedBookings: completed.length,
    upcomingBookings: upcoming.length,
    cancelledBookings: cancelled.length,
    totalSpent,
    totalKwh: Math.round(totalKwh * 10) / 10,
    vehiclesCount: vehicles.length,
    reviewsCount: reviews.length,
    tripsCount: trips.length,
    favoriteStation,
    memberSince: user.createdAt.toISOString(),
    walletBalance: user.walletBalance,
  }

  const achievements = computeAchievements({
    totalBookings: bookings.length,
    completedBookings: completed.length,
    totalSpent,
    totalKwh,
    vehiclesCount: vehicles.length,
    reviewsCount: reviews.length,
    tripsCount: trips.length,
    cancelledCount: cancelled.length,
    memberSinceDays: Math.floor((Date.now() - user.createdAt.getTime()) / 86400000),
  })

  // Build activity feed
  const activity: ActivityItem[] = []
  for (const b of bookings.slice(0, 8)) {
    const verb = b.status === 'COMPLETED' ? 'Completed session at' :
                 b.status === 'CANCELLED' ? 'Cancelled booking at' :
                 b.status === 'UPCOMING' ? 'Booked slot at' : `${b.status.toLowerCase()} at`
    activity.push({
      type: 'booking',
      title: `${verb} ${b.station.name}`,
      subtitle: `${b.station.city} · ₹${b.amount}`,
      timestamp: b.createdAt.toISOString(),
      icon: b.status === 'COMPLETED' ? 'check' : b.status === 'CANCELLED' ? 'x' : 'calendar',
    })
  }
  for (const t of transactions.slice(0, 5)) {
    if (t.reason === 'WALLET_TOPUP') {
      activity.push({
        type: 'wallet',
        title: `Added ₹${t.amount} to wallet`,
        subtitle: t.reason.replace(/_/g, ' ').toLowerCase(),
        timestamp: t.createdAt.toISOString(),
        icon: 'wallet',
      })
    } else if (t.reason === 'REFUND') {
      activity.push({
        type: 'wallet',
        title: `Refund of ₹${t.amount} received`,
        subtitle: 'Cancellation refund',
        timestamp: t.createdAt.toISOString(),
        icon: 'refund',
      })
    }
  }
  for (const r of reviews.slice(0, 3)) {
    const station = await db.station.findUnique({ where: { id: r.stationId } })
    if (station) {
      activity.push({
        type: 'review',
        title: `Reviewed ${station.name}`,
        subtitle: `${r.rating} star${r.rating > 1 ? 's' : ''}${r.comment ? ' · ' + r.comment.slice(0, 40) : ''}`,
        timestamp: r.createdAt.toISOString(),
        icon: 'star',
      })
    }
  }
  activity.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())

  return { stats, achievements, activity: activity.slice(0, 10) }
}

function computeAchievements(ctx: {
  totalBookings: number
  completedBookings: number
  totalSpent: number
  totalKwh: number
  vehiclesCount: number
  reviewsCount: number
  tripsCount: number
  cancelledCount: number
  memberSinceDays: number
}): Achievement[] {
  return [
    { id: 'first-charge', title: 'First Charge', description: 'Complete your first charging session', icon: 'zap', unlocked: ctx.completedBookings >= 1, progress: Math.min(100, ctx.completedBookings * 100) },
    { id: 'ev-enthusiast', title: 'EV Enthusiast', description: 'Complete 5 charging sessions', icon: 'battery', unlocked: ctx.completedBookings >= 5, progress: Math.min(100, (ctx.completedBookings / 5) * 100) },
    { id: 'road-tripper', title: 'Road Tripper', description: 'Plan your first long route with charging stops', icon: 'route', unlocked: ctx.tripsCount >= 1, progress: Math.min(100, ctx.tripsCount * 100) },
    { id: 'fleet-master', title: 'Fleet Master', description: 'Add 2 or more vehicles to your profile', icon: 'car', unlocked: ctx.vehiclesCount >= 2, progress: Math.min(100, (ctx.vehiclesCount / 2) * 100) },
    { id: 'reviewer', title: 'Voice of the Grid', description: 'Leave 3 reviews for charging stations', icon: 'star', unlocked: ctx.reviewsCount >= 3, progress: Math.min(100, (ctx.reviewsCount / 3) * 100) },
    { id: 'high-roller', title: 'High Roller', description: 'Spend ₹5,000+ on charging', icon: 'wallet', unlocked: ctx.totalSpent >= 5000, progress: Math.min(100, (ctx.totalSpent / 5000) * 100) },
    { id: 'power-user', title: 'Power User', description: 'Charge 100+ kWh total', icon: 'bolt', unlocked: ctx.totalKwh >= 100, progress: Math.min(100, (ctx.totalKwh / 100) * 100) },
    { id: 'loyal-customer', title: 'Loyal Customer', description: 'Be a member for 30+ days', icon: 'crown', unlocked: ctx.memberSinceDays >= 30, progress: Math.min(100, (ctx.memberSinceDays / 30) * 100) },
    { id: 'eco-warrior', title: 'Eco Warrior', description: 'Complete 20 charging sessions', icon: 'leaf', unlocked: ctx.completedBookings >= 20, progress: Math.min(100, (ctx.completedBookings / 20) * 100) },
  ]
}

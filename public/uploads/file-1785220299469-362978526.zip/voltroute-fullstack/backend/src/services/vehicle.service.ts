// ── Vehicle service: CRUD + multi-vehicle management ─────────────────

import { db } from '../prisma/prisma.service'
import type { ConnectorType, Vehicle, VehicleType } from '../shared/types'

export async function getVehiclesByUser(userId: string): Promise<Vehicle[]> {
  const vehicles = await db.vehicle.findMany({ where: { userId } })
  return vehicles.map((v) => ({ ...v, connectors: v.connectors.split(',') as ConnectorType[] }))
}

interface CreateVehicleInput {
  userId: string
  modelId?: string | null
  nickname: string
  brand: string
  model: string
  vehicleType: VehicleType
  batteryCapacity: number
  fullRange: number
  connectors: ConnectorType[]
  maxAcKw: number
  maxDcKw: number
  currentBattery: number
  isDefault: boolean
}

export async function createVehicle(input: CreateVehicleInput): Promise<Vehicle> {
  if (input.isDefault) {
    await db.vehicle.updateMany({ where: { userId: input.userId }, data: { isDefault: false } })
  }
  const vehicle = await db.vehicle.create({
    data: {
      userId: input.userId,
      modelId: input.modelId ?? null,
      nickname: input.nickname || `${input.brand} ${input.model}`,
      brand: input.brand,
      model: input.model,
      vehicleType: input.vehicleType,
      batteryCapacity: Number(input.batteryCapacity),
      fullRange: Number(input.fullRange),
      connectors: input.connectors.join(','),
      maxAcKw: Number(input.maxAcKw),
      maxDcKw: Number(input.maxDcKw),
      currentBattery: Number(input.currentBattery ?? 50),
      isDefault: Boolean(input.isDefault),
    },
  })
  return { ...vehicle, connectors: vehicle.connectors.split(',') as ConnectorType[] }
}

interface UpdateVehicleInput {
  id: string
  nickname?: string
  currentBattery?: number
  fullRange?: number
  isDefault?: boolean
  connectors?: ConnectorType[]
}

export async function updateVehicle(input: UpdateVehicleInput): Promise<Vehicle> {
  const { id, ...patch } = input
  if (patch.isDefault) {
    const v = await db.vehicle.findUnique({ where: { id } })
    if (v) {
      await db.vehicle.updateMany({ where: { userId: v.userId }, data: { isDefault: false } })
    }
  }
  const data: any = {}
  if (patch.nickname !== undefined) data.nickname = patch.nickname
  if (patch.currentBattery !== undefined) data.currentBattery = Number(patch.currentBattery)
  if (patch.fullRange !== undefined) data.fullRange = Number(patch.fullRange)
  if (patch.isDefault !== undefined) data.isDefault = Boolean(patch.isDefault)
  if (patch.connectors !== undefined) {
    data.connectors = patch.connectors.join(',')
  }
  const vehicle = await db.vehicle.update({ where: { id }, data })
  return { ...vehicle, connectors: vehicle.connectors.split(',') as ConnectorType[] }
}

export async function deleteVehicle(id: string): Promise<void> {
  await db.vehicle.delete({ where: { id } })
}

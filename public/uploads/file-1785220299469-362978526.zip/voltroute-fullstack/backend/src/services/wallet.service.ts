// ── Wallet service: balance, top-up, transactions ────────────────────
//
// Top-up flow (Razorpay):
//   1. createTopupOrder(userId, amount)        → Razorpay order id
//   2. Client opens Razorpay checkout
//   3. verifyAndCreditWallet(userId, amount, signature)  → credits wallet + records tx
//
// The legacy topUpWallet() helper is kept for backward-compat / admin tools,
// but the FE /api/wallet POST is now Razorpay-only for UPI/CARD/NETBANKING.

import { db } from '../prisma/prisma.service'
import { createOrder, verifyPaymentSignature } from './payment.service'
import type { Transaction } from '../shared/types'

export async function getTransactions(userId: string): Promise<Transaction[]> {
  const txs = await db.transaction.findMany({
    where: { userId },
    orderBy: { createdAt: 'desc' },
  })
  return txs as Transaction[]
}

/**
 * Create a Razorpay order for a wallet top-up.
 * Returns the order id + amount (paise) + key id for the client checkout.
 */
export async function createTopupOrder(
  userId: string,
  amountInr: number,
): Promise<{
  orderId: string
  amount: number // paise
  amountInr: number // rupees
  currency: string
  keyId: string | undefined
  receipt: string
}> {
  if (!userId) throw new Error('userId required')
  if (!amountInr || amountInr <= 0) throw new Error('positive amount required')

  const receipt = `wallet_${userId.slice(-6)}_${Date.now()}`
  const order = await createOrder(amountInr, receipt)

  return {
    orderId: order.id,
    amount: order.amount,
    amountInr,
    currency: order.currency,
    keyId: process.env.NEXT_PUBLIC_RAZORPAY_KEY_ID,
    receipt: order.receipt,
  }
}

/**
 * Verify the Razorpay signature, then credit the wallet + record a
 * WALLET_TOPUP transaction. If the signature is invalid, returns { error }.
 *
 * Idempotency note: we use the razorpay_payment_id as the receipt on the
 * transaction to prevent double-crediting if the client retries the verify
 * call (e.g. due to network blip). The unique constraint on... well, we
 * don't have one, so the caller must not retry after success. The UI
 * handles this by resetting state on first success.
 */
export async function verifyAndCreditWallet(params: {
  userId: string
  amountInr: number
  razorpay_order_id: string
  razorpay_payment_id: string
  razorpay_signature: string
}): Promise<
  | { transaction: Transaction; walletBalance: number }
  | { error: string }
> {
  const { userId, amountInr, razorpay_order_id, razorpay_payment_id, razorpay_signature } = params

  if (!userId || !amountInr || amountInr <= 0) {
    return { error: 'userId and positive amount required' }
  }

  // 1. Verify signature (timing-safe)
  const valid = verifyPaymentSignature({
    razorpay_order_id,
    razorpay_payment_id,
    razorpay_signature,
  })
  if (!valid) {
    return { error: 'Payment signature verification failed. Wallet not credited.' }
  }

  // 2. Credit wallet + record transaction
  await db.user.update({
    where: { id: userId },
    data: { walletBalance: { increment: Number(amountInr) } },
  })
  const tx = await db.transaction.create({
    data: {
      userId,
      type: 'CREDIT',
      amount: Number(amountInr),
      reason: 'WALLET_TOPUP',
    },
  })
  const user = await db.user.findUnique({ where: { id: userId } })

  return {
    transaction: tx as unknown as Transaction,
    walletBalance: user?.walletBalance ?? 0,
  }
}

/**
 * Direct top-up — bypasses Razorpay. Kept for admin tools / operational credits.
 * The FE no longer calls this for user-initiated top-ups.
 */
export async function topUpWallet(
  userId: string,
  amount: number,
  reason = 'WALLET_TOPUP',
): Promise<{ transaction: Transaction; walletBalance: number }> {
  if (!userId || !amount || amount <= 0) {
    throw new Error('userId and positive amount required')
  }
  await db.user.update({
    where: { id: userId },
    data: { walletBalance: { increment: Number(amount) } },
  })
  const tx = await db.transaction.create({
    data: { userId, type: 'CREDIT', amount: Number(amount), reason },
  })
  const user = await db.user.findUnique({ where: { id: userId } })
  return {
    transaction: tx as unknown as Transaction,
    walletBalance: user?.walletBalance ?? 0,
  }
}

// ── Vehicle catalog: shared reference data ───────────────────────────
// Used by:
//   - server/scripts/seed.ts (to seed VehicleModel table)
//   - features/vehicles/components/* (catalog picker in the add-vehicle dialog)
//
// Keeping this in shared/ ensures the FE picker and BE seed never drift.

import type { ConnectorType, VehicleType } from './types'

export interface VehicleCatalogEntry {
  brand: string
  model: string
  vehicleType: VehicleType
  batteryCapacity: number
  fullRange: number
  connectors: ConnectorType[]
  maxAcKw: number
  maxDcKw: number
  popular?: boolean
}

export const VEHICLE_CATALOG: VehicleCatalogEntry[] = [
  { brand: 'Tata', model: 'Nexon EV Max', vehicleType: '4W', batteryCapacity: 40.5, fullRange: 437, connectors: ['CCS2'], maxAcKw: 7.4, maxDcKw: 50, popular: true },
  { brand: 'Tata', model: 'Tigor EV', vehicleType: '4W', batteryCapacity: 26, fullRange: 315, connectors: ['CCS2'], maxAcKw: 7.4, maxDcKw: 50, popular: true },
  { brand: 'Tata', model: 'Tiago EV', vehicleType: '4W', batteryCapacity: 24, fullRange: 315, connectors: ['CCS2'], maxAcKw: 3.3, maxDcKw: 50 },
  { brand: 'MG', model: 'ZS EV', vehicleType: '4W', batteryCapacity: 50.3, fullRange: 461, connectors: ['CCS2'], maxAcKw: 7.4, maxDcKw: 76, popular: true },
  { brand: 'MG', model: 'Comet EV', vehicleType: '4W', batteryCapacity: 17.3, fullRange: 230, connectors: ['CCS2'], maxAcKw: 3.3, maxDcKw: 0 },
  { brand: 'Hyundai', model: 'Kona Electric', vehicleType: '4W', batteryCapacity: 39.2, fullRange: 452, connectors: ['CCS2'], maxAcKw: 7.2, maxDcKw: 100, popular: true },
  { brand: 'Hyundai', model: 'Ioniq 5', vehicleType: '4W', batteryCapacity: 72.6, fullRange: 631, connectors: ['CCS2'], maxAcKw: 11, maxDcKw: 350, popular: true },
  { brand: 'BYD', model: 'Atto 3', vehicleType: '4W', batteryCapacity: 60.48, fullRange: 521, connectors: ['CCS2'], maxAcKw: 11, maxDcKw: 88 },
  { brand: 'BYD', model: 'e6', vehicleType: '4W', batteryCapacity: 71.7, fullRange: 520, connectors: ['CCS2'], maxAcKw: 11, maxDcKw: 60 },
  { brand: 'Mahindra', model: 'XUV400 EV', vehicleType: '4W', batteryCapacity: 39.4, fullRange: 456, connectors: ['CCS2'], maxAcKw: 11, maxDcKw: 50 },
  { brand: 'Kia', model: 'EV6', vehicleType: '4W', batteryCapacity: 77.4, fullRange: 708, connectors: ['CCS2'], maxAcKw: 11, maxDcKw: 350, popular: true },
  { brand: 'Tesla', model: 'Model 3', vehicleType: '4W', batteryCapacity: 75, fullRange: 580, connectors: ['CCS2'], maxAcKw: 11, maxDcKw: 250, popular: true },
  { brand: 'Ather', model: '450X', vehicleType: '2W', batteryCapacity: 3.7, fullRange: 146, connectors: ['Type2'], maxAcKw: 1.2, maxDcKw: 0, popular: true },
  { brand: 'Ola', model: 'S1 Pro', vehicleType: '2W', batteryCapacity: 4, fullRange: 181, connectors: ['Type2'], maxAcKw: 1.5, maxDcKw: 0, popular: true },
  { brand: 'TVS', model: 'iQube ST', vehicleType: '2W', batteryCapacity: 5.1, fullRange: 145, connectors: ['Type2'], maxAcKw: 1.5, maxDcKw: 0 },
]

/** City presets used by the route planner autocomplete. */
export const CITY_PRESETS = [
  { name: 'Surat', lat: 21.1702, lng: 72.8311 },
  { name: 'Ahmedabad', lat: 23.0395, lng: 72.5058 },
  { name: 'Udaipur', lat: 24.5854, lng: 73.7125 },
  { name: 'Ajmer', lat: 26.4499, lng: 74.6399 },
  { name: 'Jaipur', lat: 26.9156, lng: 75.8034 },
  { name: 'Delhi', lat: 28.6139, lng: 77.2090 },
  { name: 'Mumbai', lat: 19.0760, lng: 72.8777 },
  { name: 'Pune', lat: 18.5204, lng: 73.8567 },
  { name: 'Bangalore', lat: 12.9716, lng: 77.5946 },
  { name: 'Hyderabad', lat: 17.3850, lng: 78.4867 },
  { name: 'Chennai', lat: 13.0827, lng: 80.2707 },
  { name: 'Gurugram', lat: 28.4595, lng: 77.0266 },
] as const

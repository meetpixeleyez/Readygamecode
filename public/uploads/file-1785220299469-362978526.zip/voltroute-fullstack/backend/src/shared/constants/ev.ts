// ── Shared EV constants — referenced by both FE & BE ──────────────────
// Keeping these in shared/ ensures the colors/labels never drift between
// the server-side filter logic and the client-side UI.

import type { ChargerSpeed, ChargerStatus, ConnectorType } from './types'

/** Color used for the connector-type badge in UI. */
export const CONNECTOR_COLORS: Record<ConnectorType, string> = {
  'CCS2': '#00E676',
  'CHAdeMO': '#00B0FF',
  'Type2': '#FFC107',
  'GB/T': '#FF6E40',
  'Bharat AC001': '#B388FF',
  'Bharat DC001': '#FF5252',
}

/** Color used for the live charger status indicator. */
export const STATUS_COLORS: Record<ChargerStatus, string> = {
  'AVAILABLE': '#00E676',
  'OCCUPIED': '#FFC107',
  'OFFLINE': '#9E9E9E',
  'MAINTENANCE': '#FF5252',
}

/** Human-readable label for each charger speed tier. */
export const SPEED_LABELS: Record<ChargerSpeed, string> = {
  'SLOW_AC': 'Slow AC',
  'FAST_DC': 'Fast DC',
  'ULTRA_FAST': 'Ultra Fast',
}

/** Master list of connector types (used by filters & forms). */
export const ALL_CONNECTORS: ConnectorType[] = [
  'CCS2',
  'CHAdeMO',
  'Type2',
  'GB/T',
  'Bharat AC001',
  'Bharat DC001',
]

/** Master list of charger speed tiers. */
export const ALL_SPEEDS: ChargerSpeed[] = ['SLOW_AC', 'FAST_DC', 'ULTRA_FAST']

/** Amenities the platform supports as structured filter values. */
export const ALL_AMENITIES = [
  'Cafe',
  'Restroom',
  'Waiting Lounge',
  'Covered Parking',
  '24x7',
  'Restaurant Nearby',
]

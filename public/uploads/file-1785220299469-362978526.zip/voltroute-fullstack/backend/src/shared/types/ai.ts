// ── AI Intelligence Engine — shared type contracts ───────────────────
// Imported safely from both server (BE) and client (FE).

import type { Station, Vehicle } from './index'

// ── Battery Predictor ────────────────────────────────────────────────

export interface BatteryPrediction {
  predictedRange: number        // km, after all factors applied
  arrivalBattery: number        // % at destination (if route given)
  confidence: number            // 0-100, how confident the prediction is
  batteryHealth: number         // 0-100, degradation factor
  suggestedSpeed: number        // km/h, optimal for range
  recommendedCharger: {
    station: Station
    charger: Station['chargers'][number]
  } | null
  estimatedCost: number         // INR
  recommendedChargeTime: number // minutes
  factors: {
    terrain: number             // multiplier
    speed: number
    weather: number
    acUsage: number
    health: number
  }
  breakdown: Array<{ label: string; impact: string; detail: string }>
}

export interface BatteryPredictorInput {
  vehicle: Vehicle
  /** Optional route distance in km — if provided, predicts arrival battery. */
  routeDistanceKm?: number
  /** Terrain type. */
  terrain?: 'flat' | 'hilly' | 'mountain'
  /** Average driving speed. */
  avgSpeed?: number
  /** Weather condition. */
  weather?: 'ideal' | 'cold' | 'hot' | 'rainy'
  /** AC/heating on? */
  acOn?: boolean
  /** Nearby stations for charger recommendation. */
  nearbyStations?: Station[]
  /** Number of past fast-charge sessions (for health degradation). */
  fastChargeCount?: number
  /** Vehicle age in months. */
  vehicleAgeMonths?: number
}

// ── Emergency Assistant ──────────────────────────────────────────────

export type EmergencyRisk = 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL'

export interface EmergencyAssessment {
  risk: EmergencyRisk
  reachProbability: number      // 0-100, chance of reaching nearest station
  nearestStation: Station | null
  distanceToNearest: number     // km
  usableRange: number           // km, after battery health + reserve
  alternativeStations: Station[]
  services: {
    towService: boolean
    roadsideAssistance: boolean
    batterySavingMode: boolean  // recommended?
    shareLiveLocation: boolean
    emergencyContact: boolean
  }
  nearbyFacilities: {
    police: boolean
    hospital: boolean
  }
  recommendations: string[]
}

export interface EmergencyInput {
  vehicle: Vehicle
  userLat: number
  userLng: number
  stations: Station[]
}

// ── Cost Comparison ──────────────────────────────────────────────────

export interface StationCostComparison {
  station: Station
  pricePerKwh: number
  queueMinutes: number
  chargingSpeedKw: number
  totalCost: number
  totalTimeMinutes: number      // queue + charge
  kwhNeeded: number
  rating: number
  aiScore: number               // 0-100 weighted
  rank: number
  isBestOverall: boolean
  moneySaved?: number           // vs most expensive
  timeSaved?: number            // vs slowest
}

export interface CostComparisonResult {
  comparisons: StationCostComparison[]
  bestOverall: StationCostComparison | null
  recommendation: string
}

export interface CostComparisonInput {
  vehicle: Vehicle
  targetBatteryPercent: number  // charge up to this %
  stations: Station[]
}

// ── Trip Intelligence ────────────────────────────────────────────────

export interface TripStop {
  type: 'origin' | 'charging' | 'lunch' | 'coffee' | 'rest' | 'destination'
  name: string
  address?: string
  arrivalTime: string           // HH:MM
  durationMinutes: number       // time spent here
  batteryPercent?: number       // battery on arrival
  cost?: number
  station?: Station
  description?: string
}

export interface SmartTripPlan {
  stops: TripStop[]
  totalDistance: number
  totalDuration: number         // minutes including breaks
  totalDrivingTime: number
  totalBreakTime: number
  totalChargingTime: number
  totalCost: number
  arrivalBattery: number
  warnings: string[]
  itinerary: Array<{
    time: string
    title: string
    detail: string
    icon: string
  }>
}

export interface TripIntelligenceInput {
  from: { address: string; lat: number; lng: number }
  to: { address: string; lat: number; lng: number }
  vehicle: Vehicle
  stations: Station[]
  departureTime?: string        // HH:MM, default now
  preferences?: {
    avoidNightDriving?: boolean
    lunchBreak?: boolean
    coffeeBreaks?: boolean
  }
}

// ── Standardized API response envelopes ──────────────────────────────
// All BE handlers return these shapes; FE fetch wrappers can rely on them.

export interface ApiSuccess<T> {
  data: T
  error?: never
}

export interface ApiError {
  error: string
  details?: unknown
  data?: never
}

export type ApiResponse<T> = ApiSuccess<T> | ApiError

// ── Shared type contracts: Booking ───────────────────────────────────

import type { PricingModel } from './station'
import type { PaymentMethod } from './wallet'

export type BookingStatus =
  | 'UPCOMING'
  | 'ONGOING'
  | 'COMPLETED'
  | 'CANCELLED'
  | 'NO_SHOW'

export type PaymentStatus = 'PENDING' | 'PAID' | 'REFUNDED' | 'FAILED'

export interface Booking {
  id: string
  userId: string
  stationId: string
  chargerId: string
  vehicleId: string
  status: BookingStatus
  slotStart: string
  slotEnd: string
  amount: number
  pricingModel: PricingModel
  estimatedKwh: number
  paymentStatus: PaymentStatus
  paymentMethod?: PaymentMethod | null
  qrCode?: string | null
  station?: import('./station').Station
  charger?: import('./station').Charger
  vehicle?: import('./vehicle').Vehicle
}

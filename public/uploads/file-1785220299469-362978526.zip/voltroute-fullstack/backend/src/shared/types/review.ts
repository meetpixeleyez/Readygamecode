// ── Shared type contracts: Review ────────────────────────────────────

export interface Review {
  id: string
  userId: string
  stationId: string
  bookingId?: string | null
  rating: number // 1-5
  comment?: string | null
  tags?: string[] | null
  ownerReply?: string | null
  createdAt: string
  user?: { name: string }
}

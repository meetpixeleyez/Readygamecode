// ── Shared type contracts: Station & Charger ─────────────────────────

import type { ConnectorType } from './vehicle'

export type ChargerSpeed = 'SLOW_AC' | 'FAST_DC' | 'ULTRA_FAST'
export type PricingModel = 'PER_KWH' | 'PER_HOUR' | 'FLAT'
export type ChargerStatus = 'AVAILABLE' | 'OCCUPIED' | 'OFFLINE' | 'MAINTENANCE'
export type StationStatus = 'PENDING' | 'APPROVED' | 'SUSPENDED'

export interface Charger {
  id: string
  stationId: string
  label: string
  connectorType: ConnectorType
  powerKw: number
  chargerSpeed: ChargerSpeed
  pricingModel: PricingModel
  price: number
  status: ChargerStatus
}

export interface Station {
  id: string
  ownerId?: string | null
  name: string
  description?: string | null
  state: string
  city: string
  address: string
  lat: number
  lng: number
  open24x7: boolean
  operatingHours?: string | null
  amenities: string[]
  imageUrl?: string | null
  status: StationStatus
  rating: number
  reviewCount: number
  chargers: Charger[]
  distance?: number // km from search location, optional
}

export interface StationFilters {
  radius?: number // km
  connectors?: ConnectorType[]
  speeds?: ChargerSpeed[]
  availableNow?: boolean
  minPrice?: number
  maxPrice?: number
  amenities?: string[]
  minRating?: number
  openNow?: boolean
  search?: string
  state?: string
  city?: string
  userLat?: number
  userLng?: number
}

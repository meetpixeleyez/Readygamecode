// ── Shared type contracts: Trips (Route Planner) ─────────────────────

import type { Station, Charger } from './station'

export interface ChargingStop {
  station: Station
  charger?: Charger
  arrivalBattery: number
  departureBattery: number
  chargingMinutes: number
  detourKm: number
  estimatedCost: number
}

export interface PlannedTrip {
  fromAddress: string
  toAddress: string
  fromLat: number
  fromLng: number
  toLat: number
  toLng: number
  totalDistance: number // km
  totalDuration: number // minutes
  totalChargingTime: number // minutes
  totalCost: number
  chargingStops: ChargingStop[]
  routePolyline: { lat: number; lng: number }[]
  warnings: string[]
}

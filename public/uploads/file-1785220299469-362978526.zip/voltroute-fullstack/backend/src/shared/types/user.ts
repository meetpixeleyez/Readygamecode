// ── Shared type contracts: User & Auth ───────────────────────────────
// Imported safely from both server (BE) and client (FE) code.

export type Role = 'USER' | 'OWNER' | 'ADMIN'

export interface UserPreferences {
  notifyBookings: boolean
  notifyPromotions: boolean
  notifyTripAlerts: boolean
  defaultReservePercent: number
  defaultChargeTarget: number
}

export const DEFAULT_PREFERENCES: UserPreferences = {
  notifyBookings: true,
  notifyPromotions: false,
  notifyTripAlerts: true,
  defaultReservePercent: 15,
  defaultChargeTarget: 80,
}

export interface User {
  id: string
  email: string
  name: string
  phone?: string | null
  role: Role
  walletBalance: number
  avatarUrl?: string | null
  preferences?: UserPreferences
  createdAt?: string
}

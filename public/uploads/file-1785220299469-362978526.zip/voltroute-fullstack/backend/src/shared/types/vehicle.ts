// ── Shared type contracts: Vehicle & Vehicle Models ──────────────────

export type VehicleType = '2W' | '3W' | '4W' | 'COMMERCIAL'
export type ConnectorType =
  | 'CCS2'
  | 'CHAdeMO'
  | 'Type2'
  | 'GB/T'
  | 'Bharat AC001'
  | 'Bharat DC001'

export interface VehicleModel {
  id: string
  brand: string
  model: string
  vehicleType: VehicleType
  batteryCapacity: number
  fullRange: number
  connectors: ConnectorType[]
  maxAcKw: number
  maxDcKw: number
  popular: boolean
}

export interface Vehicle {
  id: string
  userId: string
  modelId?: string | null
  nickname: string
  brand: string
  model: string
  vehicleType: VehicleType
  batteryCapacity: number
  fullRange: number
  connectors: ConnectorType[]
  maxAcKw: number
  maxDcKw: number
  currentBattery: number
  isDefault: boolean
}

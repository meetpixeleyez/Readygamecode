// ── Shared type contracts: Wallet & Payments ─────────────────────────

export type PaymentMethod = 'WALLET' | 'UPI' | 'CARD' | 'PAY_AT_STATION'

export interface Transaction {
  id: string
  type: 'CREDIT' | 'DEBIT'
  amount: number
  reason: string // WALLET_TOPUP | BOOKING_PAYMENT | REFUND | PAYOUT
  bookingId?: string | null
  createdAt: string
}

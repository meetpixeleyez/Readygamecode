import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'theme/app_theme.dart';
import 'providers/auth_provider.dart';
import 'screens/home_screen.dart';
import 'screens/discover_screen.dart';
import 'screens/vehicles_screen.dart';
import 'screens/bookings_screen.dart';
import 'screens/wallet_screen.dart';
import 'screens/ai_assistant_screen.dart';
import 'screens/profile_screen.dart';
import 'screens/owner_screen.dart';
import 'screens/admin_screen.dart';
import 'screens/setup_wizard_screen.dart';

void main() => runApp(const VoltRouteApp());

class VoltRouteApp extends StatelessWidget {
  const VoltRouteApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MultiProvider(providers: [ChangeNotifierProvider(create: (_) => AuthProvider())], child: MaterialApp(title: 'VoltRoute', debugShowCheckedModeBanner: false, theme: AppTheme.darkTheme, home: const AppRoot()));
  }
}

class AppRoot extends StatelessWidget {
  const AppRoot({super.key});
  @override
  Widget build(BuildContext context) {
    return Consumer<AuthProvider>(builder: (ctx, auth, _) {
      if (auth.loading) return Scaffold(body: Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [Icon(Icons.bolt, size: 48, color: AppTheme.primary), SizedBox(height: 16), CircularProgressIndicator()])));
      if (auth.needsSetup) return SetupWizardScreen(onComplete: auth.completeSetup);
      return const MainShell();
    });
  }
}

class MainShell extends StatefulWidget {
  const MainShell({super.key});
  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  int _idx = 0;
  final _screens = const [HomeScreen(), DiscoverScreen(), AiAssistantScreen(), BookingsScreen(), WalletScreen()];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: IndexedStack(index: _idx, children: _screens),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _idx, onTap: (i) => setState(() => _idx = i),
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.home_outlined), activeIcon: Icon(Icons.home), label: 'Home'),
          BottomNavigationBarItem(icon: Icon(Icons.map_outlined), activeIcon: Icon(Icons.map), label: 'Discover'),
          BottomNavigationBarItem(icon: Icon(Icons.psychology_outlined), activeIcon: Icon(Icons.psychology), label: 'AI'),
          BottomNavigationBarItem(icon: Icon(Icons.event_outlined), activeIcon: Icon(Icons.event), label: 'Bookings'),
          BottomNavigationBarItem(icon: Icon(Icons.account_balance_wallet_outlined), activeIcon: Icon(Icons.account_balance_wallet), label: 'Wallet'),
        ],
      ),
      drawer: Drawer(child: ListView(padding: EdgeInsets.zero, children: [
        DrawerHeader(decoration: BoxDecoration(color: AppTheme.surface), child: Consumer<AuthProvider>(builder: (ctx, auth, _) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          CircleAvatar(backgroundColor: AppTheme.primary.withOpacity(0.1), child: Text((auth.user?.name ?? 'U')[0].toUpperCase(), style: TextStyle(color: AppTheme.primary, fontWeight: FontWeight.bold))),
          SizedBox(height: 8), Text(auth.user?.name ?? 'User', style: TextStyle(fontWeight: FontWeight.bold)),
          Text(auth.user?.email ?? '', style: TextStyle(fontSize: 12, color: AppTheme.textSecondary)),
        ]))),
        ListTile(leading: Icon(Icons.person_outline), title: Text('Profile'), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ProfileScreen()))),
        ListTile(leading: Icon(Icons.business_outlined), title: Text('Owner Dashboard'), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => OwnerScreen()))),
        ListTile(leading: Icon(Icons.admin_panel_settings_outlined), title: Text('Admin Panel'), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => AdminScreen()))),
      ])),
    );
  }
}

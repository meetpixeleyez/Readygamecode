import 'station.dart';

class BatteryPrediction {
  final int predictedRange;
  final int arrivalBattery;
  final int confidence;
  final int batteryHealth;
  final int suggestedSpeed;
  final int estimatedCost;
  final int recommendedChargeTime;
  final RecommendedCharger? recommendedCharger;
  final List<BreakdownItem> breakdown;

  BatteryPrediction({required this.predictedRange, required this.arrivalBattery, required this.confidence, required this.batteryHealth, required this.suggestedSpeed, required this.estimatedCost, required this.recommendedChargeTime, this.recommendedCharger, required this.breakdown});

  factory BatteryPrediction.fromJson(Map<String, dynamic> json) => BatteryPrediction(
    predictedRange: json['predictedRange'] ?? 0, arrivalBattery: json['arrivalBattery'] ?? 0,
    confidence: json['confidence'] ?? 0, batteryHealth: json['batteryHealth'] ?? 0,
    suggestedSpeed: json['suggestedSpeed'] ?? 60, estimatedCost: json['estimatedCost'] ?? 0,
    recommendedChargeTime: json['recommendedChargeTime'] ?? 0,
    recommendedCharger: json['recommendedCharger'] != null ? RecommendedCharger.fromJson(json['recommendedCharger']) : null,
    breakdown: json['breakdown'] != null ? (json['breakdown'] as List).map((b) => BreakdownItem.fromJson(b)).toList() : [],
  );
}

class RecommendedCharger {
  final Station station;
  final Charger charger;
  RecommendedCharger({required this.station, required this.charger});
  factory RecommendedCharger.fromJson(Map<String, dynamic> json) => RecommendedCharger(station: Station.fromJson(json['station']), charger: Charger.fromJson(json['charger']));
}

class BreakdownItem {
  final String label;
  final String impact;
  final String detail;
  BreakdownItem({required this.label, required this.impact, required this.detail});
  factory BreakdownItem.fromJson(Map<String, dynamic> json) => BreakdownItem(label: json['label'] ?? '', impact: json['impact'] ?? '', detail: json['detail'] ?? '');
}

class EmergencyAssessment {
  final String risk;
  final int reachProbability;
  final Station? nearestStation;
  final int distanceToNearest;
  final int usableRange;
  final List<String> recommendations;

  EmergencyAssessment({required this.risk, required this.reachProbability, this.nearestStation, required this.distanceToNearest, required this.usableRange, required this.recommendations});

  factory EmergencyAssessment.fromJson(Map<String, dynamic> json) => EmergencyAssessment(
    risk: json['risk'] ?? 'LOW', reachProbability: json['reachProbability'] ?? 0,
    nearestStation: json['nearestStation'] != null ? Station.fromJson(json['nearestStation']) : null,
    distanceToNearest: json['distanceToNearest'] ?? 0, usableRange: json['usableRange'] ?? 0,
    recommendations: List<String>.from(json['recommendations'] ?? []),
  );
}

class CostComparisonResult {
  final List<StationCostComparison> comparisons;
  final StationCostComparison? bestOverall;
  final String recommendation;

  CostComparisonResult({required this.comparisons, this.bestOverall, required this.recommendation});

  factory CostComparisonResult.fromJson(Map<String, dynamic> json) => CostComparisonResult(
    comparisons: json['comparisons'] != null ? (json['comparisons'] as List).map((c) => StationCostComparison.fromJson(c)).toList() : [],
    bestOverall: json['bestOverall'] != null ? StationCostComparison.fromJson(json['bestOverall']) : null,
    recommendation: json['recommendation'] ?? '',
  );
}

class StationCostComparison {
  final Station station;
  final int totalCost;
  final int queueMinutes;
  final double chargingSpeedKw;
  final int totalTimeMinutes;
  final int aiScore;
  final bool isBestOverall;
  final int? moneySaved;
  final int? timeSaved;

  StationCostComparison({required this.station, required this.totalCost, required this.queueMinutes, required this.chargingSpeedKw, required this.totalTimeMinutes, required this.aiScore, required this.isBestOverall, this.moneySaved, this.timeSaved});

  factory StationCostComparison.fromJson(Map<String, dynamic> json) => StationCostComparison(
    station: Station.fromJson(json['station']), totalCost: json['totalCost'] ?? 0,
    queueMinutes: json['queueMinutes'] ?? 0, chargingSpeedKw: (json['chargingSpeedKw'] ?? 0).toDouble(),
    totalTimeMinutes: json['totalTimeMinutes'] ?? 0, aiScore: json['aiScore'] ?? 0,
    isBestOverall: json['isBestOverall'] ?? false, moneySaved: json['moneySaved'], timeSaved: json['timeSaved'],
  );
}

class PlannedTrip {
  final int totalDistance;
  final int totalDuration;
  final int totalChargingTime;
  final int totalCost;
  final List<ChargingStop> chargingStops;
  final List<String> warnings;

  PlannedTrip({required this.totalDistance, required this.totalDuration, required this.totalChargingTime, required this.totalCost, required this.chargingStops, required this.warnings});

  factory PlannedTrip.fromJson(Map<String, dynamic> json) => PlannedTrip(
    totalDistance: json['totalDistance'] ?? 0, totalDuration: json['totalDuration'] ?? 0,
    totalChargingTime: json['totalChargingTime'] ?? 0, totalCost: json['totalCost'] ?? 0,
    chargingStops: json['chargingStops'] != null ? (json['chargingStops'] as List).map((s) => ChargingStop.fromJson(s)).toList() : [],
    warnings: List<String>.from(json['warnings'] ?? []),
  );
}

class ChargingStop {
  final Station station;
  final int arrivalBattery;
  final int departureBattery;
  final int chargingMinutes;
  final int estimatedCost;

  ChargingStop({required this.station, required this.arrivalBattery, required this.departureBattery, required this.chargingMinutes, required this.estimatedCost});

  factory ChargingStop.fromJson(Map<String, dynamic> json) => ChargingStop(
    station: Station.fromJson(json['station']), arrivalBattery: json['arrivalBattery'] ?? 0,
    departureBattery: json['departureBattery'] ?? 0, chargingMinutes: json['chargingMinutes'] ?? 0,
    estimatedCost: json['estimatedCost'] ?? 0,
  );
}

import 'station.dart';
import 'user.dart';

class Booking {
  final String id;
  final String status;
  final String slotStart;
  final String slotEnd;
  final double amount;
  final String paymentStatus;
  final String? paymentMethod;
  final String? qrCode;
  final Station? station;
  final Charger? charger;
  final Vehicle? vehicle;

  Booking({required this.id, required this.status, required this.slotStart, required this.slotEnd, required this.amount, required this.paymentStatus, this.paymentMethod, this.qrCode, this.station, this.charger, this.vehicle});

  factory Booking.fromJson(Map<String, dynamic> json) => Booking(
    id: json['id'] ?? '', status: json['status'] ?? 'UPCOMING',
    slotStart: json['slotStart'] ?? '', slotEnd: json['slotEnd'] ?? '',
    amount: (json['amount'] ?? 0).toDouble(), paymentStatus: json['paymentStatus'] ?? 'PENDING',
    paymentMethod: json['paymentMethod'], qrCode: json['qrCode'],
    station: json['station'] != null ? Station.fromJson(json['station']) : null,
    charger: json['charger'] != null ? Charger.fromJson(json['charger']) : null,
    vehicle: json['vehicle'] != null ? Vehicle.fromJson(json['vehicle']) : null,
  );
}

class Transaction {
  final String id;
  final String type;
  final double amount;
  final String reason;
  final String createdAt;

  Transaction({required this.id, required this.type, required this.amount, required this.reason, required this.createdAt});

  factory Transaction.fromJson(Map<String, dynamic> json) => Transaction(
    id: json['id'] ?? '', type: json['type'] ?? 'CREDIT',
    amount: (json['amount'] ?? 0).toDouble(), reason: json['reason'] ?? '', createdAt: json['createdAt'] ?? '',
  );
}

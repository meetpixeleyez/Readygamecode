class Station {
  final String id;
  final String name;
  final String? description;
  final String state;
  final String city;
  final String address;
  final double lat;
  final double lng;
  final bool open24x7;
  final String? operatingHours;
  final List<String> amenities;
  final String status;
  final double rating;
  final int reviewCount;
  final List<Charger> chargers;
  final double? distance;

  Station({required this.id, required this.name, this.description, required this.state, required this.city, required this.address, required this.lat, required this.lng, required this.open24x7, this.operatingHours, required this.amenities, required this.status, required this.rating, required this.reviewCount, required this.chargers, this.distance});

  factory Station.fromJson(Map<String, dynamic> json) => Station(
    id: json['id'] ?? '', name: json['name'] ?? '', description: json['description'],
    state: json['state'] ?? '', city: json['city'] ?? '', address: json['address'] ?? '',
    lat: (json['lat'] ?? 0).toDouble(), lng: (json['lng'] ?? 0).toDouble(),
    open24x7: json['open24x7'] ?? false, operatingHours: json['operatingHours'],
    amenities: json['amenities'] != null ? List<String>.from(json['amenities']) : [],
    status: json['status'] ?? 'APPROVED', rating: (json['rating'] ?? 0).toDouble(),
    reviewCount: json['reviewCount'] ?? 0,
    chargers: json['chargers'] != null ? (json['chargers'] as List).map((c) => Charger.fromJson(c)).toList() : [],
    distance: json['distance']?.toDouble(),
  );

  int get availableCount => chargers.where((c) => c.status == 'AVAILABLE').length;
}

class Charger {
  final String id;
  final String label;
  final String connectorType;
  final double powerKw;
  final String chargerSpeed;
  final String pricingModel;
  final double price;
  final String status;

  Charger({required this.id, required this.label, required this.connectorType, required this.powerKw, required this.chargerSpeed, required this.pricingModel, required this.price, required this.status});

  factory Charger.fromJson(Map<String, dynamic> json) => Charger(
    id: json['id'] ?? '', label: json['label'] ?? '', connectorType: json['connectorType'] ?? 'CCS2',
    powerKw: (json['powerKw'] ?? 0).toDouble(), chargerSpeed: json['chargerSpeed'] ?? 'FAST_DC',
    pricingModel: json['pricingModel'] ?? 'PER_KWH', price: (json['price'] ?? 0).toDouble(), status: json['status'] ?? 'AVAILABLE',
  );

  String get priceLabel => pricingModel == 'PER_KWH' ? '₹${price.toInt()}/kWh' : pricingModel == 'PER_HOUR' ? '₹${price.toInt()}/hr' : '₹${price.toInt()}';
  String get speedLabel => {'SLOW_AC': 'Slow AC', 'FAST_DC': 'Fast DC', 'ULTRA_FAST': 'Ultra Fast'}[chargerSpeed] ?? chargerSpeed;
}

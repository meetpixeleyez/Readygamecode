class User {
  final String id;
  final String email;
  final String name;
  final String? phone;
  final String role;
  final double walletBalance;
  final List<Vehicle>? vehicles;
  final String? createdAt;

  User({required this.id, required this.email, required this.name, this.phone, required this.role, required this.walletBalance, this.vehicles, this.createdAt});

  factory User.fromJson(Map<String, dynamic> json) => User(
    id: json['id'] ?? '', email: json['email'] ?? '', name: json['name'] ?? '',
    phone: json['phone'], role: json['role'] ?? 'USER',
    walletBalance: (json['walletBalance'] ?? 0).toDouble(),
    vehicles: json['vehicles'] != null ? (json['vehicles'] as List).map((v) => Vehicle.fromJson(v)).toList() : null,
    createdAt: json['createdAt'],
  );
}

class Vehicle {
  final String id;
  final String nickname;
  final String brand;
  final String model;
  final String vehicleType;
  final double batteryCapacity;
  final double fullRange;
  final List<String> connectors;
  final double maxAcKw;
  final double maxDcKw;
  final double currentBattery;
  final bool isDefault;

  Vehicle({required this.id, required this.nickname, required this.brand, required this.model, required this.vehicleType, required this.batteryCapacity, required this.fullRange, required this.connectors, required this.maxAcKw, required this.maxDcKw, required this.currentBattery, required this.isDefault});

  factory Vehicle.fromJson(Map<String, dynamic> json) => Vehicle(
    id: json['id'] ?? '', nickname: json['nickname'] ?? '', brand: json['brand'] ?? '', model: json['model'] ?? '',
    vehicleType: json['vehicleType'] ?? '4W', batteryCapacity: (json['batteryCapacity'] ?? 0).toDouble(),
    fullRange: (json['fullRange'] ?? 0).toDouble(), connectors: json['connectors'] != null ? List<String>.from(json['connectors']) : [],
    maxAcKw: (json['maxAcKw'] ?? 0).toDouble(), maxDcKw: (json['maxDcKw'] ?? 0).toDouble(),
    currentBattery: (json['currentBattery'] ?? 50).toDouble(), isDefault: json['isDefault'] ?? false,
  );

  Map<String, dynamic> toJson() => {'id': id, 'nickname': nickname, 'brand': brand, 'model': model, 'vehicleType': vehicleType, 'batteryCapacity': batteryCapacity, 'fullRange': fullRange, 'connectors': connectors, 'maxAcKw': maxAcKw, 'maxDcKw': maxDcKw, 'currentBattery': currentBattery, 'isDefault': isDefault};
}

class VehicleModel {
  final String id;
  final String brand;
  final String model;
  final String vehicleType;
  final double batteryCapacity;
  final double fullRange;
  final List<String> connectors;
  final double maxAcKw;
  final double maxDcKw;
  final bool popular;

  VehicleModel({required this.id, required this.brand, required this.model, required this.vehicleType, required this.batteryCapacity, required this.fullRange, required this.connectors, required this.maxAcKw, required this.maxDcKw, this.popular = false});

  factory VehicleModel.fromJson(Map<String, dynamic> json) => VehicleModel(
    id: json['id'] ?? '', brand: json['brand'] ?? '', model: json['model'] ?? '',
    vehicleType: json['vehicleType'] ?? '4W', batteryCapacity: (json['batteryCapacity'] ?? 0).toDouble(),
    fullRange: (json['fullRange'] ?? 0).toDouble(), connectors: json['connectors'] != null ? List<String>.from(json['connectors']) : [],
    maxAcKw: (json['maxAcKw'] ?? 0).toDouble(), maxDcKw: (json['maxDcKw'] ?? 0).toDouble(), popular: json['popular'] ?? false,
  );
}

import 'package:flutter/material.dart';
import '../models/user.dart';
import '../services/api_service.dart';

class AuthProvider extends ChangeNotifier {
  User? _user;
  bool _loading = true;
  bool _needsSetup = false;

  User? get user => _user;
  bool get loading => _loading;
  bool get needsSetup => _needsSetup;
  bool get isAuthenticated => _user != null;

  Vehicle? get defaultVehicle {
    if (_user?.vehicles == null || _user!.vehicles!.isEmpty) return null;
    return _user!.vehicles!.firstWhere((v) => v.isDefault, orElse: () => _user!.vehicles!.first);
  }

  AuthProvider() { _init(); }

  Future<void> _init() async {
    try {
      final status = await ApiService.getSetupStatus();
      _needsSetup = status['needsSetup'] ?? false;
      if (!_needsSetup) _user = await ApiService.getMe();
    } catch (e) { debugPrint('Auth init: $e'); }
    _loading = false; notifyListeners();
  }

  Future<void> refreshUser() async { _user = await ApiService.getMe(); notifyListeners(); }
  Future<void> updateUser(Map<String, dynamic> patch) async { _user = await ApiService.updateMe(patch); notifyListeners(); }
  Future<void> updateWalletBalance(double b) async { if (_user != null) { _user = User(id: _user!.id, email: _user!.email, name: _user!.name, phone: _user!.phone, role: _user!.role, walletBalance: b, vehicles: _user!.vehicles, createdAt: _user!.createdAt); notifyListeners(); } }
  void completeSetup() { _needsSetup = false; _init(); }
  void setVehicles(List<Vehicle> v) { if (_user != null) { _user = User(id: _user!.id, email: _user!.email, name: _user!.name, phone: _user!.phone, role: _user!.role, walletBalance: _user!.walletBalance, vehicles: v, createdAt: _user!.createdAt); notifyListeners(); } }
}

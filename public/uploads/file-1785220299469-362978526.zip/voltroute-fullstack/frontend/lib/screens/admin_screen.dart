import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import '../services/api_service.dart';

class AdminScreen extends StatefulWidget {
  const AdminScreen({super.key});
  @override
  State<AdminScreen> createState() => _AdminScreenState();
}
class _AdminScreenState extends State<AdminScreen> {
  Map<String, dynamic>? _data; bool _loading = true;
  @override
  void initState() { super.initState(); _load(); }
  Future<void> _load() async { setState(() => _loading = true); try { _data = await ApiService.getAdminOverview(); } catch (e) {} setState(() => _loading = false); }
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: Text('Admin Panel')),
    body: _loading ? Center(child: CircularProgressIndicator()) : RefreshIndicator(onRefresh: _load, child: SingleChildScrollView(padding: EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      GridView.count(shrinkWrap: true, physics: NeverScrollableScrollPhysics(), crossAxisCount: 2, childAspectRatio: 1.5, crossAxisSpacing: 8, mainAxisSpacing: 8, children: [_SC('Users', '${_data?['stats']['totalUsers'] ?? 0}', AppTheme.primary), _SC('Stations', '${_data?['stats']['totalStations'] ?? 0}', AppTheme.secondary), _SC('Bookings', '${_data?['stats']['totalBookings'] ?? 0}', AppTheme.accent), _SC('Revenue', '₹${_data?['stats']['totalRevenue'] ?? 0}', AppTheme.purple)]),
      SizedBox(height: 16),
      Text('Pending Approvals', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)), SizedBox(height: 8),
      (_data?['pendingStations'] as List?)?.isEmpty ?? true ? Card(child: Padding(padding: EdgeInsets.all(24), child: Center(child: Text('No pending approvals', style: TextStyle(color: AppTheme.textSecondary))))) : ...((_data!['pendingStations'] as List).map((s) => Card(margin: EdgeInsets.only(bottom: 8), child: ListTile(title: Text(s['name'], style: TextStyle(fontWeight: FontWeight.w600)), subtitle: Text('${s['city']}, ${s['state']}'), trailing: ElevatedButton(onPressed: () async { await ApiService.approveStation(s['id']); _load(); }, child: Text('Approve')))))).toList(),
    ]))),
  );
}
class _SC extends StatelessWidget { final String l, v; final Color c; const _SC(this.l, this.v, this.c); @override Widget build(BuildContext context) => Card(child: Padding(padding: EdgeInsets.all(12), child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.center, children: [Text(l, style: TextStyle(fontSize: 11, color: AppTheme.textSecondary)), SizedBox(height: 4), Text(v, style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: c))]))); }

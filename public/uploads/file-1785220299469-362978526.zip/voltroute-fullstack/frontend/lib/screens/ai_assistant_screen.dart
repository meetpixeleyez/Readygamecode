import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../theme/app_theme.dart';
import '../providers/auth_provider.dart';
import '../services/api_service.dart';
import '../models/ai_prediction.dart';
import '../models/user.dart';

class AiAssistantScreen extends StatefulWidget {
  const AiAssistantScreen({super.key});
  @override
  State<AiAssistantScreen> createState() => _AiAssistantScreenState();
}
class _AiAssistantScreenState extends State<AiAssistantScreen> with SingleTickerProviderStateMixin {
  late TabController _tc;
  @override
  void initState() { super.initState(); _tc = TabController(length: 4, vsync: this); }
  @override
  void dispose() { _tc.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>(); final v = auth.defaultVehicle;
    if (v == null) return Scaffold(appBar: AppBar(title: Text('AI Assistant')), body: Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [Icon(Icons.psychology, size: 48, color: AppTheme.textSecondary), SizedBox(height: 12), Text('Add a vehicle to unlock AI'), SizedBox(height: 16), ElevatedButton(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => VehiclesScreen())), child: Text('Add Vehicle'))])));
    return Scaffold(
      appBar: AppBar(title: Row(children: [Container(padding: EdgeInsets.all(6), decoration: BoxDecoration(gradient: LinearGradient(colors: [AppTheme.primary, AppTheme.secondary]), borderRadius: BorderRadius.circular(8)), child: Icon(Icons.psychology, size: 18, color: Colors.black)), SizedBox(width: 8), Text('AI Engine')]), bottom: TabBar(controller: _tc, isScrollable: true, tabs: [Tab(icon: Icon(Icons.battery_charging_full, size: 16), text: 'Battery'), Tab(icon: Icon(Icons.warning, size: 16), text: 'SOS'), Tab(icon: Icon(Icons.compare_arrows, size: 16), text: 'Compare'), Tab(icon: Icon(Icons.route, size: 16), text: 'Route')], labelColor: AppTheme.primary, unselectedLabelColor: AppTheme.textSecondary, indicatorColor: AppTheme.primary)),
      body: TabBarView(controller: _tc, children: [_BatteryTab(vehicle: v, userId: auth.user?.id), _EmergencyTab(vehicle: v), _CompareTab(vehicle: v), _RouteTab(vehicle: v)]),
    );
  }
}
class _BatteryTab extends StatefulWidget { final Vehicle vehicle; final String? userId; const _BatteryTab({required this.vehicle, this.userId}); @override State<_BatteryTab> createState() => _BatteryTabState(); }
class _BatteryTabState extends State<_BatteryTab> {
  BatteryPrediction? _pred; bool _loading = false; String _terrain = 'flat'; String _weather = 'ideal'; double _speed = 60; bool _ac = true;
  Future<void> _predict() async { setState(() => _loading = true); try { _pred = await ApiService.predictBattery({'vehicle': widget.vehicle.toJson(), 'terrain': _terrain, 'weather': _weather, 'avgSpeed': _speed, 'acOn': _ac, 'userId': widget.userId}); } catch (e) {} setState(() => _loading = false); }
  @override
  Widget build(BuildContext context) => SingleChildScrollView(padding: EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    Card(child: Padding(padding: EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text('Driving Conditions', style: TextStyle(fontWeight: FontWeight.w600, fontSize: 15)), SizedBox(height: 12),
      Row(children: [Expanded(child: DropdownButtonFormField(value: _terrain, decoration: InputDecoration(labelText: 'Terrain', isDense: true), items: [DropdownMenuItem(value: 'flat', child: Text('Flat')), DropdownMenuItem(value: 'hilly', child: Text('Hilly')), DropdownMenuItem(value: 'mountain', child: Text('Mountain'))], onChanged: (v) => setState(() => _terrain = v!))), SizedBox(width: 8), Expanded(child: DropdownButtonFormField(value: _weather, decoration: InputDecoration(labelText: 'Weather', isDense: true), items: [DropdownMenuItem(value: 'ideal', child: Text('Ideal')), DropdownMenuItem(value: 'cold', child: Text('Cold')), DropdownMenuItem(value: 'hot', child: Text('Hot')), DropdownMenuItem(value: 'rainy', child: Text('Rainy'))], onChanged: (v) => setState(() => _weather = v!)))]),
      SizedBox(height: 12), Text('Speed: ${_speed.toInt()} km/h', style: TextStyle(fontSize: 12, color: AppTheme.textSecondary)), Slider(value: _speed, min: 30, max: 120, divisions: 9, activeColor: AppTheme.primary, onChanged: (v) => setState(() => _speed = v)),
      Row(children: [Text('AC/Heating'), Spacer(), Switch(value: _ac, activeColor: AppTheme.primary, onChanged: (v) => setState(() => _ac = v))]),
      SizedBox(height: 12), SizedBox(width: double.infinity, child: ElevatedButton(onPressed: _loading ? null : _predict, child: _loading ? SizedBox(height: 20, width: 20, child: CircularProgressIndicator(strokeWidth: 2)) : Text('Predict Range'))),
    ]))),
    if (_pred != null) ...[SizedBox(height: 16), Card(child: Padding(padding: EdgeInsets.all(16), child: Column(children: [
      Row(mainAxisAlignment: MainAxisAlignment.spaceAround, children: [_Stat('Predicted Range', '${_pred!.predictedRange}', 'km', AppTheme.primary), _Stat('Arrival Battery', '${_pred!.arrivalBattery}', '%', AppTheme.secondary)]),
      SizedBox(height: 12),
      Row(mainAxisAlignment: MainAxisAlignment.spaceAround, children: [_Stat('Health', '${_pred!.batteryHealth}', '%', AppTheme.textPrimary), _Stat('Speed', '${_pred!.suggestedSpeed}', 'km/h', AppTheme.textPrimary), _Stat('Cost', '₹${_pred!.estimatedCost}', '', AppTheme.primary)]),
      if (_pred!.recommendedCharger != null) ...[SizedBox(height: 12), Container(padding: EdgeInsets.all(10), decoration: BoxDecoration(color: AppTheme.background, borderRadius: BorderRadius.circular(8)), child: Row(children: [Icon(Icons.ev_station, size: 16, color: AppTheme.primary), SizedBox(width: 8), Expanded(child: Text(_pred!.recommendedCharger!.station.name, style: TextStyle(fontSize: 13, fontWeight: FontWeight.w500))), Text('${_pred!.recommendedChargeTime} min', style: TextStyle(fontSize: 13, color: AppTheme.primary, fontWeight: FontWeight.w600))]))],
    ])))]
  ]));
}
class _Stat extends StatelessWidget { final String l, v, u; final Color c; const _Stat(this.l, this.v, this.u, this.c); @override Widget build(BuildContext context) => Column(children: [Text(l, style: TextStyle(fontSize: 11, color: AppTheme.textSecondary)), SizedBox(height: 2), Text(v, style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: c)), if (u.isNotEmpty) Text(u, style: TextStyle(fontSize: 10, color: AppTheme.textSecondary))]); }
class _EmergencyTab extends StatefulWidget { final Vehicle vehicle; const _EmergencyTab({required this.vehicle}); @override State<_EmergencyTab> createState() => _EmergencyTabState(); }
class _EmergencyTabState extends State<_EmergencyTab> {
  EmergencyAssessment? _a; bool _loading = false;
  Future<void> _assess() async { setState(() => _loading = true); try { _a = await ApiService.assessEmergency({'vehicle': widget.vehicle.toJson(), 'userLat': 19.0760, 'userLng': 72.8777}); } catch (e) {} setState(() => _loading = false); }
  @override
  Widget build(BuildContext context) => SingleChildScrollView(padding: EdgeInsets.all(16), child: Column(children: [SizedBox(width: double.infinity, child: ElevatedButton(onPressed: _loading ? null : _assess, child: _loading ? SizedBox(height: 20, width: 20, child: CircularProgressIndicator(strokeWidth: 2)) : Text('Assess Emergency Risk'))), if (_a != null) ...[SizedBox(height: 16), Card(child: Padding(padding: EdgeInsets.all(16), child: Column(children: [Row(mainAxisAlignment: MainAxisAlignment.spaceAround, children: [Column(children: [Text('Risk', style: TextStyle(fontSize: 11, color: AppTheme.textSecondary)), Text(_a!.risk, style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: {'LOW': AppTheme.primary, 'MEDIUM': AppTheme.accent, 'HIGH': AppTheme.danger, 'CRITICAL': AppTheme.danger}[_a!.risk] ?? AppTheme.textSecondary))]), Column(children: [Text('Reach', style: TextStyle(fontSize: 11, color: AppTheme.textSecondary)), Text('${_a!.reachProbability}%', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold))])]), SizedBox(height: 12), if (_a!.nearestStation != null) Text('Nearest: ${_a!.nearestStation!.name} (${_a!.distanceToNearest} km)', style: TextStyle(fontSize: 13)), SizedBox(height: 8), ..._a!.recommendations.map((r) => Padding(padding: EdgeInsets.only(bottom: 4), child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('→ ', style: TextStyle(color: AppTheme.primary)), Expanded(child: Text(r, style: TextStyle(fontSize: 12)))])))])))]]);
}
class _CompareTab extends StatefulWidget { final Vehicle vehicle; const _CompareTab({required this.vehicle}); @override State<_CompareTab> createState() => _CompareTabState(); }
class _CompareTabState extends State<_CompareTab> {
  CostComparisonResult? _r; bool _loading = false;
  Future<void> _compare() async { setState(() => _loading = true); try { _r = await ApiService.compareCosts({'vehicle': widget.vehicle.toJson(), 'targetBatteryPercent': 80}); } catch (e) {} setState(() => _loading = false); }
  @override
  Widget build(BuildContext context) => SingleChildScrollView(padding: EdgeInsets.all(16), child: Column(children: [SizedBox(width: double.infinity, child: ElevatedButton(onPressed: _loading ? null : _compare, child: _loading ? SizedBox(height: 20, width: 20, child: CircularProgressIndicator(strokeWidth: 2)) : Text('Compare Stations'))), if (_r != null && _r!.bestOverall != null) ...[SizedBox(height: 16), Card(child: Padding(padding: EdgeInsets.all(12), child: Text(_r!.recommendation, style: TextStyle(color: AppTheme.primary, fontSize: 13)))), SizedBox(height: 8), ..._r!.comparisons.map((c) => Card(margin: EdgeInsets.only(bottom: 6), child: ListTile(title: Text(c.station.name, style: TextStyle(fontSize: 14, fontWeight: FontWeight.w600)), subtitle: Text('₹${c.totalCost} · ${c.queueMinutes}min queue · ${c.chargingSpeedKw.toInt()}kW', style: TextStyle(fontSize: 11)), trailing: Text('${c.aiScore}', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: AppTheme.primary)))))]);
}
class _RouteTab extends StatefulWidget { final Vehicle vehicle; const _RouteTab({required this.vehicle}); @override State<_RouteTab> createState() => _RouteTabState(); }
class _RouteTabState extends State<_RouteTab> {
  PlannedTrip? _trip; bool _loading = false; String _from = 'Surat'; String _to = 'Delhi';
  final _coords = {'Surat': [21.1702, 72.8311], 'Ahmedabad': [23.0395, 72.5058], 'Udaipur': [24.5854, 73.7125], 'Jaipur': [26.9156, 75.8034], 'Delhi': [28.6139, 77.2090], 'Mumbai': [19.0760, 72.8777], 'Pune': [18.5204, 73.8567], 'Bangalore': [12.9716, 77.5946], 'Hyderabad': [17.3850, 78.4867], 'Chennai': [13.0827, 80.2707]};
  Future<void> _plan() async { setState(() => _loading = true); try { _trip = await ApiService.planRoute({'from': {'address': _from, 'lat': _coords[_from]![0], 'lng': _coords[_from]![1]}, 'to': {'address': _to, 'lat': _coords[_to]![0], 'lng': _coords[_to]![1]}, 'vehicle': widget.vehicle.toJson(), 'reservePercent': 15, 'targetChargePercent': 80}); } catch (e) {} setState(() => _loading = false); }
  @override
  Widget build(BuildContext context) => SingleChildScrollView(padding: EdgeInsets.all(16), child: Column(children: [
    Card(child: Padding(padding: EdgeInsets.all(16), child: Column(children: [Row(children: [Expanded(child: DropdownButtonFormField(value: _from, decoration: InputDecoration(labelText: 'From', isDense: true), items: _coords.keys.map((c) => DropdownMenuItem(value: c, child: Text(c))).toList(), onChanged: (v) => setState(() => _from = v!))), SizedBox(width: 8), Expanded(child: DropdownButtonFormField(value: _to, decoration: InputDecoration(labelText: 'To', isDense: true), items: _coords.keys.map((c) => DropdownMenuItem(value: c, child: Text(c))).toList(), onChanged: (v) => setState(() => _to = v!)))]), SizedBox(height: 12), SizedBox(width: double.infinity, child: ElevatedButton(onPressed: _loading ? null : _plan, child: _loading ? SizedBox(height: 20, width: 20, child: CircularProgressIndicator(strokeWidth: 2)) : Text('Plan Route')))]))),
    if (_trip != null) ...[SizedBox(height: 16), Card(child: Padding(padding: EdgeInsets.all(16), child: Row(mainAxisAlignment: MainAxisAlignment.spaceAround, children: [_Stat('Distance', '${_trip!.totalDistance}', 'km', AppTheme.primary), _Stat('Duration', '${(_trip!.totalDuration / 60).round()}h', '${_trip!.totalDuration % 60}m', AppTheme.secondary), _Stat('Stops', '${_trip!.chargingStops.length}', '', AppTheme.accent), _Stat('Cost', '₹${_trip!.totalCost}', '', AppTheme.primary)]))), SizedBox(height: 8), ..._trip!.chargingStops.asMap().entries.map((e) => Card(margin: EdgeInsets.only(bottom: 6), child: ListTile(leading: CircleAvatar(backgroundColor: AppTheme.accent.withOpacity(0.2), child: Text('${e.key + 1}', style: TextStyle(color: AppTheme.accent, fontWeight: FontWeight.bold))), title: Text(e.value.station.name, style: TextStyle(fontSize: 14, fontWeight: FontWeight.w600)), subtitle: Text('${e.value.arrivalBattery}% → ${e.value.departureBattery}% · ${e.value.chargingMinutes}min · ₹${e.value.estimatedCost}', style: TextStyle(fontSize: 11)))))]
  ]));
}

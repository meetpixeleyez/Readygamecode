import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../theme/app_theme.dart';
import '../providers/auth_provider.dart';
import '../services/api_service.dart';
import '../models/booking.dart';

class BookingsScreen extends StatefulWidget {
  const BookingsScreen({super.key});
  @override
  State<BookingsScreen> createState() => _BookingsScreenState();
}
class _BookingsScreenState extends State<BookingsScreen> with SingleTickerProviderStateMixin {
  late TabController _tc; List<Booking> _bookings = []; bool _loading = true;
  @override
  void initState() { super.initState(); _tc = TabController(length: 4, vsync: this); }
  @override
  void didChangeDependencies() { super.didChangeDependencies(); _load(); }
  Future<void> _load() async {
    final auth = context.read<AuthProvider>(); if (auth.user == null) return;
    setState(() => _loading = true);
    try { _bookings = await ApiService.getBookings(auth.user!.id); } catch (e) {}
    setState(() => _loading = false);
  }
  List<Booking> _filter(String tab) => _bookings.where((b) => tab == 'upcoming' ? b.status == 'UPCOMING' : tab == 'ongoing' ? b.status == 'ONGOING' : tab == 'past' ? b.status == 'COMPLETED' || b.status == 'NO_SHOW' : b.status == 'CANCELLED').toList();
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: Text('My Bookings'), bottom: TabBar(controller: _tc, tabs: [Tab(text: 'Upcoming'), Tab(text: 'Ongoing'), Tab(text: 'Past'), Tab(text: 'Cancelled')], labelColor: AppTheme.primary, unselectedLabelColor: AppTheme.textSecondary, indicatorColor: AppTheme.primary)),
    body: _loading ? Center(child: CircularProgressIndicator()) : TabBarView(controller: _tc, children: [_list('upcoming'), _list('ongoing'), _list('past'), _list('cancelled')]),
  );
  Widget _list(String tab) { final items = _filter(tab); if (items.isEmpty) return Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [Icon(Icons.event_busy, size: 48, color: AppTheme.textSecondary), SizedBox(height: 8), Text('No bookings')])); return ListView.builder(padding: EdgeInsets.all(12), itemCount: items.length, itemBuilder: (ctx, i) => _card(items[i])); }
  Widget _card(Booking b) {
    Color sc = {'UPCOMING': AppTheme.secondary, 'ONGOING': AppTheme.primary, 'COMPLETED': AppTheme.textSecondary, 'CANCELLED': AppTheme.danger}[b.status] ?? AppTheme.textSecondary;
    return Card(margin: EdgeInsets.only(bottom: 8), child: Padding(padding: EdgeInsets.all(12), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(children: [Expanded(child: Text(b.station?.name ?? 'Unknown', style: TextStyle(fontWeight: FontWeight.w600, fontSize: 15))), Container(padding: EdgeInsets.symmetric(horizontal: 8, vertical: 3), decoration: BoxDecoration(color: sc.withOpacity(0.1), borderRadius: BorderRadius.circular(8), border: Border.all(color: sc.withOpacity(0.3))), child: Text(b.status, style: TextStyle(fontSize: 10, color: sc)))]),
      SizedBox(height: 8),
      Row(children: [Icon(Icons.location_on, size: 12, color: AppTheme.textSecondary), SizedBox(width: 4), Text('${b.station?.city ?? ''}', style: TextStyle(fontSize: 12, color: AppTheme.textSecondary)), Spacer(), Text('₹${b.amount.toInt()}', style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold, color: AppTheme.primary))]),
      SizedBox(height: 8),
      Row(children: [Icon(Icons.schedule, size: 12, color: AppTheme.textSecondary), SizedBox(width: 4), Text('${_fmt(b.slotStart)}', style: TextStyle(fontSize: 12, color: AppTheme.textSecondary)), Spacer(), if (b.charger != null) Text('${b.charger!.label} · ${b.charger!.connectorType}', style: TextStyle(fontSize: 11, color: AppTheme.textSecondary))]),
      if (b.status == 'UPCOMING') ...[SizedBox(height: 12), Row(children: [Expanded(child: OutlinedButton.icon(onPressed: () async { await ApiService.cancelBooking(b.id); _load(); }, icon: Icon(Icons.close, size: 14, color: AppTheme.danger), label: Text('Cancel', style: TextStyle(fontSize: 11, color: AppTheme.danger)), style: OutlinedButton.styleFrom(padding: EdgeInsets.symmetric(vertical: 8), side: BorderSide(color: AppTheme.danger.withOpacity(0.3))))), SizedBox(width: 6), Expanded(child: OutlinedButton.icon(onPressed: () async { await ApiService.completeBooking(b.id); _load(); }, icon: Icon(Icons.check, size: 14, color: AppTheme.primary), label: Text('Done', style: TextStyle(fontSize: 11, color: AppTheme.primary)), style: OutlinedButton.styleFrom(padding: EdgeInsets.symmetric(vertical: 8), side: BorderSide(color: AppTheme.primary.withOpacity(0.3)))))])],
    ])));
  }
  String _fmt(String iso) { try { final d = DateTime.parse(iso); return '${d.day}/${d.month} ${d.hour.toString().padLeft(2, '0')}:${d.minute.toString().padLeft(2, '0')}'; } catch (e) { return iso; } }
}

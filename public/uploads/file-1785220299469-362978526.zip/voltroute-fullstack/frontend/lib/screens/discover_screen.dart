import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import '../services/api_service.dart';
import '../models/station.dart';
import 'package:url_launcher/url_launcher.dart';

class DiscoverScreen extends StatefulWidget {
  const DiscoverScreen({super.key});
  @override
  State<DiscoverScreen> createState() => _DiscoverScreenState();
}

class _DiscoverScreenState extends State<DiscoverScreen> {
  List<Station> _stations = [];
  bool _loading = true;
  String _search = '';

  @override
  void initState() { super.initState(); _load(); }
  Future<void> _load() async {
    setState(() => _loading = true);
    try { _stations = await ApiService.searchStations(search: _search.isEmpty ? null : _search); } catch (e) {}
    setState(() => _loading = false);
  }

  void _openDetail(Station station) {
    showModalBottomSheet(context: context, isScrollControlled: true, backgroundColor: AppTheme.surface, shape: RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))), builder: (ctx) => DraggableScrollableSheet(initialChildSize: 0.85, maxChildSize: 0.95, minChildSize: 0.5, expand: false, builder: (ctx, scrollController) => ListView(controller: scrollController, padding: EdgeInsets.all(16), children: [
      Center(child: Container(width: 40, height: 4, decoration: BoxDecoration(color: AppTheme.textSecondary, borderRadius: BorderRadius.circular(2)))),
      SizedBox(height: 16),
      Text(station.name, style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
      SizedBox(height: 4),
      Row(children: [Icon(Icons.location_on, size: 14, color: AppTheme.textSecondary), SizedBox(width: 4), Expanded(child: Text(station.address, style: TextStyle(color: AppTheme.textSecondary, fontSize: 13)))]),
      SizedBox(height: 12),
      Row(children: [
        _StatChip(icon: Icons.star, label: '${station.rating.toStringAsFixed(1)} (${station.reviewCount})', color: AppTheme.accent),
        SizedBox(width: 8),
        _StatChip(icon: Icons.ev_station, label: '${station.availableCount}/${station.chargers.length} free', color: AppTheme.primary),
        SizedBox(width: 8),
        _StatChip(icon: Icons.access_time, label: station.open24x7 ? '24x7' : (station.operatingHours ?? ''), color: AppTheme.secondary),
      ]),
      if (station.description != null) ...[SizedBox(height: 12), Text(station.description!, style: TextStyle(fontSize: 13, color: AppTheme.textSecondary))],
      SizedBox(height: 12),
      Wrap(spacing: 6, runSpacing: 6, children: station.amenities.map((a) => Container(padding: EdgeInsets.symmetric(horizontal: 8, vertical: 4), decoration: BoxDecoration(color: AppTheme.surface, borderRadius: BorderRadius.circular(6), border: Border.all(color: AppTheme.border)), child: Text(a, style: TextStyle(fontSize: 11)))).toList()),
      SizedBox(height: 16),
      Text('Live Charger Status', style: TextStyle(fontWeight: FontWeight.w600, fontSize: 15)),
      SizedBox(height: 8),
      ...station.chargers.map((c) => Container(margin: EdgeInsets.only(bottom: 6), padding: EdgeInsets.all(10), decoration: BoxDecoration(color: AppTheme.background, borderRadius: BorderRadius.circular(8), border: Border.all(color: AppTheme.border)), child: Row(children: [
        Container(width: 10, height: 10, decoration: BoxDecoration(color: AppTheme.statusColors[c.status] ?? AppTheme.textSecondary, shape: BoxShape.circle)),
        SizedBox(width: 10),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('${c.label} · ${c.connectorType}', style: TextStyle(fontSize: 13, fontWeight: FontWeight.w500)), Text('${c.powerKw.toInt()}kW · ${c.speedLabel}', style: TextStyle(fontSize: 11, color: AppTheme.textSecondary))])),
        Text(c.priceLabel, style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: AppTheme.primary)),
      ]))),
      SizedBox(height: 16),
      Row(children: [
        Expanded(child: OutlinedButton.icon(onPressed: () async { await launchUrl(Uri.parse('https://www.google.com/maps/dir/?api=1&destination=${station.lat},${station.lng}')); }, icon: Icon(Icons.navigation, size: 16), label: Text('Directions'))),
        SizedBox(width: 8),
        Expanded(child: ElevatedButton.icon(onPressed: () { Navigator.pop(ctx); ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Booking flow — select charger first'))); }, icon: Icon(Icons.bolt, size: 16), label: Text('Book Slot'))),
      ]),
      SizedBox(height: 16),
    ])));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Discover Stations')),
      body: Column(children: [
        Padding(padding: EdgeInsets.all(12), child: TextField(decoration: InputDecoration(prefixIcon: Icon(Icons.search), hintText: 'Search by station, city...', isDense: true), onChanged: (v) => _search = v, onSubmitted: (_) => _load())),
        Padding(padding: EdgeInsets.symmetric(horizontal: 12), child: Align(alignment: Alignment.centerLeft, child: Text(_loading ? 'Loading...' : '${_stations.length} stations found', style: TextStyle(color: AppTheme.textSecondary, fontSize: 12)))),
        SizedBox(height: 8),
        Expanded(child: _loading ? Center(child: CircularProgressIndicator()) : _stations.isEmpty ? Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [Icon(Icons.map_outlined, size: 48, color: AppTheme.textSecondary), SizedBox(height: 8), Text('No stations found')])) : ListView.builder(padding: EdgeInsets.symmetric(horizontal: 12), itemCount: _stations.length, itemBuilder: (ctx, i) => _StationCard(station: _stations[i], onTap: () => _openDetail(_stations[i]))))
      ]),
    );
  }
}

class _StatChip extends StatelessWidget {
  final IconData icon; final String label; final Color color;
  const _StatChip({required this.icon, required this.label, required this.color});
  @override
  Widget build(BuildContext context) => Container(padding: EdgeInsets.symmetric(horizontal: 8, vertical: 4), decoration: BoxDecoration(color: color.withOpacity(0.1), borderRadius: BorderRadius.circular(6), border: Border.all(color: color.withOpacity(0.3))), child: Row(mainAxisSize: MainAxisSize.min, children: [Icon(icon, size: 12, color: color), SizedBox(width: 4), Text(label, style: TextStyle(fontSize: 11, color: color))]));
}

class _StationCard extends StatelessWidget {
  final Station station; final VoidCallback onTap;
  const _StationCard({required this.station, required this.onTap});
  @override
  Widget build(BuildContext context) => Card(margin: EdgeInsets.only(bottom: 8), child: InkWell(onTap: onTap, borderRadius: BorderRadius.circular(12), child: Padding(padding: EdgeInsets.all(12), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    Row(children: [Expanded(child: Text(station.name, style: TextStyle(fontWeight: FontWeight.w600, fontSize: 15))), Container(padding: EdgeInsets.symmetric(horizontal: 8, vertical: 3), decoration: BoxDecoration(color: station.availableCount > 0 ? AppTheme.primary.withOpacity(0.1) : AppTheme.accent.withOpacity(0.1), borderRadius: BorderRadius.circular(12), border: Border.all(color: station.availableCount > 0 ? AppTheme.primary.withOpacity(0.3) : AppTheme.accent.withOpacity(0.3))), child: Text('${station.availableCount}/${station.chargers.length} free', style: TextStyle(fontSize: 11, color: station.availableCount > 0 ? AppTheme.primary : AppTheme.accent)))]),
    SizedBox(height: 4),
    Row(children: [Icon(Icons.location_on, size: 12, color: AppTheme.textSecondary), SizedBox(width: 4), Expanded(child: Text(station.address, style: TextStyle(fontSize: 12, color: AppTheme.textSecondary), maxLines: 1, overflow: TextOverflow.ellipsis))]),
    SizedBox(height: 8),
    Wrap(spacing: 4, children: station.chargers.take(3).map((c) { final color = AppTheme.connectorColors[c.connectorType] ?? AppTheme.textSecondary; return Container(padding: EdgeInsets.symmetric(horizontal: 6, vertical: 2), decoration: BoxDecoration(borderRadius: BorderRadius.circular(4), border: Border.all(color: color.withOpacity(0.3))), child: Text('${c.connectorType} · ${c.powerKw.toInt()}kW', style: TextStyle(fontSize: 10, color: color))); }).toList())
  ]))));
}

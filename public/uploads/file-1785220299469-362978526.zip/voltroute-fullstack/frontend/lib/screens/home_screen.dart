import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../theme/app_theme.dart';
import '../providers/auth_provider.dart';
import '../services/api_service.dart';
import '../models/station.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  List<Station> _stations = [];
  bool _loading = true;

  @override
  void initState() { super.initState(); _load(); }
  Future<void> _load() async {
    try { _stations = await ApiService.searchStations(); } catch (e) {} finally { setState(() => _loading = false); }
  }

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();
    final v = auth.defaultVehicle;
    return Scaffold(
      body: SafeArea(child: RefreshIndicator(onRefresh: _load, child: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Container(padding: EdgeInsets.all(8), decoration: BoxDecoration(color: AppTheme.primary, borderRadius: BorderRadius.circular(12)), child: Icon(Icons.bolt, color: Colors.black, size: 24)),
            SizedBox(width: 12),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('VoltRoute', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)), Text('EV Charging Platform', style: TextStyle(fontSize: 11, color: AppTheme.textSecondary))])),
            if (auth.user != null) Container(padding: EdgeInsets.symmetric(horizontal: 10, vertical: 6), decoration: BoxDecoration(color: AppTheme.surface, borderRadius: BorderRadius.circular(8), border: Border.all(color: AppTheme.border)), child: Row(mainAxisSize: MainAxisSize.min, children: [Icon(Icons.account_balance_wallet, size: 14, color: AppTheme.primary), SizedBox(width: 4), Text('₹${auth.user!.walletBalance.toInt()}', style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600))]))
          ]),
          SizedBox(height: 24),
          Container(padding: EdgeInsets.all(20), decoration: BoxDecoration(gradient: LinearGradient(colors: [AppTheme.primary.withOpacity(0.15), AppTheme.secondary.withOpacity(0.05)], begin: Alignment.topLeft, end: Alignment.bottomRight), borderRadius: BorderRadius.circular(20), border: Border.all(color: AppTheme.primary.withOpacity(0.2))), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('Find, book & route to\nEV charging — anywhere.', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold, height: 1.3)),
            SizedBox(height: 8),
            Text('India-first EV charging platform. Discover stations, plan trips, and book slots.', style: TextStyle(color: AppTheme.textSecondary, fontSize: 13)),
            SizedBox(height: 16),
            Row(children: [
              Expanded(child: ElevatedButton.icon(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => DiscoverScreen())), icon: Icon(Icons.map, size: 18), label: Text('Find Stations'))),
              SizedBox(width: 8),
              Expanded(child: OutlinedButton.icon(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => AiAssistantScreen())), icon: Icon(Icons.route, size: 18, color: AppTheme.secondary), label: Text('Plan Route', style: TextStyle(color: AppTheme.secondary))))
            ])
          ])),
          SizedBox(height: 20),
          if (v != null) Card(child: Padding(padding: EdgeInsets.all(14), child: Row(children: [
            Container(padding: EdgeInsets.all(10), decoration: BoxDecoration(color: AppTheme.primary.withOpacity(0.1), borderRadius: BorderRadius.circular(10)), child: Icon(Icons.battery_charging_full, color: AppTheme.primary, size: 22)),
            SizedBox(width: 12),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('${v.brand} ${v.model}', style: TextStyle(fontWeight: FontWeight.w600, fontSize: 15)), Text('${v.currentBattery.toInt()}% · ${(v.fullRange * v.currentBattery / 100).round()} km · ${v.connectors.join(', ')}', style: TextStyle(fontSize: 12, color: AppTheme.textSecondary))])),
            TextButton(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => VehiclesScreen())), child: Text('Manage'))
          ]))) else Card(child: Padding(padding: EdgeInsets.all(14), child: Row(children: [
            Container(padding: EdgeInsets.all(10), decoration: BoxDecoration(color: AppTheme.secondary.withOpacity(0.1), borderRadius: BorderRadius.circular(10)), child: Icon(Icons.directions_car, color: AppTheme.secondary, size: 22)),
            SizedBox(width: 12),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('Add your vehicle', style: TextStyle(fontWeight: FontWeight.w600, fontSize: 15)), Text('Unlock smart filtering & route planning', style: TextStyle(fontSize: 12, color: AppTheme.textSecondary))])),
            ElevatedButton(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => VehiclesScreen())), child: Text('Add'))
          ]))),
          SizedBox(height: 20),
          Text('Featured Stations', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          SizedBox(height: 12),
          if (_loading) Center(child: CircularProgressIndicator())
          else if (_stations.isEmpty) Card(child: Padding(padding: EdgeInsets.all(24), child: Center(child: Column(children: [Icon(Icons.map_outlined, size: 40, color: AppTheme.textSecondary), SizedBox(height: 8), Text('No stations yet', style: TextStyle(color: AppTheme.textSecondary)), SizedBox(height: 12), ElevatedButton(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => OwnerScreen())), child: Text('Add Stations'))]))))
          else ..._stations.take(3).map((s) => Card(margin: EdgeInsets.only(bottom: 8), child: ListTile(contentPadding: EdgeInsets.all(12), title: Text(s.name, style: TextStyle(fontWeight: FontWeight.w600)), subtitle: Text('${s.city}, ${s.state} · ${s.availableCount}/${s.chargers.length} free'), trailing: Row(mainAxisSize: MainAxisSize.min, children: [Icon(Icons.star, size: 14, color: AppTheme.accent), Text(s.rating.toStringAsFixed(1), style: TextStyle(fontSize: 13))]))))
        ])
      ))),
    );
  }
}

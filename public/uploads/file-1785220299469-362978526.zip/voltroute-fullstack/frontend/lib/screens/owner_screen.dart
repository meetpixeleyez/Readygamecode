import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../theme/app_theme.dart';
import '../providers/auth_provider.dart';
import '../services/api_service.dart';
import '../models/station.dart';

class OwnerScreen extends StatefulWidget {
  const OwnerScreen({super.key});
  @override
  State<OwnerScreen> createState() => _OwnerScreenState();
}
class _OwnerScreenState extends State<OwnerScreen> {
  List<dynamic> _stations = []; bool _loading = true;
  @override
  void didChangeDependencies() { super.didChangeDependencies(); _load(); }
  Future<void> _load() async { final auth = context.read<AuthProvider>(); if (auth.user == null) return; setState(() => _loading = true); try { _stations = await ApiService.getOwnerStations(auth.user!.id); } catch (e) {} setState(() => _loading = false); }
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: Text('Owner Dashboard')),
    body: _loading ? Center(child: CircularProgressIndicator()) : _stations.isEmpty ? Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [Icon(Icons.business, size: 48, color: AppTheme.textSecondary), SizedBox(height: 8), Text('No stations registered'), SizedBox(height: 12), ElevatedButton(onPressed: () => _addStation(context), child: Text('Register Station'))])) : RefreshIndicator(onRefresh: _load, child: ListView.builder(padding: EdgeInsets.all(16), itemCount: _stations.length, itemBuilder: (ctx, i) => Card(margin: EdgeInsets.only(bottom: 8), child: ExpansionTile(title: Text(_stations[i]['name'], style: TextStyle(fontWeight: FontWeight.w600)), subtitle: Text('${_stations[i]['city']}, ${_stations[i]['state']} · ₹${_stations[i]['weeklyRevenue']}', style: TextStyle(fontSize: 12, color: AppTheme.textSecondary)), children: [(_stations[i]['chargers'] as List).map((c) => ListTile(dense: true, leading: Container(width: 10, height: 10, decoration: BoxDecoration(color: AppTheme.statusColors[c['status']] ?? AppTheme.textSecondary, shape: BoxShape.circle)), title: Text('${c['label']} · ${c['connectorType']} · ${c['powerKw']}kW', style: TextStyle(fontSize: 13)), trailing: Switch(value: c['status'] == 'AVAILABLE', activeColor: AppTheme.primary, onChanged: (val) async { await ApiService.toggleCharger(c['id'], val ? 'AVAILABLE' : 'MAINTENANCE'); _load(); }))]).toList()])))),
  );
  void _addStation(BuildContext context) {
    final name = TextEditingController(); final state = TextEditingController(); final city = TextEditingController(); final addr = TextEditingController();
    showDialog(context: context, builder: (ctx) => AlertDialog(title: Text('Register Station'), content: Column(mainAxisSize: MainAxisSize.min, children: [TextField(controller: name, decoration: InputDecoration(labelText: 'Station name', isDense: true)), SizedBox(height: 8), TextField(controller: state, decoration: InputDecoration(labelText: 'State', isDense: true)), SizedBox(height: 8), TextField(controller: city, decoration: InputDecoration(labelText: 'City', isDense: true)), SizedBox(height: 8), TextField(controller: addr, decoration: InputDecoration(labelText: 'Address', isDense: true))]), actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: Text('Cancel')), ElevatedButton(onPressed: () async { final auth = context.read<AuthProvider>(); try { await ApiService.createStation({'ownerId': auth.user!.id, 'name': name.text, 'state': state.text, 'city': city.text, 'address': addr.text, 'lat': 19.076, 'lng': 72.877, 'open24x7': true, 'amenities': ['Restroom'], 'chargers': [{'label': 'DC-01', 'connectorType': 'CCS2', 'powerKw': 60, 'chargerSpeed': 'FAST_DC', 'pricingModel': 'PER_KWH', 'price': 22}]}); Navigator.pop(ctx); _load(); } catch (e) { ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Error: $e'))); } }, child: Text('Register'))]));
  }
}

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../theme/app_theme.dart';
import '../providers/auth_provider.dart';
import '../services/api_service.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});
  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}
class _ProfileScreenState extends State<ProfileScreen> {
  Map<String, dynamic>? _stats;
  @override
  void didChangeDependencies() { super.didChangeDependencies(); _load(); }
  Future<void> _load() async { try { _stats = await ApiService.getMyStats(); setState(() {}); } catch (e) {} }
  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>(); final u = auth.user;
    return Scaffold(appBar: AppBar(title: Text('Profile')), body: SingleChildScrollView(padding: EdgeInsets.all(16), child: Column(children: [
      Card(child: Padding(padding: EdgeInsets.all(20), child: Column(children: [CircleAvatar(radius: 40, backgroundColor: AppTheme.primary.withOpacity(0.1), child: Text((u?.name ?? 'U')[0].toUpperCase(), style: TextStyle(fontSize: 32, fontWeight: FontWeight.bold, color: AppTheme.primary))), SizedBox(height: 12), Text(u?.name ?? 'User', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)), Text(u?.email ?? '', style: TextStyle(color: AppTheme.textSecondary, fontSize: 13)), SizedBox(height: 8), Container(padding: EdgeInsets.symmetric(horizontal: 10, vertical: 4), decoration: BoxDecoration(color: AppTheme.primary.withOpacity(0.1), borderRadius: BorderRadius.circular(8), border: Border.all(color: AppTheme.primary.withOpacity(0.3))), child: Text(u?.role ?? 'USER', style: TextStyle(fontSize: 11, color: AppTheme.primary)))]))),
      SizedBox(height: 16),
      if (_stats != null) GridView.count(shrinkWrap: true, physics: NeverScrollableScrollPhysics(), crossAxisCount: 2, childAspectRatio: 1.5, crossAxisSpacing: 8, mainAxisSpacing: 8, children: [_StatCard(Icons.event, 'Bookings', '${_stats!['stats']['totalBookings']}', AppTheme.primary), _StatCard(Icons.account_balance_wallet, 'Spent', '₹${_stats!['stats']['totalSpent']}', AppTheme.secondary), _StatCard(Icons.directions_car, 'Vehicles', '${_stats!['stats']['vehiclesCount']}', AppTheme.accent), _StatCard(Icons.route, 'Trips', '${_stats!['stats']['tripsCount']}', AppTheme.purple)]),
      SizedBox(height: 16),
      if (_stats != null && _stats!['achievements'] != null) ...[Text('Achievements', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)), SizedBox(height: 8), ...(_stats!['achievements'] as List).map((a) => Card(margin: EdgeInsets.only(bottom: 4), child: ListTile(leading: Icon(a['unlocked'] ? Icons.emoji_events : Icons.emoji_events_outlined, color: a['unlocked'] ? AppTheme.accent : AppTheme.textSecondary), title: Text(a['title'], style: TextStyle(fontSize: 13, fontWeight: FontWeight.w500)), subtitle: Text(a['description'], style: TextStyle(fontSize: 11)), trailing: a['unlocked'] ? Container(padding: EdgeInsets.symmetric(horizontal: 6, vertical: 2), decoration: BoxDecoration(color: AppTheme.accent, borderRadius: BorderRadius.circular(4)), child: Text('UNLOCKED', style: TextStyle(fontSize: 9, color: Colors.black, fontWeight: FontWeight.bold))) : Text('${(a['progress'] ?? 0).round()}%', style: TextStyle(fontSize: 11, color: AppTheme.textSecondary)))))],
      SizedBox(height: 16),
      Card(child: Padding(padding: EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('Switch Role', style: TextStyle(fontWeight: FontWeight.w600, fontSize: 15)), SizedBox(height: 8), Row(children: ['USER', 'OWNER', 'ADMIN'].map((r) => Expanded(child: Padding(padding: EdgeInsets.symmetric(horizontal: 4), child: ElevatedButton(onPressed: () => auth.updateUser({'role': r}), style: ElevatedButton.styleFrom(backgroundColor: u?.role == r ? AppTheme.primary : AppTheme.surface, foregroundColor: u?.role == r ? Colors.black : AppTheme.textPrimary, padding: EdgeInsets.symmetric(vertical: 10)), child: Text(r, style: TextStyle(fontSize: 12))))).toList()))])))
    ])));
  }
}
class _StatCard extends StatelessWidget { final IconData i; final String l, v; final Color c; const _StatCard(this.i, this.l, this.v, this.c); @override Widget build(BuildContext context) => Card(child: Padding(padding: EdgeInsets.all(12), child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.center, children: [Row(children: [Icon(i, size: 16, color: c), SizedBox(width: 6), Text(l, style: TextStyle(fontSize: 11, color: AppTheme.textSecondary))]), SizedBox(height: 4), Text(v, style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold))]))); }

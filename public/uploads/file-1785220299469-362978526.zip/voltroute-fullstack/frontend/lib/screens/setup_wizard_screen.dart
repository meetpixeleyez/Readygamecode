import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import '../services/api_service.dart';

class SetupWizardScreen extends StatefulWidget {
  final VoidCallback onComplete;
  const SetupWizardScreen({super.key, required this.onComplete});
  @override
  State<SetupWizardScreen> createState() => _SetupWizardScreenState();
}
class _SetupWizardScreenState extends State<SetupWizardScreen> {
  int _step = 0; bool _loading = false;
  final _sName = TextEditingController(); final _sState = TextEditingController(); final _sCity = TextEditingController(); final _sAddr = TextEditingController(); bool _open24x7 = true;
  final _vBrand = TextEditingController(); final _vModel = TextEditingController(); String _vType = '4W'; List<String> _conn = ['CCS2'];
  Future<void> _submitStation() async {
    if (_sName.text.isEmpty || _sState.text.isEmpty || _sCity.text.isEmpty) return;
    setState(() => _loading = true);
    try { await ApiService.createStationsBulk([{'name': _sName.text, 'state': _sState.text, 'city': _sCity.text, 'address': _sAddr.text, 'lat': 19.076, 'lng': 72.877, 'open24x7': _open24x7, 'amenities': ['Restroom'], 'chargers': [{'label': 'DC-01', 'connectorType': 'CCS2', 'powerKw': 60, 'chargerSpeed': 'FAST_DC', 'pricingModel': 'PER_KWH', 'price': 22}]}]); setState(() => _step = 2); } catch (e) { ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Error: $e'))); }
    setState(() => _loading = false);
  }
  Future<void> _submitVehicle() async {
    if (_vBrand.text.isEmpty || _vModel.text.isEmpty) return;
    setState(() => _loading = true);
    try { await ApiService.createVehicleModelsBulk([{'brand': _vBrand.text, 'model': _vModel.text, 'vehicleType': _vType, 'batteryCapacity': 40, 'fullRange': 300, 'connectors': _conn, 'maxAcKw': 7.4, 'maxDcKw': 50, 'popular': true}]); setState(() => _step = 3); } catch (e) { ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Error: $e'))); }
    setState(() => _loading = false);
  }
  @override
  Widget build(BuildContext context) => Scaffold(body: SafeArea(child: Center(child: SingleChildScrollView(padding: EdgeInsets.all(24), child: ConstrainedBox(constraints: BoxConstraints(maxWidth: 500), child: _build())))));
  Widget _build() {
    switch (_step) {
      case 0: return Column(mainAxisSize: MainAxisSize.min, children: [Container(padding: EdgeInsets.all(20), decoration: BoxDecoration(gradient: LinearGradient(colors: [AppTheme.primary, AppTheme.secondary]), borderRadius: BorderRadius.circular(20)), child: Icon(Icons.bolt, size: 48, color: Colors.black)), SizedBox(height: 24), Text('Welcome to VoltRoute', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)), SizedBox(height: 8), Text('Set up your EV charging platform. Add stations and vehicle models to get started.', textAlign: TextAlign.center, style: TextStyle(color: AppTheme.textSecondary)), SizedBox(height: 32), SizedBox(width: double.infinity, child: ElevatedButton(onPressed: () => setState(() => _step = 1), child: Text('Get Started')))]);
      case 1: return Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [Text('Add Charging Station', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)), SizedBox(height: 16), TextField(controller: _sName, decoration: InputDecoration(labelText: 'Station name *')), SizedBox(height: 8), Row(children: [Expanded(child: TextField(controller: _sState, decoration: InputDecoration(labelText: 'State *'))), SizedBox(width: 8), Expanded(child: TextField(controller: _sCity, decoration: InputDecoration(labelText: 'City *')))]), SizedBox(height: 8), TextField(controller: _sAddr, decoration: InputDecoration(labelText: 'Address *')), SizedBox(height: 8), SwitchListTile(title: Text('Open 24x7'), value: _open24x7, activeColor: AppTheme.primary, onChanged: (v) => setState(() => _open24x7 = v)), SizedBox(height: 16), Row(children: [TextButton(onPressed: () => setState(() => _step = 0), child: Text('Back')), SizedBox(width: 8), Expanded(child: ElevatedButton(onPressed: _loading ? null : _submitStation, child: _loading ? SizedBox(height: 20, width: 20, child: CircularProgressIndicator(strokeWidth: 2)) : Text('Continue')))])]);
      case 2: return Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [Text('Add Vehicle Model', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)), SizedBox(height: 16), Row(children: [Expanded(child: TextField(controller: _vBrand, decoration: InputDecoration(labelText: 'Brand *'))), SizedBox(width: 8), Expanded(child: TextField(controller: _vModel, decoration: InputDecoration(labelText: 'Model *')))]), SizedBox(height: 8), DropdownButtonFormField(value: _vType, decoration: InputDecoration(labelText: 'Type'), items: [DropdownMenuItem(value: '2W', child: Text('2-Wheeler')), DropdownMenuItem(value: '4W', child: Text('4-Wheeler')), DropdownMenuItem(value: 'COMMERCIAL', child: Text('Commercial'))], onChanged: (v) => setState(() => _vType = v!)), SizedBox(height: 8), Wrap(spacing: 6, children: ['CCS2', 'CHAdeMO', 'Type2', 'GB/T', 'Bharat AC001', 'Bharat DC001'].map((c) => ChoiceChip(label: Text(c, style: TextStyle(fontSize: 11)), selected: _conn.contains(c), selectedColor: AppTheme.primary, onSelected: (v) => setState(() => v ? _conn.add(c) : _conn.remove(c)))).toList()), SizedBox(height: 16), Row(children: [TextButton(onPressed: () => setState(() => _step = 1), child: Text('Back')), SizedBox(width: 8), Expanded(child: ElevatedButton(onPressed: _loading ? null : _submitVehicle, child: _loading ? SizedBox(height: 20, width: 20, child: CircularProgressIndicator(strokeWidth: 2)) : Text('Complete Setup')))])]);
      case 3: return Column(mainAxisSize: MainAxisSize.min, children: [Container(padding: EdgeInsets.all(20), decoration: BoxDecoration(color: AppTheme.primary.withOpacity(0.1), shape: BoxShape.circle), child: Icon(Icons.check, size: 48, color: AppTheme.primary)), SizedBox(height: 24), Text('Setup Complete!', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: AppTheme.primary)), SizedBox(height: 8), Text('Your EV charging platform is ready.', textAlign: TextAlign.center, style: TextStyle(color: AppTheme.textSecondary)), SizedBox(height: 32), SizedBox(width: double.infinity, child: ElevatedButton(onPressed: widget.onComplete, child: Text('Enter VoltRoute')))]);
      default: return SizedBox();
    }
  }
}

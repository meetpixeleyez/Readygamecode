import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../theme/app_theme.dart';
import '../providers/auth_provider.dart';
import '../services/api_service.dart';
import '../models/user.dart';

class VehiclesScreen extends StatefulWidget {
  const VehiclesScreen({super.key});
  @override
  State<VehiclesScreen> createState() => _VehiclesScreenState();
}
class _VehiclesScreenState extends State<VehiclesScreen> {
  List<Vehicle> _vehicles = []; bool _loading = true;
  @override
  void didChangeDependencies() { super.didChangeDependencies(); _load(); }
  Future<void> _load() async {
    final auth = context.read<AuthProvider>(); if (auth.user == null) return;
    setState(() => _loading = true);
    try { _vehicles = await ApiService.getVehicles(auth.user!.id); auth.setVehicles(_vehicles); } catch (e) {}
    setState(() => _loading = false);
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('My Vehicles'), actions: [IconButton(icon: Icon(Icons.add), onPressed: () => _showAddDialog(context))]),
      body: _loading ? Center(child: CircularProgressIndicator()) : _vehicles.isEmpty ? Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [Icon(Icons.directions_car, size: 48, color: AppTheme.textSecondary), SizedBox(height: 12), Text('No vehicles added yet'), SizedBox(height: 16), ElevatedButton.icon(onPressed: () => _showAddDialog(context), icon: Icon(Icons.add), label: Text('Add Vehicle'))])) : ListView.builder(padding: EdgeInsets.all(12), itemCount: _vehicles.length, itemBuilder: (ctx, i) => _VehicleCard(vehicle: _vehicles[i], onChanged: _load)),
    );
  }
  void _showAddDialog(BuildContext context) {
    final nickname = TextEditingController(); final brand = TextEditingController(); final model = TextEditingController();
    String vehicleType = '4W'; double battery = 40; double range = 300; List<String> connectors = ['CCS2'];
    showDialog(context: context, builder: (ctx) => StatefulBuilder(builder: (ctx, setState) => AlertDialog(
      title: Text('Add Vehicle'), content: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [
        TextField(controller: nickname, decoration: InputDecoration(labelText: 'Nickname', isDense: true)),
        SizedBox(height: 8),
        TextField(controller: brand, decoration: InputDecoration(labelText: 'Brand', isDense: true)),
        SizedBox(height: 8),
        TextField(controller: model, decoration: InputDecoration(labelText: 'Model', isDense: true)),
        SizedBox(height: 8),
        DropdownButtonFormField(value: vehicleType, decoration: InputDecoration(labelText: 'Type', isDense: true), items: [DropdownMenuItem(value: '2W', child: Text('2-Wheeler')), DropdownMenuItem(value: '4W', child: Text('4-Wheeler')), DropdownMenuItem(value: 'COMMERCIAL', child: Text('Commercial'))], onChanged: (v) => setState(() => vehicleType = v!)),
        SizedBox(height: 8),
        Row(children: [Expanded(child: TextField(controller: TextEditingController(text: battery.toString()), decoration: InputDecoration(labelText: 'Battery kWh', isDense: true), keyboardType: TextInputType.number, onChanged: (v) => battery = double.tryParse(v) ?? 40)), SizedBox(width: 8), Expanded(child: TextField(controller: TextEditingController(text: range.toString()), decoration: InputDecoration(labelText: 'Range km', isDense: true), keyboardType: TextInputType.number, onChanged: (v) => range = double.tryParse(v) ?? 300))]),
        SizedBox(height: 8),
        Wrap(spacing: 6, children: ['CCS2', 'CHAdeMO', 'Type2', 'GB/T', 'Bharat AC001', 'Bharat DC001'].map((c) => ChoiceChip(label: Text(c, style: TextStyle(fontSize: 11)), selected: connectors.contains(c), selectedColor: AppTheme.primary, onSelected: (val) => setState(() => val ? connectors.add(c) : connectors.remove(c)))).toList()),
      ])),
      actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: Text('Cancel')), ElevatedButton(onPressed: () async {
        final auth = context.read<AuthProvider>();
        try {
          await ApiService.createVehicle({'userId': auth.user!.id, 'nickname': nickname.text, 'brand': brand.text, 'model': model.text, 'vehicleType': vehicleType, 'batteryCapacity': battery, 'fullRange': range, 'connectors': connectors, 'maxAcKw': 7.4, 'maxDcKw': 50, 'currentBattery': 50, 'isDefault': _vehicles.isEmpty});
          Navigator.pop(ctx); _load();
        } catch (e) { ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Error: $e'))); }
      }, child: Text('Add'))],
    )));
  }
}
class _VehicleCard extends StatelessWidget {
  final Vehicle vehicle; final VoidCallback onChanged;
  const _VehicleCard({required this.vehicle, required this.onChanged});
  @override
  Widget build(BuildContext context) => Card(margin: EdgeInsets.only(bottom: 8), child: Padding(padding: EdgeInsets.all(12), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    Row(children: [Container(padding: EdgeInsets.all(8), decoration: BoxDecoration(color: AppTheme.primary.withOpacity(0.1), borderRadius: BorderRadius.circular(10)), child: Icon(vehicle.vehicleType == '2W' ? Icons.two_wheeler : Icons.directions_car, color: AppTheme.primary, size: 20)), SizedBox(width: 10), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Row(children: [Text(vehicle.nickname, style: TextStyle(fontWeight: FontWeight.w600, fontSize: 15)), if (vehicle.isDefault) ...[SizedBox(width: 6), Container(padding: EdgeInsets.symmetric(horizontal: 6, vertical: 1), decoration: BoxDecoration(color: AppTheme.primary, borderRadius: BorderRadius.circular(4)), child: Text('DEFAULT', style: TextStyle(fontSize: 9, color: Colors.black, fontWeight: FontWeight.bold)))]), Text('${vehicle.brand} ${vehicle.model}', style: TextStyle(fontSize: 12, color: AppTheme.textSecondary))])), TextButton(onPressed: () async { await ApiService.deleteVehicle(vehicle.id); onChanged(); }, child: Text('Delete', style: TextStyle(color: AppTheme.danger)))
    ]),
    SizedBox(height: 8),
    Row(children: [Icon(Icons.battery_charging_full, size: 14, color: AppTheme.primary), SizedBox(width: 4), Text('${vehicle.currentBattery.toInt()}%', style: TextStyle(fontSize: 12)), SizedBox(width: 8), Expanded(child: ClipRRect(borderRadius: BorderRadius.circular(4), child: LinearProgressIndicator(value: vehicle.currentBattery / 100, backgroundColor: AppTheme.surface, valueColor: AlwaysStoppedAnimation(vehicle.currentBattery > 50 ? AppTheme.primary : AppTheme.accent), minHeight: 6))), SizedBox(width: 8), Text('${(vehicle.fullRange * vehicle.currentBattery / 100).round()} km', style: TextStyle(fontSize: 10, color: AppTheme.textSecondary))]),
    SizedBox(height: 8),
    Wrap(spacing: 4, children: vehicle.connectors.map((c) { final color = AppTheme.connectorColors[c] ?? AppTheme.textSecondary; return Container(padding: EdgeInsets.symmetric(horizontal: 6, vertical: 2), decoration: BoxDecoration(borderRadius: BorderRadius.circular(4), border: Border.all(color: color.withOpacity(0.3))), child: Text(c, style: TextStyle(fontSize: 10, color: color))); }).toList())
  ])));
}

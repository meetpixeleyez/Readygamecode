import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../theme/app_theme.dart';
import '../providers/auth_provider.dart';
import '../services/api_service.dart';
import '../models/booking.dart';

class WalletScreen extends StatefulWidget {
  const WalletScreen({super.key});
  @override
  State<WalletScreen> createState() => _WalletScreenState();
}
class _WalletScreenState extends State<WalletScreen> {
  List<Transaction> _txns = []; bool _loading = true;
  @override
  void didChangeDependencies() { super.didChangeDependencies(); _load(); }
  Future<void> _load() async {
    final auth = context.read<AuthProvider>(); if (auth.user == null) return;
    setState(() => _loading = true);
    try { _txns = await ApiService.getTransactions(auth.user!.id); } catch (e) {}
    setState(() => _loading = false);
  }
  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>(); final balance = auth.user?.walletBalance ?? 0;
    final spent = _txns.where((t) => t.type == 'DEBIT').fold(0.0, (s, t) => s + t.amount);
    final topped = _txns.where((t) => t.type == 'CREDIT').fold(0.0, (s, t) => s + t.amount);
    return Scaffold(
      appBar: AppBar(title: Text('Wallet & Payments')),
      body: RefreshIndicator(onRefresh: _load, child: SingleChildScrollView(padding: EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Container(padding: EdgeInsets.all(20), decoration: BoxDecoration(gradient: LinearGradient(colors: [AppTheme.primary.withOpacity(0.15), Colors.transparent]), borderRadius: BorderRadius.circular(16), border: Border.all(color: AppTheme.primary.withOpacity(0.2))), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Row(children: [Icon(Icons.account_balance_wallet, size: 16, color: AppTheme.primary), SizedBox(width: 6), Text('Wallet Balance', style: TextStyle(color: AppTheme.textSecondary, fontSize: 13))],), SizedBox(height: 8), Text('₹${balance.toInt()}', style: TextStyle(fontSize: 36, fontWeight: FontWeight.bold, color: AppTheme.primary)), SizedBox(height: 12), ElevatedButton.icon(onPressed: () => _topup(context, auth), icon: Icon(Icons.add, size: 18), label: Text('Add Money'))])),
        SizedBox(height: 16),
        Row(children: [Expanded(child: Card(child: Padding(padding: EdgeInsets.all(12), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Row(children: [Icon(Icons.arrow_upward, size: 14, color: AppTheme.danger), SizedBox(width: 4), Text('Spent', style: TextStyle(color: AppTheme.textSecondary, fontSize: 11))]), SizedBox(height: 4), Text('₹${spent.toInt()}', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold))]))), SizedBox(width: 8), Expanded(child: Card(child: Padding(padding: EdgeInsets.all(12), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Row(children: [Icon(Icons.arrow_downward, size: 14, color: AppTheme.primary), SizedBox(width: 4), Text('Topped up', style: TextStyle(color: AppTheme.textSecondary, fontSize: 11))]), SizedBox(height: 4), Text('₹${topped.toInt()}', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold))])))]),
        SizedBox(height: 16),
        Text('Transaction History', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
        SizedBox(height: 8),
        if (_loading) Center(child: CircularProgressIndicator()) else if (_txns.isEmpty) Padding(padding: EdgeInsets.all(24), child: Center(child: Text('No transactions yet', style: TextStyle(color: AppTheme.textSecondary)))) else ..._txns.map((t) { final isCredit = t.type == 'CREDIT'; return Card(margin: EdgeInsets.only(bottom: 4), child: ListTile(leading: Container(padding: EdgeInsets.all(8), decoration: BoxDecoration(color: (isCredit ? AppTheme.primary : AppTheme.danger).withOpacity(0.1), shape: BoxShape.circle), child: Icon(isCredit ? Icons.arrow_downward : Icons.arrow_upward, size: 16, color: isCredit ? AppTheme.primary : AppTheme.danger)), title: Text(t.reason.replaceAll('_', ' ').toLowerCase().split(' ').map((w) => w[0].toUpperCase() + w.substring(1)).join(' '), style: TextStyle(fontSize: 13, fontWeight: FontWeight.w500)), subtitle: Text(t.createdAt.split('T')[0], style: TextStyle(fontSize: 11)), trailing: Text('${isCredit ? '+' : '-'}₹${t.amount.toInt()}', style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: isCredit ? AppTheme.primary : AppTheme.danger)))); }),
      ]))),
    );
  }
  void _topup(BuildContext context, AuthProvider auth) {
    double amount = 1000;
    showDialog(context: context, builder: (ctx) => StatefulBuilder(builder: (ctx, setState) => AlertDialog(
      title: Text('Add Money'), content: Column(mainAxisSize: MainAxisSize.min, children: [
        Text('₹${amount.toInt()}', style: TextStyle(fontSize: 32, fontWeight: FontWeight.bold, color: AppTheme.primary)),
        SizedBox(height: 16),
        Wrap(spacing: 8, children: [500, 1000, 2000, 5000].map((a) => ChoiceChip(label: Text('₹$a'), selected: amount == a, selectedColor: AppTheme.primary, onSelected: (_) => setState(() => amount = a.toDouble()))).toList()),
      ]),
      actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: Text('Cancel')), ElevatedButton(onPressed: () async {
        try {
          final order = await ApiService.createWalletOrder(auth.user!.id, amount);
          ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Order created: ${order['orderId']}. Razorpay checkout integration needed.')));
          Navigator.pop(ctx);
        } catch (e) { ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Error: $e'))); }
      }, child: Text('Pay ₹${amount.toInt()}'))],
    )));
  }
}

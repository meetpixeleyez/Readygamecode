import 'package:dio/dio.dart';
import '../models/user.dart';
import '../models/station.dart';
import '../models/booking.dart';
import '../models/ai_prediction.dart';

class ApiService {
  // Android emulator: http://10.0.2.2:3001
  // Physical device: http://YOUR_IP:3001
  static const String baseUrl = 'http://10.0.2.2:3001';
  static final Dio _dio = Dio(BaseOptions(baseUrl: baseUrl, connectTimeout: const Duration(seconds: 10), receiveTimeout: const Duration(seconds: 30), headers: {'Content-Type': 'application/json'}));

  // Auth
  static Future<User> getMe() async => User.fromJson((await _dio.get('/api/me')).data['user']);
  static Future<User> updateMe(Map<String, dynamic> patch) async => User.fromJson((await _dio.patch('/api/me', data: patch)).data['user']);
  static Future<Map<String, dynamic>> getMyStats() async => (await _dio.get('/api/me/stats')).data;

  // Stations
  static Future<List<Station>> searchStations({String? search, double? userLat, double? userLng, double? radius, List<String>? connectors}) async {
    final params = <String, dynamic>{};
    if (search != null) params['search'] = search;
    if (userLat != null) params['userLat'] = userLat;
    if (userLng != null) params['userLng'] = userLng;
    if (radius != null) params['radius'] = radius;
    if (connectors != null) params['connectors'] = connectors.join(',');
    final res = await _dio.get('/api/stations', queryParameters: params);
    return (res.data['stations'] as List).map((s) => Station.fromJson(s)).toList();
  }
  static Future<Station> getStationById(String id) async => Station.fromJson((await _dio.get('/api/stations/$id')).data['station']);

  // Vehicles
  static Future<List<Vehicle>> getVehicles(String userId) async => (await _dio.get('/api/vehicles', queryParameters: {'userId': userId})).data['vehicles'].map((v) => Vehicle.fromJson(v)).toList().cast<Vehicle>();
  static Future<Vehicle> createVehicle(Map<String, dynamic> data) async => Vehicle.fromJson((await _dio.post('/api/vehicles', data: data)).data['vehicle']);
  static Future<Vehicle> updateVehicle(String id, Map<String, dynamic> patch) async => Vehicle.fromJson((await _dio.patch('/api/vehicles', data: {'id': id, ...patch})).data['vehicle']);
  static Future<void> deleteVehicle(String id) async => await _dio.delete('/api/vehicles', queryParameters: {'id': id});

  // Bookings
  static Future<List<Booking>> getBookings(String userId) async => (await _dio.get('/api/bookings', queryParameters: {'userId': userId})).data['bookings'].map((b) => Booking.fromJson(b)).toList().cast<Booking>();
  static Future<Booking> createBooking(Map<String, dynamic> data) async => Booking.fromJson((await _dio.post('/api/bookings', data: data)).data['booking']);
  static Future<void> cancelBooking(String id) async => await _dio.patch('/api/bookings/$id', data: {'action': 'cancel'});
  static Future<void> completeBooking(String id) async => await _dio.patch('/api/bookings/$id', data: {'action': 'complete'});
  static Future<void> rescheduleBooking(String id, String start, String end) async => await _dio.patch('/api/bookings/$id', data: {'action': 'reschedule', 'slotStart': start, 'slotEnd': end});

  // Wallet
  static Future<List<Transaction>> getTransactions(String userId) async => (await _dio.get('/api/wallet', queryParameters: {'userId': userId})).data['transactions'].map((t) => Transaction.fromJson(t)).toList().cast<Transaction>();
  static Future<Map<String, dynamic>> createWalletOrder(String userId, double amount) async => (await _dio.post('/api/wallet/create-order', data: {'userId': userId, 'amount': amount})).data;
  static Future<Map<String, dynamic>> verifyWalletTopup(Map<String, dynamic> data) async => (await _dio.post('/api/wallet/verify', data: data)).data;

  // Payments
  static Future<Map<String, dynamic>> createPaymentOrder(Map<String, dynamic> data) async => (await _dio.post('/api/payments/create-order', data: data)).data;
  static Future<Map<String, dynamic>> verifyPayment(Map<String, dynamic> data) async => (await _dio.post('/api/payments/verify', data: data)).data;

  // Reviews
  static Future<List<dynamic>> getReviews(String stationId) async => (await _dio.get('/api/reviews', queryParameters: {'stationId': stationId})).data['reviews'] as List;

  // Route Planner
  static Future<PlannedTrip> planRoute(Map<String, dynamic> data) async => PlannedTrip.fromJson((await _dio.post('/api/route-planner', data: data)).data['trip']);

  // AI
  static Future<BatteryPrediction> predictBattery(Map<String, dynamic> data) async => BatteryPrediction.fromJson((await _dio.post('/api/ai/predict-battery', data: data)).data['prediction']);
  static Future<EmergencyAssessment> assessEmergency(Map<String, dynamic> data) async => EmergencyAssessment.fromJson((await _dio.post('/api/ai/emergency', data: data)).data['assessment']);
  static Future<CostComparisonResult> compareCosts(Map<String, dynamic> data) async => CostComparisonResult.fromJson((await _dio.post('/api/ai/compare-costs', data: data)).data);
  static Future<Map<String, dynamic>> planSmartTrip(Map<String, dynamic> data) async => (await _dio.post('/api/ai/plan-trip', data: data)).data['plan'];

  // Owner
  static Future<List<Station>> getOwnerStations(String ownerId) async => (await _dio.get('/api/owner', queryParameters: {'ownerId': ownerId})).data['stations'].map((s) => Station.fromJson(s)).toList().cast<Station>();
  static Future<void> createStation(Map<String, dynamic> data) async => await _dio.post('/api/owner', data: data);
  static Future<void> toggleCharger(String chargerId, String status) async => await _dio.patch('/api/owner', data: {'action': 'toggle-charger', 'chargerId': chargerId, 'status': status});

  // Admin
  static Future<Map<String, dynamic>> getAdminOverview() async => (await _dio.get('/api/admin')).data;
  static Future<void> approveStation(String id) async => await _dio.patch('/api/owner', data: {'action': 'approve-station', 'id': id});

  // Setup
  static Future<Map<String, dynamic>> getSetupStatus() async => (await _dio.get('/api/setup/status')).data;
  static Future<void> createStationsBulk(List<Map<String, dynamic>> stations) async => await _dio.post('/api/setup/stations', data: {'stations': stations});
  static Future<void> createVehicleModelsBulk(List<Map<String, dynamic>> models) async => await _dio.post('/api/setup/vehicle-models', data: {'models': models});
  static Future<List<VehicleModel>> getVehicleModels() async => (await _dio.get('/api/setup/vehicle-models')).data['models'].map((m) => VehicleModel.fromJson(m)).toList().cast<VehicleModel>();
}

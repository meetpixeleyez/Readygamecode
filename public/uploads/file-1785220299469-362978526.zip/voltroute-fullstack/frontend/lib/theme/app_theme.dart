import 'package:flutter/material.dart';

class AppTheme {
  static const Color background = Color(0xFF0D0F12);
  static const Color surface = Color(0xFF121417);
  static const Color primary = Color(0xFF00E676);
  static const Color secondary = Color(0xFF00B0FF);
  static const Color accent = Color(0xFFFFC107);
  static const Color danger = Color(0xFFFF5252);
  static const Color purple = Color(0xFFB388FF);
  static const Color textPrimary = Color(0xFFF5F5F5);
  static const Color textSecondary = Color(0xFF999999);
  static const Color border = Color(0x1AFFFFFF);

  static const Map<String, Color> connectorColors = {
    'CCS2': Color(0xFF00E676),
    'CHAdeMO': Color(0xFF00B0FF),
    'Type2': Color(0xFFFFC107),
    'GB/T': Color(0xFFFF6E40),
    'Bharat AC001': Color(0xFFB388FF),
    'Bharat DC001': Color(0xFFFF5252),
  };

  static const Map<String, Color> statusColors = {
    'AVAILABLE': Color(0xFF00E676),
    'OCCUPIED': Color(0xFFFFC107),
    'OFFLINE': Color(0xFF9E9E9E),
    'MAINTENANCE': Color(0xFFFF5252),
  };

  static ThemeData get darkTheme => ThemeData(
    useMaterial3: true,
    brightness: Brightness.dark,
    scaffoldBackgroundColor: background,
    colorScheme: const ColorScheme.dark(
      primary: primary, secondary: secondary, surface: surface,
      error: danger, onPrimary: Colors.black, onSurface: textPrimary,
    ),
    appBarTheme: const AppBarTheme(backgroundColor: background, foregroundColor: textPrimary, elevation: 0),
    cardTheme: CardThemeData(
      color: surface, elevation: 0,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12), side: const BorderSide(color: border)),
    ),
    inputDecorationTheme: InputDecorationTheme(
      filled: true, fillColor: surface,
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(8), borderSide: const BorderSide(color: border)),
      enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(8), borderSide: const BorderSide(color: border)),
      focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(8), borderSide: const BorderSide(color: primary, width: 1.5)),
      contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      labelStyle: const TextStyle(color: textSecondary, fontSize: 12),
    ),
    elevatedButtonTheme: ElevatedButtonThemeData(
      style: ElevatedButton.styleFrom(
        backgroundColor: primary, foregroundColor: Colors.black, elevation: 0,
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
      ),
    ),
    bottomNavigationBarTheme: const BottomNavigationBarThemeData(
      backgroundColor: surface, selectedItemColor: primary, unselectedItemColor: textSecondary,
      type: BottomNavigationBarType.fixed,
    ),
  );
}

// CardThemeData compatibility
class CardThemeData extends CardTheme {
  const CardThemeData({super.color, super.elevation, super.shape});
}

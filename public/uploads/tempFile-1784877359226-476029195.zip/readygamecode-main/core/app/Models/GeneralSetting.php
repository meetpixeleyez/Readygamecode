<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class GeneralSetting extends Model {
    protected $casts = [
        'mail_config'                 => 'object',
        'sms_config'                  => 'object',
        'global_shortcodes'           => 'object',
        'socialite_credentials'       => 'object',
        'firebase_config'             => 'object',
        'personal_license_features'   => 'array',
        'commercial_license_features' => 'array',
        'ftp'                         => 'object',
        'wasabi'                      => 'object',
        'digital_ocean'               => 'object',
        'backblaze'                   => 'object',
        'config_progress'             => 'object',
    ];

    protected $hidden = ['email_template', 'mail_config', 'sms_config', 'system_info'];

    public function scopeSiteName($query, $pageTitle = null) {
        $pageTitle = empty($pageTitle) ? '' : ' - ' . $pageTitle;
        return $this->site_name . $pageTitle;
    }

    protected static function boot() {
        parent::boot();
        static::saved(function () {
            \Cache::forget('GeneralSetting');
        });
    }
}
